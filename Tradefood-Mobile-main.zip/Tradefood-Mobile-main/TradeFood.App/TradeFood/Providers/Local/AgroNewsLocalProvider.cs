﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Repositories;

namespace TradeFood.Providers
{
    public class AgroNewsLocalProvider : IAgroNewsLocalProvider
    {
        private readonly IAgroNewsRepository _agroNewsRepository;

        public AgroNewsLocalProvider(IAgroNewsRepository agroNewsRepository)
        {
            _agroNewsRepository = agroNewsRepository;
        }

        public Task<List<NewsReport>> GetAgroNewsAsync()
        {
            return this.GetAgroNewsFromDb();
        }

        private Task<List<NewsReport>> GetAgroNewsFromDb()
        {
            return _agroNewsRepository.GetAgroNewsAsync();
        }
    }
}