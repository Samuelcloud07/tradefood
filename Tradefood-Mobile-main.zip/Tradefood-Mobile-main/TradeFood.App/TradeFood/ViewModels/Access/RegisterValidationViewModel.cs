﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Views;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class RegisterValidationViewModel : BaseViewModel, IQueryAttributable
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IDialogsHelper _dialogsHelper;

        public RegisterValidationViewModel(ILogger logger,
                                           IAuthenticationService authenticationService,
                                           IDialogsHelper dialogsHelper)
            : base(logger)
        {
            ValidateAccountCommand = new SandboxedCommand(ValidateAccount);

            ResendCodeCommand = new SandboxedCommand(ResendCode);

            GoBackCommand = new SandboxedCommand(GoBack);
            _authenticationService = authenticationService;
            _dialogsHelper = dialogsHelper;
        }

        public void ApplyQueryAttributes(IDictionary<string, string> query)
        {
            SignUpData = JsonConvert.DeserializeObject<LoginResponse>(HttpUtility.UrlDecode(query["signUpData"]));
        }

        // Properties
        public LoginResponse SignUpData { get; private set; }

        public string ValidationCode { get; set; }

        // Commands
        public SandboxedCommand ValidateAccountCommand { get; private set; }

        public SandboxedCommand ResendCodeCommand { get; private set; }

        public SandboxedCommand GoBackCommand { get; private set; }

        // Methods
        private async Task GoBack() => await Shell.Current.Navigation.PopToRootAsync();

        private async Task ValidateAccount()
        {
            if (string.IsNullOrEmpty(ValidationCode))
            {
                _dialogsHelper.ShowAlert(Strings.YouMustCompleteTheValidationCode);

                return;
            }

            _dialogsHelper.ShowDialog();

            var emailConfirmation = new EmailConfirmation
            {
                Email = SignUpData.Email,
                EmailConfirmationToken = ValidationCode
            };

            var emailConfirmationData = await _authenticationService.ConfirmEmailAsync(emailConfirmation);

            var emailConfirmationDataSerialized = JsonConvert.SerializeObject(emailConfirmationData);

            _dialogsHelper.HideDialog();

            await Shell.Current.GoToAsync($"/{nameof(RegisterSuccessPage)}?succesData={emailConfirmationDataSerialized}");
        }

        private async Task ResendCode()
        {
            _dialogsHelper.ShowDialog();

            await _authenticationService.ResendEmailConfirmationAsync(SignUpData.Email);

            _dialogsHelper.HideDialog();

            _dialogsHelper.ShowAlert($"Un nuevo código de validación ha sido enviado a tu casilla de mail: {SignUpData.Email}");
        }
    }
}