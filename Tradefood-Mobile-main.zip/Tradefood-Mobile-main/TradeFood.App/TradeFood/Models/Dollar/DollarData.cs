﻿using Newtonsoft.Json;
using System;

namespace TradeFood.Models
{
    public class DollarData
    {
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("fecha")]
        public DateTime Fecha { get; set; }

        [JsonProperty("compra")]
        public string Compra { get; set; }

        [JsonProperty("venta")]
        public string Venta { get; set; }
    }
}