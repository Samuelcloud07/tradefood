﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class NewsReport : BaseEntityModel
    {
        [JsonProperty("header")]
        public string Header { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("url")]
        public string Url { get; set; }

        [JsonProperty("image")]
        public string Image { get; set; }
    }
}