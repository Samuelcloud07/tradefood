﻿using System.Net.Http;

namespace TradeFood.ApiClient
{
    public interface IAppHttpClient
    {
        HttpClient HttpClient { get; }
    }
}