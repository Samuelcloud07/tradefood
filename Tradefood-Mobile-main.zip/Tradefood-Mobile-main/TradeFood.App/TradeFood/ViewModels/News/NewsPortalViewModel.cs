﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using TradeFood.Helpers;
using TradeFood.Repositories;
using TradeFood.Services.Loggin;

namespace TradeFood.ViewModels
{
    public class NewsPortalViewModel : BaseViewModel
    {
        private readonly IAgroNewsRepository _agroNewsRepository;
        private readonly IDialogsHelper _dialogsHelper;

        public NewsPortalViewModel(ILogger logger,
                                   IAgroNewsRepository agroNewsRepository,
                                   IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _agroNewsRepository = agroNewsRepository;
            _dialogsHelper = dialogsHelper;
        }

        protected override async Task InitializeAsync()
        {
            _dialogsHelper.ShowDialog();

            await base.InitializeAsync();

            var news = await _agroNewsRepository.GetAgroNewsAsync();

            foreach (var report in news)
                AgroNews.Add(new AgroNewsItemViewModel(report));

            this.OnPropertyChanged(nameof(AgroNews));

            _dialogsHelper.HideDialog();
        }

        // Properties
        public ObservableCollection<AgroNewsItemViewModel> AgroNews { get; private set; } = new ObservableCollection<AgroNewsItemViewModel>();
    }
}