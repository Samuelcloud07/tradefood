﻿using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.ApiClient.ApisInterfaces
{
    public interface IStatesApi
    {
        [Get("/provinciasfunction/states/provincias")]
        Task<TradeFoodApiResponse<List<ProvinceLocation>>> GetProvincesAsync();

        [Get("/provinciasfunction/states/localidades?province={provincia}")]
        Task<TradeFoodApiResponse<List<ProvinceLocation>>> GetLocationsForProvinceAsync(string provincia);
    }
}