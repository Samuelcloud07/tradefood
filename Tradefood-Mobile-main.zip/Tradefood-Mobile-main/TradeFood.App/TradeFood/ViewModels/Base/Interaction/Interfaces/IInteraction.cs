﻿using System;

namespace TradeFood.ViewModels.Base
{
    public interface IInteraction
    {
        event EventHandler Requested;
    }

    public interface IInteraction<T>
    {
        event EventHandler<ValueEventArgs<T>> Requested;
    }
}