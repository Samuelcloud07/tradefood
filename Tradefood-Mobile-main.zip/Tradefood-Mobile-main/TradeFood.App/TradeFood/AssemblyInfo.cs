using System.Resources;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
[assembly: Preserve(AllMembers = true)]
[assembly: ExportFont("Poppins-Bold.ttf", Alias = "Poppins_Bold")]
[assembly: ExportFont("Poppins-SemiBold.ttf", Alias = "Poppins_SemiBold")]
[assembly: ExportFont("Poppins-Medium.ttf", Alias = "Poppins_Medium")]
[assembly: ExportFont("Poppins-Regular.ttf", Alias = "Poppins_Regular")]
[assembly: ExportFont("Poppins-Light.ttf", Alias = "Poppins_Light")]
[assembly: ExportFont("Poppins-Italic.ttf", Alias = "Poppins_Italic")]
[assembly: NeutralResourcesLanguage("en")]