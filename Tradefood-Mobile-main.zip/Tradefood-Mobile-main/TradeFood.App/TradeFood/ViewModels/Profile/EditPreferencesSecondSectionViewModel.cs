﻿using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    class EditPreferencesSecondSectionViewModel : BaseViewModel
    {
        public readonly IStatesService _statesServices;
        private readonly IProfileService _profileService;
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialoghelpers;
        public EditPreferencesSecondSectionViewModel(ILogger logger,
                                    IAppSettings appSettings,
                                    IProfileService profileService,
                                    IStatesService statesService,
                                    IDialogsHelper dialogsHelper)
            : base(logger)
        {

            GoBackCommand = new SandboxedCommand(GoBack);
            SavePreferencesCommand = new SandboxedCommand(SavePreferences);
            SelectProvincesCommand = new SandboxedCommand(SelectProvinces);
            SelectProvincesChoreCommand = new SandboxedCommand(SelectProvincesChore);
            SelectLocationsCommand = new SandboxedCommand(SelectLocations);

            _appSettings = appSettings;
            _profileService = profileService;
            _statesServices = statesService;
            _dialoghelpers = dialogsHelper;
        }

        protected override async Task InitializeAsync()
        {
            _dialoghelpers.ShowDialog();

            await base.InitializeAsync();

            WinteringPaymentTerms = new ObservableCollection<PaymentTermsItemViewModel>
            {
                new PaymentTermsItemViewModel("Contado"),
                new PaymentTermsItemViewModel("30 - 60 días"),
                new PaymentTermsItemViewModel("0 - 30 - 60 días"),
                new PaymentTermsItemViewModel("30 días"),
                new PaymentTermsItemViewModel("45 días"),
                new PaymentTermsItemViewModel("30 - 60 - 90 días")
            };

            ChorePaymentTerms = new ObservableCollection<PaymentTermsItemViewModel>
            {
                new PaymentTermsItemViewModel("Contado"),
                new PaymentTermsItemViewModel("7 días"),
                new PaymentTermsItemViewModel("15 días"),
                new PaymentTermsItemViewModel("21 días"),
                new PaymentTermsItemViewModel("45 días"),
                new PaymentTermsItemViewModel("30 días")
            };

            foreach (var term in PreferencesObject.PaymentTerms)
            {
                if (term.BusinessType.Equals("wintering"))
                {
                    foreach (var item in WinteringPaymentTerms)
                    {
                        if (term.Name.Equals(item.Name))
                        {
                            item.Selected = true;
                            item.MinPriceSelected = term.MinPrice.ToString();
                            item.MaxPriceSelected = term.MaxPrice.ToString();
                            WinteringPaymentTermsSelected.Add(item);
                        }
                    }
                }

                if (term.BusinessType.Equals("chore"))
                {
                    foreach (var item in ChorePaymentTerms)
                    {
                        if (term.Name.Equals(item.Name))
                        {
                            item.Selected = true;
                            item.MinPriceSelected = term.MinPrice.ToString();
                            item.MaxPriceSelected = term.MaxPrice.ToString();
                            ChorePaymentTermsSelected.Add(item);
                        }
                    }
                }
            }

            //test = new PaymentTermsItemViewModel(WinteringPaymentTermsSelected[0].Name)
            //{
            //    MinPriceSelected = WinteringPaymentTermsSelected[0].MinPriceSelected,
            //    MaxPriceSelected = WinteringPaymentTermsSelected[0].MaxPriceSelected
            //};
            //test = WinteringPaymentTermsSelected[0];

            Provinces = await _statesServices.GetProvincesAsync();

            if (ProvincesCollection.Count == 0)
            {
                foreach (var province in Provinces)
                {
                    ProvincesCollection.Add(new ProvinceOrLocationItemViewModel
                    {
                        Name = province.Name.Equals("Tierra del Fuego, Antártida e Islas del Atlántico Sur") ? "Tierra del fuego" : province.Name,
                        Selected = PreferencesObject.DestinationStatesWintering.Contains(province.Name.Equals("Tierra del Fuego, Antártida e Islas del Atlántico Sur") ? "Tierra del fuego" : province.Name)
                    });

                    if (PreferencesObject.DestinationStatesWintering.Contains(province.Name.Equals("Tierra del Fuego, Antártida e Islas del Atlántico Sur") ? "Tierra del fuego" : province.Name))
                        ProvincesSelected.Add(new ProvinceAndLocationItemViewModel(province.Name));
                }

                HeightProvincesWintering = 40;
            }


            if (ProvincesCollectionChore.Count == 0)
            {
                foreach (var province in Provinces)
                {
                    ProvincesCollectionChore.Add(new ProvinceOrLocationItemViewModel
                    {
                        Name = province.Name.Equals("Tierra del Fuego, Antártida e Islas del Atlántico Sur") ? "Tierra del fuego" : province.Name,
                        Selected = PreferencesObject.DestinationStatesChore.Contains(province.Name.Equals("Tierra del Fuego, Antártida e Islas del Atlántico Sur") ? "Tierra del fuego" : province.Name)
                    });

                    if (PreferencesObject.DestinationStatesChore.Contains(province.Name.Equals("Tierra del Fuego, Antártida e Islas del Atlántico Sur") ? "Tierra del fuego" : province.Name))
                        ProvincesSelectedChore.Add(new ProvinceAndLocationItemViewModel(province.Name));
                }
                HeightProvincesChore = 40;
            }

            _dialoghelpers.HideDialog();
        }

        public PreferencesDto PreferencesObject { get; set; }

        public List<ProvinceLocation> Provinces { get; private set; } = new List<ProvinceLocation>();

        public List<ProvinceLocation> Locations { get; private set; } = new List<ProvinceLocation>();

        public ObservableCollection<LocationsGroup> LocationsGroup { get; set; } = new ObservableCollection<LocationsGroup>();

        public ObservableCollection<LocationsGroup> LocationsGroupSelected { get; set; } = new ObservableCollection<LocationsGroup>();

        // Properties Wintering

        public ObservableCollection<ProvinceOrLocationItemViewModel> ProvincesCollection { get; set; } = new ObservableCollection<ProvinceOrLocationItemViewModel>();

        public ObservableCollection<ProvinceAndLocationItemViewModel> ProvincesSelected { get; set; } = new ObservableCollection<ProvinceAndLocationItemViewModel>();

        public ObservableCollection<PaymentTermsItemViewModel> WinteringPaymentTerms { get; set; }

        public ObservableCollection<PaymentTermsItemViewModel> WinteringPaymentTermsSelected { get; set; } = new ObservableCollection<PaymentTermsItemViewModel>();

        public PaymentTermsItemViewModel test { get; set; }
        public List<PaymentTermDto> PaymentTerms { get; set; } = new List<PaymentTermDto>();

        public int HeightProvincesWintering { get; set; }

        // End properties wintering

        // Properties Chore

        public ObservableCollection<ProvinceOrLocationItemViewModel> ProvincesCollectionChore { get; set; } = new ObservableCollection<ProvinceOrLocationItemViewModel>();

        public ObservableCollection<ProvinceAndLocationItemViewModel> ProvincesSelectedChore { get; set; } = new ObservableCollection<ProvinceAndLocationItemViewModel>();

        public ObservableCollection<PaymentTermsItemViewModel> ChorePaymentTermsSelected { get; set; } = new ObservableCollection<PaymentTermsItemViewModel>();

        public ObservableCollection<PaymentTermsItemViewModel> ChorePaymentTerms { get; set; }

        public int HeightProvincesChore { get; set; }

        // End properties chore

        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();

        public bool HasErrors { get; set; }

        private bool ValidateAll()
        {
            Errors.Clear();

            if (PreferencesObject.IsBusinessTypeWintering)
            {
                if (ProvincesSelected.Count == 0)
                    Errors.Add(nameof(ProvincesSelected), Strings.YouMustSelectAtLeastOneProvince);

                if (WinteringPaymentTermsSelected.Count == 0)
                {
                    Errors.Add(nameof(WinteringPaymentTerms), Strings.YouMustSelectAtLeastOnePaymentTerm);
                }
                else
                {
                    foreach (var item in WinteringPaymentTermsSelected)
                    {
                        if (string.IsNullOrEmpty(item.MinPriceSelected) || string.IsNullOrEmpty(item.MaxPriceSelected))
                        {
                            Errors.Add(nameof(WinteringPaymentTermsSelected), Strings.YouMustSelectAMinimumAndMaximumAmount);
                            break;
                        }
                        else if (item.MaxPriceSelected.Equals(item.MinPriceSelected) || int.Parse(item.MaxPriceSelected) < int.Parse(item.MinPriceSelected))
                        {
                            Errors.Add(nameof(WinteringPaymentTermsSelected), Strings.MaximumCannotBeEqualToOrLessThanTheMinimum);
                            break;
                        }

                    }
                }

            }
            if (PreferencesObject.IsBusinessTypeChore)
            {
                if (ProvincesSelectedChore.Count == 0)
                    Errors.Add(nameof(ProvincesSelectedChore), Strings.YouMustSelectAtLeastOneProvince);

                if (ChorePaymentTermsSelected.Count == 0)
                {
                    Errors.Add(nameof(ChorePaymentTerms), Strings.YouMustSelectAtLeastOnePaymentTerm);
                }
                else
                {
                    foreach (var item in ChorePaymentTermsSelected)
                    {
                        if (string.IsNullOrEmpty(item.MinPriceSelected) || string.IsNullOrEmpty(item.MaxPriceSelected))
                        {
                            Errors.Add(nameof(ChorePaymentTermsSelected), Strings.YouMustSelectAMinimumAndMaximumAmount);
                            break;
                        }
                        else if (item.MaxPriceSelected.Equals(item.MinPriceSelected) || Int32.Parse(item.MaxPriceSelected) < Int32.Parse(item.MinPriceSelected))
                        {
                            Errors.Add(nameof(ChorePaymentTermsSelected), Strings.MaximumCannotBeEqualToOrLessThanTheMinimum);
                            break;
                        }

                    }
                }
            }


            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }


        //Commands
        public SandboxedCommand SelectProvincesCommand { get; private set; }
        public SandboxedCommand SelectProvincesChoreCommand { get; private set; }
        public SandboxedCommand SelectLocationsCommand { get; private set; }

        public SandboxedCommand SavePreferencesCommand { get; private set; }
        public SandboxedCommand GoBackCommand { get; private set; }

        // Methods
        private async Task SelectProvinces()
        {
            await PopupNavigation.Instance.PushAsync(new SelectProvincesPopupPage(ProvincesCollection, "Invernada"));
        }

        private async Task SelectProvincesChore()
        {
            await PopupNavigation.Instance.PushAsync(new SelectProvincesPopupPage(ProvincesCollectionChore, "Faena"));
        }

        private async Task SelectLocations()
        {
            await PopupNavigation.Instance.PushAsync(new SelectLocationsPopupPage(LocationsGroup));
        }

        private async Task SavePreferences()
        {
            if (!ValidateAll())
                return;

            _dialoghelpers.ShowDialog();

            StringBuilder sbWinteringProvinces = new StringBuilder("");
            StringBuilder sbChoreProvinces = new StringBuilder("");

            if (PreferencesObject.IsBusinessTypeWintering)
            {
                if (ProvincesSelected.Count > 0)
                {
                    for (int i = 0; i < ProvincesSelected.Count; i++)
                    {
                        if (ProvincesSelected.Count == 1)
                        {
                            sbWinteringProvinces.Append(ProvincesSelected[i].ProvinceName);
                        }
                        else if (i == (ProvincesSelected.Count - 1))
                        {
                            sbWinteringProvinces.Append(" y ");
                            sbWinteringProvinces.Append(ProvincesSelected[i].ProvinceName);
                        }
                        else if (i == (ProvincesSelected.Count - 2))
                        {
                            sbWinteringProvinces.Append(ProvincesSelected[i].ProvinceName);
                        }
                        else
                        {
                            sbWinteringProvinces.Append(ProvincesSelected[i].ProvinceName);
                            sbWinteringProvinces.Append(", ");
                        }
                    }
                }
                foreach (var payment in WinteringPaymentTermsSelected)
                {
                    PaymentTerms.Add(new PaymentTermDto
                    {
                        BusinessType = "wintering",
                        Name = payment.Name,
                        Selected = true,
                        MinPrice = string.IsNullOrEmpty(payment.MinPriceSelected) ? 0 : int.Parse(payment.MinPriceSelected),
                        MaxPrice = string.IsNullOrEmpty(payment.MaxPriceSelected) ? 0 : int.Parse(payment.MaxPriceSelected)
                    });
                };
            }

            if (PreferencesObject.IsBusinessTypeChore)
            {
                if (ProvincesSelectedChore.Count > 0)
                {
                    for (int i = 0; i < ProvincesSelectedChore.Count; i++)
                    {
                        if (ProvincesSelectedChore.Count == 1)
                        {
                            sbChoreProvinces.Append(ProvincesSelectedChore[i].ProvinceName);
                        }
                        else if (i == (ProvincesSelectedChore.Count - 1))
                        {
                            sbChoreProvinces.Append(" y ");
                            sbChoreProvinces.Append(ProvincesSelectedChore[i].ProvinceName);
                        }
                        else if (i == (ProvincesSelectedChore.Count - 2))
                        {
                            sbChoreProvinces.Append(ProvincesSelectedChore[i].ProvinceName);
                        }
                        else
                        {
                            sbChoreProvinces.Append(ProvincesSelectedChore[i].ProvinceName);
                            sbChoreProvinces.Append(", ");
                        }
                    }
                }
                foreach (var payment in ChorePaymentTermsSelected)
                {
                    PaymentTerms.Add(new PaymentTermDto
                    {
                        BusinessType = "chore",
                        Name = payment.Name,
                        Selected = true,
                        MinPrice = string.IsNullOrEmpty(payment.MinPriceSelected) ? 0 : int.Parse(payment.MinPriceSelected),
                        MaxPrice = string.IsNullOrEmpty(payment.MaxPriceSelected) ? 0 : int.Parse(payment.MaxPriceSelected)
                    });
                };
            }

            PreferencesObject.DestinationStatesWintering = sbWinteringProvinces.ToString();
            PreferencesObject.DestinationStatesChore = sbChoreProvinces.ToString();
            PreferencesObject.PaymentTerms = PaymentTerms;

            await _profileService.AddProfilePreferences(long.Parse(_appSettings.UserId), PreferencesObject);

            _dialoghelpers.HideDialog();

            await Shell.Current.GoToAsync("../../..");
        }
        private async Task GoBack()
        {
            await Shell.Current.GoToAsync("..");
        }
    }


}
