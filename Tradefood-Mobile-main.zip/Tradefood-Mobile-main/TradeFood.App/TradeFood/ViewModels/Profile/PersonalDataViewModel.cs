﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using Xamarin.Forms;

namespace TradeFood.ViewModels.Profile
{
    internal class PersonalDataViewModel : BaseViewModel
    {
        private readonly IAppSettings _appSettings;
        private readonly IProfileService _profileService;
        private readonly IDialogsHelper _dialogsHelper;
        public PersonalDataViewModel(ILogger logger,
                                     IAppSettings appSettings,
                                     IProfileService profileService,
                                     IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _appSettings = appSettings;
            _profileService = profileService;
            _dialogsHelper = dialogsHelper;

            AddCommercialReferenceCommand = new SandboxedCommand(AddCommercialReference);
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            UserId = _appSettings.UserId;
        }

        //Properties
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Comments { get; set; }   

        //Commands
        public SandboxedCommand AddCommercialReferenceCommand { get; private set; }

        private async Task AddCommercialReference()
        {
           if(string.IsNullOrEmpty(Name) || string.IsNullOrEmpty(Comments))
            {
                _dialogsHelper.ShowAlert(Strings.YouMustCompleteAllTheFields);
                return;
            }

            var newCommercialReference = new CommercialReferenceDto
            {
                Name = Name,
                Comments = Comments
            };

            await _profileService.AddCommercialReferenceAsync(UserId, newCommercialReference);
            MessagingCenter.Send<PersonalDataViewModel>(this, "ReferenciaComercialAgregada");
            await Shell.Current.GoToAsync("..");
        }

    }
}
