﻿using System.Collections.Generic;
using System.ComponentModel;

namespace TradeFood.ViewModels
{
    public class PaymentTermsItemViewModel : INotifyPropertyChanged
    {
        public PaymentTermsItemViewModel(string name)
        {
            Name = name;
        }
        public string Name { get; set; }

        public List<string> MinPrice { get; set; } = new List<string>
        {
            "100",
            "200",
            "300",
            "400",
            "500",
            "600",
            "700",
            "800",
            "900",
            "1000"
        };
        public List<string> MaxPrice { get; set; } = new List<string>
        {
            "100",
            "200",
            "300",
            "400",
            "500",
            "600",
            "700",
            "800",
            "900",
            "1000"
        };
        public string MinPriceSelected { get; set; }

        public string MaxPriceSelected { get; set; }

        private bool _selected;
        public bool Selected
        {
            get => _selected;
            set
            {
                _selected = value;
                OnPropertyChanged(nameof(Selected));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}