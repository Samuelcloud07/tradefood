﻿using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;

namespace TradeFood.ApiClient
{
    public interface IProfileApi
    {
        [Get("/profile/Profile")]
        Task<TradeFoodApiResponse<string>> TestAsync();

        [Get("/Profile-Function/Profile/get-commercial-references?userId={userId}")]
        Task<TradeFoodApiResponse<CommercialReferenceDto>> GetCommercialReferenceAsync(long userId);

        [Post("/profile-function/Profile/add-commercial-reference?userId={userId}")]
        Task<TradeFoodApiResponse<bool>> AddCommercialReferenceAsync(string userId, [Body(BodySerializationMethod.Serialized)] CommercialReferenceDto commercialReference);

        [Post("/Profile-Function/Profile/add-societiesandpersons?userId={userId}")]
        Task<TradeFoodApiResponse<bool>> AddSocietiesAndPersonsAsync(long userId, [Body(BodySerializationMethod.Serialized)] SocietiesAndPersonDto societiesAndPerson);

        [Get("/profile-function/Profile/get-societiesandpersons?userId={userId}")]
        Task<TradeFoodApiResponse<List<SocietiesAndPersonDto>>> GetSocietiesAndPersonsAsync(long userId);

        [Post("/Profile-Function/Profile/add-addresssocieties?userId={userId}&societiesId={societiesId}")]
        Task<TradeFoodApiResponse<bool>> AddAddressSocietiesAsync(long userId, long societiesId, [Body(BodySerializationMethod.Serialized)] AddressDto address);

        [Delete("/Profile-Function/Profile/delete-societies?userId={userId}&societiesId={societiesId}")]
        Task<TradeFoodApiResponse<bool>> DeleteSocietiesAsync(long userId, long societiesId);

        [Post("/Profile-Function/Profile/update-societies?userId={userId}")]
        Task<TradeFoodApiResponse<bool>> UpdateSocietiesAsync(long userId, [Body(BodySerializationMethod.Serialized)] SocietiesAndPersonDto societiesAndPersons);

        [Post("/Profile/update-address/Profile/update-address?userId={userId}")]
        Task<TradeFoodApiResponse<bool>> UpdateAddressAsync(long userId, [Body(BodySerializationMethod.Serialized)] AddressDto address);

        [Get("/Profile-Function/Profile/get-user-addresses?userId={userId}")]
        Task<TradeFoodApiResponse<List<AddressDto>>> GetAddressesAsync(long userId);

        [Get("/Profile-Function/Profile/get-all-user-addresses?userId={userId}")]
        Task<TradeFoodApiResponse<List<AddressDto>>> GetAllAddressesAsync(long userId);

        [Post("/Profile-Function/Profile/add-address?userId={userId}")]
        Task<TradeFoodApiResponse<bool>> AddAddressAsync(AddressDto addressDto, long userId);

        [Get("/Profile-Function/Profile/get-stats-type-profile")]
        Task<TradeFoodApiResponse<ProfileStats>> GetProfileStats();

        [Get("/Profile-Function/Profile/get-preferences?userId={userId}")]
        Task<TradeFoodApiResponse<PreferencesDto>> GetProfilePreferences(long userId);

        [Post("/Profile-Function/Profile/add-preferences?userId={userId}")]
        Task<TradeFoodApiResponse<bool>> AddProfilePreferences(long userId, [Body(BodySerializationMethod.Serialized)] PreferencesDto preferences);
    }
}
