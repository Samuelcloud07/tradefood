﻿using TradeFood.ApiClient;

namespace TradeFood.Providers
{
    public class TradeFoodBaseApiProvider : BaseApiProvider
    {
        public TradeFoodBaseApiProvider(IAppHttpClient httpClientSingleton,
                                        IApiExceptionManager apiExceptionManager)
            : base(httpClientSingleton, apiExceptionManager)
        {
        }
    }
}