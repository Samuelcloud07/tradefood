﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public interface ILiniersLocalProvider : ILiniersProvider
    {
        Task<List<LiniersData>> PersistLiniersDataAsync(IEnumerable<LiniersData> liniersData);
    }
}