﻿namespace TradeFood.Providers
{
    public interface IStatesLocalProvider : IStatesProvider
    {
    }
}