﻿using Foundation;
using Microsoft.AppCenter.Distribute;
using PanCardView.iOS;
using UIKit;

namespace TradeFood.iOS
{
    [Register(nameof(AppDelegate))]
    public partial class AppDelegate : global::Xamarin.Forms.Platform.iOS.FormsApplicationDelegate
    {
        public override bool FinishedLaunching(UIApplication app, NSDictionary options)
        {
            UINavigationBar.Appearance.Translucent = false;
            UITabBar.Appearance.BackgroundColor = UIColor.White;

            app.StatusBarStyle = UIStatusBarStyle.LightContent;

            Rg.Plugins.Popup.Popup.Init();

            global::Xamarin.Forms.Forms.Init();

            CardsViewRenderer.Preserve();

            FFImageLoading.Forms.Platform.CachedImageRenderer.Init();

            Distribute.DontCheckForUpdatesInDebug();

            LoadApplication(new App());

            Plugin.InputKit.Platforms.iOS.Config.Init();

            return base.FinishedLaunching(app, options);
        }
    }
}