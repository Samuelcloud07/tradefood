﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using TradeFood.Enums;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Xamarin.Essentials;

namespace TradeFood.Services.Loggin
{
    public class AppState : IAppState
    {
        private Guid _installId = Guid.Empty;
        private AppLogLevel _logLevel;

        public AppLogLevel GetAppLogLevel() =>_logLevel;

        public Guid GetInstallId() => _installId;

        public async Task Init()
        {
            if (await CheckAppCenter())
            {
                //https://docs.microsoft.com/en-us/appcenter/sdk/other-apis/xamarin#identify-installations//
                Guid? installId = await AppCenter.GetInstallIdAsync();
                
                if (installId != null)
                    _installId = (Guid)installId;
            }
        }

        public void SetAppLogLevel(AppLogLevel level)
        {
            // this controls what logging message should be set to AppCenter at all
            _logLevel = level;
        }

        private async Task<bool> CheckAppCenter()
        {
            var retValue = true;

            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    // connection to internet is available
                    // check to make sure analytics is wired up
                    if (!await Analytics.IsEnabledAsync())
                    {
                        // we can't really report to appcenter that appcenter isn't working!
                        Debug.WriteLine($"[{this.GetType()}] Warning: AppCenter Analytics is NOT enabled.");

                        retValue = false;
                    }

                    if (!await Crashes.IsEnabledAsync())
                    {
                        // we can't really report to appcenter that appcenter isn't working!
                        Debug.WriteLine($"[{this.GetType()}] Warning: AppCenter Crash Reporting is NOT enabled.");
                
                        retValue = false;
                    }
                }
            }
            catch (Exception ex)
            {
                // we can't really report to appcenter that appcenter isn't working!
                Debug.WriteLine($"[{this.GetType()}] Exception while checking if AppCenter is enabled {ex.Message} {ex.StackTrace}");

                retValue = false;
            }

            return retValue;
        }
    }
}