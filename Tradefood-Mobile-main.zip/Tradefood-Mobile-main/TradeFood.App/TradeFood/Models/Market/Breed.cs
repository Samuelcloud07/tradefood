﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market
{
    public  class Breed
    {
        public string Name { get; set; }
    }
}
