﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TradeFood.Models.Profile;

namespace TradeFood.Providers
{
    public interface IProfileLocalProvider : IProfileProvider
    {
    }
}
