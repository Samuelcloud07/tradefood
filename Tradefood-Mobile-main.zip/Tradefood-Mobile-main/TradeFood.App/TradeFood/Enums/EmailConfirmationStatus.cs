﻿namespace TradeFood.Enums
{
    public enum EmailConfirmationStatus
    {
        Pending,
        Verified
    }
}