﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;

namespace TradeFood.Providers
{
    public class ProfileApiProvider : TradeFoodBaseApiProvider, IProfileApiProvider
    {

        public ProfileApiProvider(IAppHttpClient httpClientSingleton,
                                  IApiExceptionManager apiExceptionManager)
        : base(httpClientSingleton, apiExceptionManager)
        {

        }

        public async Task<string> TestAsync()
        {
            var result = await this.ExecuteRequest<TradeFoodApiResponse<string>>(
                () => this.GetRestServiceFor<IProfileApi>().TestAsync()).ConfigureAwait(false);
            return result.Data;
        }

        public async Task<CommercialReferenceDto> GetCommercialReferenceAsync(long userId)
        {
            var commercialReference = await this.ExecuteRequest<TradeFoodApiResponse<CommercialReferenceDto>>(
                () => this.GetRestServiceFor<IProfileApi>().GetCommercialReferenceAsync(userId)).ConfigureAwait(false);
            return commercialReference.Data;
        }

        public async Task<bool> AddCommercialReferenceAsync(string userId, CommercialReferenceDto commercialReference)
        {
            var newCommercialReference = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IProfileApi>().AddCommercialReferenceAsync(userId, commercialReference)).ConfigureAwait(false);
            return newCommercialReference.Data;
        }

        public async Task<bool> AddSocietiesAndPersonsAsync(long userId, SocietiesAndPersonDto societiesAndPerson)
        {
            var newSocietiesAndPerson = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IProfileApi>().AddSocietiesAndPersonsAsync(userId, societiesAndPerson)).ConfigureAwait(false);
            return newSocietiesAndPerson.Data;
        }

        public async Task<List<SocietiesAndPersonDto>> GetSocietiesAndPersonsAsync(long userId)
        {
            var societiesAndPerson = await this.ExecuteRequest<TradeFoodApiResponse<List<SocietiesAndPersonDto>>>(
                () => this.GetRestServiceFor<IProfileApi>().GetSocietiesAndPersonsAsync(userId)).ConfigureAwait(false);
            return societiesAndPerson.Data;
        }

        public async Task<bool> AddAddressSocietiesAsync(long userId, long societiesId, AddressDto address)
        {
            var newSocietiesAndPerson = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IProfileApi>().AddAddressSocietiesAsync(userId, societiesId, address)).ConfigureAwait(false);
            return newSocietiesAndPerson.Data;
        }

        public async Task<bool> DeleteSocietiesAsync(long userId, long societiesId)
        {
            var deletesocieties = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IProfileApi>().DeleteSocietiesAsync(userId, societiesId)).ConfigureAwait(false);
            return deletesocieties.Data;
        }

        public async Task<bool> UpdateSocietiesAsync(long userId, SocietiesAndPersonDto societiesAndPersons)
        {
            var updatesocieties = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                 () => this.GetRestServiceFor<IProfileApi>().UpdateSocietiesAsync(userId, societiesAndPersons)).ConfigureAwait(false);
            return updatesocieties.Data;
        }
        public async Task<bool> UpdateAddressAsync(long userId, AddressDto address)
        {
            var updateaddress = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                 () => this.GetRestServiceFor<IProfileApi>().UpdateAddressAsync(userId, address)).ConfigureAwait(false);
            return updateaddress.Data;
        }

        public async Task<List<AddressDto>> GetAddressesAsync(long userId)
        {
            var getAddresses = await this.ExecuteRequest<TradeFoodApiResponse<List<AddressDto>>>(
                () => this.GetRestServiceFor<IProfileApi>().GetAddressesAsync(userId)).ConfigureAwait(false);
            return getAddresses.Data;
        }

        public async Task<List<AddressDto>> GetAllAddressesAsync(long userId)
        {
            var getAddresses = await this.ExecuteRequest<TradeFoodApiResponse<List<AddressDto>>>(
                () => this.GetRestServiceFor<IProfileApi>().GetAllAddressesAsync(userId)).ConfigureAwait(false);
            return getAddresses.Data;
        }

        public async Task<bool> AddAddressAsync(AddressDto addressDto, long userId)
        {
            var addAddresses = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IProfileApi>().AddAddressAsync(addressDto, userId)).ConfigureAwait(false);
            return addAddresses.Data;
        }

        public async Task<ProfileStats> GetProfileStats()
        {
            var profileStats = await this.ExecuteRequest<TradeFoodApiResponse<ProfileStats>>(
                () => this.GetRestServiceFor<IProfileApi>().GetProfileStats()).ConfigureAwait(false);

            return profileStats.Data;
        }

        public async Task<PreferencesDto> GetProfilePreferences(long userId)
        {
            var profilePreferences = await this.ExecuteRequest<TradeFoodApiResponse<PreferencesDto>>(
                () => this.GetRestServiceFor<IProfileApi>().GetProfilePreferences(userId)).ConfigureAwait(false);

            return profilePreferences.Data;
        }

        public async Task<bool> AddProfilePreferences(long userId, PreferencesDto preferences)
        {
            var profilePreferences = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IProfileApi>().AddProfilePreferences(userId, preferences)).ConfigureAwait(false);

            return profilePreferences.Data;
        }
    }
}
