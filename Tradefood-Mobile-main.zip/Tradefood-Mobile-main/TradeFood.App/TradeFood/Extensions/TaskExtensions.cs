﻿using TradeFood.Exceptions;
using TradeFood.Services.Loggin;
using System;
using System.Threading.Tasks;

namespace TradeFood.Extensions
{
    public static class TaskExtensions
    {
        public static async void RunInSandbox(Task task)
        {
            try
            {
                await Task.Yield();

                await task.ConfigureAwait(false);
            }
            catch(Exception genericEx)
            {
                if (genericEx.GetType() != typeof(NoInternetException)
                    &&
                    genericEx.GetType() != typeof(OperationCanceledException))
                {
                    var logger = TypeLocator.Resolve<ILogger>();

                    logger.LogException(genericEx);
                }
            }
        }

        public static async void RunInSandbox(Task task, Action<Exception> onException)
        {
            try
            {
                await Task.Yield();

                await task.ConfigureAwait(false);
            }
            catch (Exception exception)
            {
                onException.Invoke(exception);
            }
        }
    }
}