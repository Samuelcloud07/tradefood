﻿namespace TradeFood.Views
{
    public partial class FinancesPage : BasePage
    {
        public FinancesPage()
        {
            InitializeComponent();
        }
    }
}