﻿using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Services
{
    public interface IGrainsService
    {
        Task<GrainData> GetGrainsQuotationAsync();
    }
}