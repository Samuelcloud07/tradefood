﻿using SQLite;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Extensions;
using TradeFood.Models;

namespace TradeFood.Repositories
{
    public class AgroNewsRepository : BaseSQLiteRepository<NewsReport>, IAgroNewsRepository
    {
        private readonly ISQLiteAdapter _adapter;

        public AgroNewsRepository(ISQLiteAdapter adapter)
            : base(adapter)
        {
            _adapter = adapter;
        }

        public async Task<List<NewsReport>> GetAgroNewsAsync()
        {
            var agroNews = await _adapter.Connection.Table<NewsReport>()
                                                .ToListAsync()
                                                .ConfigureAwait(false);

            return agroNews;
        }

        public async Task<List<NewsReport>> PersistAgroNewsAsync(IEnumerable<NewsReport> agroNews)
        {
            await _adapter.Connection.RunInTransactionAsync(
                (SQLiteConnection conn) =>
                {
                    List<NewsReport> newsAlreadySaved = new List<NewsReport>();
                    newsAlreadySaved = conn.Table<NewsReport>().ToList();

                    IEnumerable<NewsReport> newsToSave = Enumerable.Empty<NewsReport>();

                     newsToSave = agroNews.Where(an => !newsAlreadySaved.Any(ans => ans.Url != an.Url));

                    //if (!newsToSave.IsNullOrEmpty())
                    //conn.InsertAll(agroNews, true);

                    if (!newsToSave.IsNullOrEmpty())
                    {
                        int id = newsAlreadySaved.Count;
                        foreach (var item in newsToSave)
                        {
                            conn.InsertOrReplace(new NewsReport
                            {
                                Id = id,
                                Url = item.Url,
                                Header = item.Header,
                                Image = item.Image,
                                Description = item.Description
                            });
                            id++;
                        }
                    }
                }).ConfigureAwait(false);

            return new List<NewsReport>(agroNews);
        }
    }
}