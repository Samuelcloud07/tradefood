﻿namespace TradeFood.Models
{
    public class RegisterSuccess
    {
        public string Title { get; set; }

        public string Content { get; set; }

        public string Image { get; set; }
    }
}