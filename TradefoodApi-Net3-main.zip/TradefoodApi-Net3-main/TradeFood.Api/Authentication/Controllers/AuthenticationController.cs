﻿using Authentication.Models.Dtos;
using Authentication.Services;
using Common.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace Authentication.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : BaseController
    {
        private readonly IAuthenticationService _authenticationService;

        public AuthenticationController(ILogger<BaseController> logger,
                              IAuthenticationService authenticationService)
            : base(logger)
        {
            _authenticationService = authenticationService;
        }

        [HttpGet("planets")]
        [ProducesResponseType(typeof(List<PlanetDto>), (int)HttpStatusCode.OK)]
        public Task<IActionResult> GetPlanets()
        {
            return ExecuteAsync(() => _authenticationService.GetPlanetsAsync());
        }
    }
}