﻿using TradeFood.ViewModels;
using TradeFood.Views.Templates;
using Xamarin.Forms;

namespace TradeFood.Views.DataTemplateSelectors
{
    public class InquirieTemplateSelector : DataTemplateSelector
    {
        private DataTemplate _chatBotPost;

        private DataTemplate _userPost;

        public InquirieTemplateSelector()
        {
            _chatBotPost = new DataTemplate(typeof(ChatBotTemplate));

            _userPost = new DataTemplate(typeof(UserQueryTemplate));
        }

        protected override DataTemplate OnSelectTemplate(object item, BindableObject container)
        {
            if (!(item is InquirieItemViewModel inquirieItem))
                return null;

            return inquirieItem.IsUserPost ? _userPost : _chatBotPost;
        }
    }
}