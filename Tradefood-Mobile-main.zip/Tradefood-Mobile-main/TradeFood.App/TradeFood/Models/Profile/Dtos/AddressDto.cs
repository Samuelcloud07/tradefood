﻿using TradeFood.Enums;
using TradeFood.Settings;

namespace TradeFood.Models.Profile.Dtos
{
    public class AddressDto
    {
        private readonly IAppSettings _appSettings;
        public AddressDto()
        {
            _appSettings = TypeLocator.Resolve<IAppSettings>();
        }

        public AddressDto(AddressDto add ,TypeSocieties type) : this()
        {
            Id = add.Id;
            State = add.State;
            Location = add.Location;
            Street = add.Street;
            Number = add.Number;
            WithoutNumber = add.WithoutNumber;
            ZipCode = add.ZipCode;
            FloorDepartment = add.FloorDepartment;
            Observations = add.Observations;
            Type = type;
        }

        public long Id { get; set; }
        public TypeSocieties Type { get; set; }
        public string State { get; set; }

        public string Location { get; set; }

        public string Street { get; set; }

        public int? Number { get; set; }
        public bool WithoutNumber { get; set; }

        public string ZipCode { get; set; }
        public string FloorDepartment { get; set; }
        public string Observations { get; set; }
        public bool ObservationsValidate => !string.IsNullOrEmpty(Observations);
        public string FullAddress => $"{Street} {Number} {FloorDepartment}, {Location}-{State} ({ZipCode})";

        public string AddressLabel
        {
            get
            {
                switch (_appSettings.ClientType)
                {
                    case "Productor_Persona":
                        if (Type == TypeSocieties.PersonaFisica)
                            return "Domicilio de la persona fisica:";
                        else
                            return "Domicilio de la sociedad:";
                    case "Productor_Empresa":
                        return "Domicilio de la sociedad:";
                    case "Comisionista":
                        if (Type == TypeSocieties.PersonaFisica)
                            return "Domicilio de la persona fisica:";
                        else
                            return "Domicilio de la sociedad:";
                    case "Consignataria":
                        return "Domicilio de la sociedad:";
                    case "Frigorífico":
                        if (Type == TypeSocieties.RazonMatarife)
                            return "Domicilio de establicimiento faenador:";
                        else
                            return "Domicilio de la sociedad:";
                    default: return "";
                }
            }
        }
    }
}
