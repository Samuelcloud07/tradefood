﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using TradeFood.Enums;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Newtonsoft.Json;

namespace TradeFood.Services.Loggin
{
    public class Logger : ILogger
    {
        private readonly IAppState _appState;

        public Logger()
        {
            _appState = TypeLocator.Resolve<IAppState>();
        }

        public void LogEvent(AppLogLevel level, string message)
        {
            if (_appState.GetAppLogLevel() <= level)
            {
                try
                {
                    Analytics.TrackEvent($"{level}: {message}",
                        new Dictionary<string, string>() { { "InstallId", _appState.GetInstallId().ToString() } });
                }
                catch(Exception ex)
                {
                    Debug.WriteLine($"{ex.Message} - {ex}");
                }
            }
        }

        public void LogEvent(AppLogLevel level, string message, Dictionary<string, string> dict)
        {
            if (_appState.GetAppLogLevel() <= level)
            {
                dict.Add("InstallId", _appState.GetInstallId().ToString());
                Analytics.TrackEvent($"{level}: {message}", dict);
            }
        }

        public void LogException(Exception ex, object data = null, Dictionary<string, string> dict = null)
        {
            if (data != null)
            {
                var attachments = new ErrorAttachmentLog[]
                {
                    ErrorAttachmentLog.AttachmentWithText("innerExceptionData", JsonConvert.SerializeObject(data)),
                };

                Crashes.TrackError(ex, properties: dict, attachments: attachments);
            }
            else
                Crashes.TrackError(ex, dict);
        }
    }
}