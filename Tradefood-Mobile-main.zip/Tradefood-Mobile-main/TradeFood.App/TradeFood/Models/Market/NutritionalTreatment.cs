﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market
{
    public class NutritionalTreatment
    {
        public string TreatmentType { get; set; }
        public int Days { get; set; }
    }
}
