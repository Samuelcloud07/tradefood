﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Web;
using TradeFood.Commands;
using TradeFood.Enums;
using TradeFood.Models;
using TradeFood.Services.Loggin;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class RegisterSuccessViewModel : BaseViewModel, IQueryAttributable
    {
        private LoginResponse _succesData;

        public RegisterSuccessViewModel(ILogger logger)
            : base(logger)
        {
            GoBackCommand = new SandboxedCommand(GoBack);
        }

        public void ApplyQueryAttributes(IDictionary<string, string> query)
        {
            _succesData = JsonConvert.DeserializeObject<LoginResponse>(HttpUtility.UrlDecode(query["succesData"]));
        }

        protected override Task InitializeAsync()
        {
            switch (_succesData.ProfileType)
            {
                case ClientType.Frigorífico:
                    ProfileSuccessList = new ObservableCollection<RegisterSuccess>
                    {
                        new RegisterSuccess
                        {
                            Title = "Cargá tus preferencias de compra",
                            Content = "Dentro de tu perfil, completa con tus intereses y preferencias de compra, así podremos ofrecerte las tropas que mejor se adecúen a tus intereses",
                            Image = "information.png"
                        },
                        new RegisterSuccess
                        {
                            Title = "Recibí ofertas inmediatamente",
                            Content = "En función a tus indicaciones, recibí ofertas al instante, con prenegocios que se adecúen a las preferencias que determinaste",
                            Image = "notifications.png"
                        },
                        new RegisterSuccess
                        {
                            Title = "Comprá tropas ofrecidas",
                            Content = "Una vez que encuentres tu oferta ideal, podrás comprarla a través de la app, de una forma segura",
                            Image = "shopping.png"
                        }
                    };

                    break;

                case ClientType.Productor_Persona:
                case ClientType.Productor_Empresa:
                case ClientType.Comisionista:
                case ClientType.Consignataria:
                    ProfileSuccessList = new ObservableCollection<RegisterSuccess>
                    {
                        new RegisterSuccess
                        {
                            Title = "Cargá tus tropas",
                            Content = "Completa con todos los datos de tu tropa, adjuntando evidencia en video sobre ella, para publicar tu prenegocio",
                            Image = "video_calling.png"
                        },
                        new RegisterSuccess
                        {
                            Title = "Publicá tus prenegocios",
                            Content = "Publica tus prenegocios, los cuales alcanzarán a miles de compradores dentro de la app, dispuestos a ofertar inmediatamente por ellas ",
                            Image = "shopping.png"
                        },
                        new RegisterSuccess
                        {
                            Title = "Vendé tus tropas",
                            Content = "Vende las tropas publicadas cuando recibas una oferta que se ajuste a tus intereses",
                            Image = "wallet.png"
                        }
                    };
                    break;
            }

            return base.InitializeAsync();
        }

        // Properties
        public ObservableCollection<RegisterSuccess> ProfileSuccessList { get; private set; } = new ObservableCollection<RegisterSuccess>();

        private int _position;
        public int Position
        {
            get => _position;
            set
            {
                _position = value;

                this.OnPropertyChanged(nameof(Position));

                if (_position == 2)
                    CompleteVisible = true;

                this.OnPropertyChanged(nameof(CompleteVisible));
            }
        }

        public bool CompleteVisible { get; set; }

        // Commands
        public SandboxedCommand GoBackCommand { get; private set; }

        // Methods
        private async Task GoBack() => await Shell.Current.Navigation.PopToRootAsync();
    }
}