﻿using Xamarin.Forms;

namespace TradeFood.Effects
{
    public class RemoveEntryBordersEffect : RoutingEffect
    {
        public RemoveEntryBordersEffect()
            : base("TradeFood.RemoveEntryBordersEffect")
        {
        }
    }
}