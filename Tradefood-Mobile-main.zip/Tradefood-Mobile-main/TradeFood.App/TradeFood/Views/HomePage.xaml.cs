﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Repositories;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels;
using TradeFood.ViewModels.Base;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.Views
{
    public partial class HomePage : BasePage
    {
        private HomeViewModel _vm;

        public HomePage()
        {
            InitializeComponent();

            _vm = new HomeViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<ILiniersService>(),
                TypeLocator.Resolve<IDollarService>(),
                TypeLocator.Resolve<IGrainsService>(),
                TypeLocator.Resolve<IWheaterService>(),
                TypeLocator.Resolve<IAgroNewsService>(),
                TypeLocator.Resolve<IAgroNewsRepository>(),
                TypeLocator.Resolve<IAppSettings>(),
                TypeLocator.Resolve<IDialogsHelper>());

            this.BindingContext = _vm;

            if (DeviceInfo.Platform == DevicePlatform.Android || DeviceInfo.Platform == DevicePlatform.iOS)
            {
                var weather = new ToolbarItem
                {
                    IconImageSource = "ic_weather",
                    Priority = 1,
                    Order = ToolbarItemOrder.Primary,
                    Command = _vm.ShowWheaterCommand
                };

                var notification = new ToolbarItem
                {
                    IconImageSource = "ic_notification",
                    Priority = 1,
                    Order = ToolbarItemOrder.Primary
                };

                var chat = new ToolbarItem
                {
                    IconImageSource = "ic_chat",
                    Priority = 1,
                    Order = ToolbarItemOrder.Primary,
                    Command = _vm.OpenChatbotCommand
                };

                this.ToolbarItems.Add(weather);
                this.ToolbarItems.Add(notification);
                this.ToolbarItems.Add(chat);
            }
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            if (DeviceInfo.Platform == DevicePlatform.UWP)
            {
                MainThread.InvokeOnMainThreadAsync(async () =>
                {
                    Shell.SetNavBarIsVisible(this, true);

                    await Task.Delay(100);

                    Shell.SetNavBarIsVisible(this, false);
                });
            }
        }
    }
}