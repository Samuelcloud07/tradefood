﻿using System;
using System.Threading.Tasks;

namespace TradeFood.Helpers
{
    public interface IDialogsHelper
    {
        void ShowDialog();

        void ShowDialog(string text);

        void HideDialog();

        IDisposable ShowAlert(string message, string title = null);

        Task ShowAlertAsync(string message, string title = null);

        Task<bool> ShowConfirmAsync(string message);
        Task<bool> ShowConfirmAsync(string message, string title);
    }
}