﻿using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Services.Loggin;
using TradeFood.Views;
using TradeFood.Settings;
using Xamarin.Forms;
using TradeFood.Services;

namespace TradeFood.ViewModels.Profile
{
    class ProfileViewModel : BaseViewModel
    {
        private readonly IAppSettings _appSettings;
        private readonly IProfileService _profileService;

        public ProfileViewModel(ILogger logger,
                                IAppSettings appSettings,
                                IProfileService profileService)
            : base(logger)
        {
            _appSettings = appSettings;

            _profileService = profileService;

            GoToDataCommand = new SandboxedCommand(GoToData);

            GoToPreferencesCommand = new SandboxedCommand(GoToPreferences);

            GoToSettingsCommand = new SandboxedCommand(GoToSettings);
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            UserName = _appSettings.UserName;

            ClientType = _appSettings.ClientType;

            PhoneNumber = _appSettings.PhoneNumber;

            Email = _appSettings.UserEmail;

            Location = $"{_appSettings.Location},{_appSettings.State}";

            UserId = _appSettings.UserId;

            ClientType = _appSettings.ClientType;
        }

        // Properties
        public string UserId { get; private set; }

        public string UserName { get; private set; }

        public string PhoneNumber { get; private set; }

        public string Email { get; private set; }

        public string Location { get; private set; }

        public string ClientType { get; private set; }

        //Commands
        public SandboxedCommand GoToDataCommand { get; private set; }

        public SandboxedCommand GoToPreferencesCommand { get; private set; }

        public SandboxedCommand GoToSettingsCommand { get; private set; }

        //Methods 
        public async Task GoToData() => await Shell.Current.GoToAsync(nameof(ProfileDataPage));

        public async Task GoToPreferences()
        {
            var preferences = await _profileService.GetProfilePreferences(long.Parse(_appSettings.UserId));

            if (preferences == null)
                await Shell.Current.GoToAsync(nameof(ProfilePreferencesEmptyPage));
            else
                await Shell.Current.GoToAsync(nameof(ProfilePreferencesCompletePage));

        }

        //public async Task GoToPreferences() => await Shell.Current.GoToAsync(nameof(ProfilePreferencesCompletePage));

        public async Task GoToSettings() => await Shell.Current.GoToAsync(nameof(SettingsPage));
    }
}