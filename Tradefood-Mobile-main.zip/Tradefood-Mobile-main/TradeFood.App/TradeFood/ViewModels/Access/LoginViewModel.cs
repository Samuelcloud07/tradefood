﻿using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using Xamarin.Forms;
using TradeFood.Views;
using TradeFood.Services;
using TradeFood.Resources;
using TradeFood.Models;

namespace TradeFood.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        public LoginViewModel(ILogger logger,
                              IAuthenticationService authenticationService,
                              IAppSettings appSettings,
                              IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _authenticationService = authenticationService;
            _appSettings = appSettings;
            _dialogsHelper = dialogsHelper;

            LoginCommand = new SandboxedCommand(Login);

            RegisterCommand = new SandboxedCommand(Register);

            RecoverPasswordCommand = new SandboxedCommand(RecoverPassword);
        }

        // Properties
        public string IdNumber { get; set; }

        public string Password { get; set; }

        // Commands
        public SandboxedCommand LoginCommand { get; private set; }

        public SandboxedCommand RegisterCommand { get; private set; }

        public SandboxedCommand RecoverPasswordCommand { get; private set; }

        // Methods
        private async Task Login()
        {
            if (string.IsNullOrEmpty(IdNumber) || string.IsNullOrEmpty(Password))
            {
                _dialogsHelper.ShowAlert(Strings.YouMustCompleteAllTheFields);

                return;
            }

            _dialogsHelper.ShowDialog();

            var signIn = new SignIn
            {
                IdIssued = long.Parse(IdNumber),
                Password = Password
            };

            var loginResponse = await _authenticationService.LoginAsync(signIn);

            _dialogsHelper.HideDialog();

            _appSettings.IsLoggedIn = true;

            // Send message to AppShell
            MessagingCenter.Send<BaseViewModel>(this, "LoginCompleted");

            if (loginResponse.ProfileType == Enums.ClientType.Administrador)
            {
                _appSettings.IsAdmin = true;

                Application.Current.MainPage = new NavigationPage(new AdministratorMainPage());
            }
            else
                await Shell.Current.GoToAsync("//home");
        }

        private async Task Register() => await Shell.Current.GoToAsync(nameof(RegisterPage));

        private async Task RecoverPassword() => await Shell.Current.GoToAsync("ForgetPassword");
    }
}