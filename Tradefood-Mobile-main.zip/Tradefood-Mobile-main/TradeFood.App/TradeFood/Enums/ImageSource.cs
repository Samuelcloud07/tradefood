﻿namespace TradeFood.Enums
{
    public enum ImageSource
    {
        Camera,
        Gallery,
        VideoGallery
    }
}