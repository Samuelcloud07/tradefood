﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Repositories
{
    public interface IAgroNewsRepository : ISQLiteRepository<NewsReport>
    {
        Task<List<NewsReport>> GetAgroNewsAsync();

        Task<List<NewsReport>> PersistAgroNewsAsync(IEnumerable<NewsReport> agroNews);
    }
}