﻿using System;
using TradeFood.Extensions;

namespace TradeFood.Commands
{
    internal sealed class DelegateCommand : IDelegateCommand
    {
        private readonly Func<bool> _canExecute;
        private readonly Action _execute;

        public DelegateCommand(Action execute)
            : this(execute, null)
        {
        }

        public DelegateCommand(Action execute, Func<bool> canExecute)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter) => _canExecute == null || _canExecute();

        public bool CanExecute() => CanExecute(null);

        public void Execute(object parameter)
        {
            if (CanExecute(parameter))
                _execute();
        }

        public void Execute() => Execute(null);

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    internal sealed class DelegateCommand<T> : IDelegateCommand, IDelegateCommand<T>
    {
        private readonly Func<T, bool> _canExecute;
        private readonly Action<T> _execute;

        public DelegateCommand(Action<T> execute)
            : this(execute, null)
        {
        }

        public DelegateCommand(Action<T> execute, Func<T, bool> canExecute)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter) => _canExecute == null || _canExecute((T)typeof(T).MakeSafeValueCore(parameter));

        public bool CanExecute() => CanExecute(null);

        public bool CanExecute(T parameter) => _canExecute == null || _canExecute(parameter);

        public void Execute(object parameter)
        {
            if (!CanExecute(parameter))
                return;

            _execute((T)typeof(T).MakeSafeValueCore(parameter));
        }

        public void Execute() => Execute(null);

        public void Execute(T parameter)
        {
            if (!CanExecute(parameter))
                return;

            _execute(parameter);
        }

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}