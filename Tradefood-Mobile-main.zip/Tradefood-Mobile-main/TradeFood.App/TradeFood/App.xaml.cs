﻿using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Microsoft.AppCenter.Distribute;
using System.Globalization;
using TradeFood.Enums;
using TradeFood.Helpers;
using TradeFood.Services.Loggin;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood
{
    public partial class App : Application
    {
        private IAppState _appState;

        public App()
        {
            // Set the actual language
            LocalizationResourceManagerHelper.Instance.SetCulture(new CultureInfo("es"));

            TypeLocator.Start();

            VersionTracking.Track();

            InitializeComponent();

            _appState = TypeLocator.Resolve<IAppState>();

            _appState.Init();

            MainPage = new AppShell();
        }

        protected override void OnStart()
        {
#if DEBUG
            _appState.SetAppLogLevel(AppLogLevel.Verbose);
#else
            AppCenter.Start("android=03b79243-150a-4ed6-bcd8-c958ba334c1a;"
                            + "ios=19eeb004-1422-49f7-b1c8-e4c1f8302d22;"
                            + "uwp=ae94b3e5-45ec-4d67-ad1c-145dbb1998b3;",
                            typeof(Analytics), typeof(Crashes), typeof(Distribute));

            _appState.SetAppLogLevel(AppLogLevel.Info);

            AppCenter.SetUserId(_appState.GetInstallId().ToString());
#endif
        }

        protected override void OnSleep()
        {
            base.OnSleep();
        }

        protected override void OnResume()
        {
            base.OnResume();
        }
    }
}