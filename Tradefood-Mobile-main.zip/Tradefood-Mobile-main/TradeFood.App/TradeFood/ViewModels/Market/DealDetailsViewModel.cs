﻿using Acr.UserDialogs;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels.Base;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class DealDetailsViewModel : BaseViewModel, IQueryAttributable
    {
        private readonly IAppSettings _appSettings;
        private readonly IUserDialogs _userDialogs;
        private readonly IDialogsHelper _dialogsHelper;

        private Interaction _diplayVideoFromSourceInteraction = new Interaction();

        public DealDetailsViewModel(ILogger logger,
                                    IAppSettings appSettings,
                                    IUserDialogs userDialogs,
                                    IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _appSettings = appSettings;
            _userDialogs = userDialogs;
            _dialogsHelper = dialogsHelper;

            GoBackCommand = new SandboxedCommand(GoBack);

            RequestPriceCommand = new SandboxedCommand(RequestPrice);

            ChangeMainEvidenceCommand = new SandboxedCommand(ChangeMainEvidence);
        }

        public void ApplyQueryAttributes(IDictionary<string, string> query)
        {
            Deal = JsonConvert.DeserializeObject<Deal>(HttpUtility.UrlDecode(query["dealDetails"]));

            MainEvidenceFile = Deal.EvidenceFiles.FirstOrDefault().FilePath;

            if (Deal.CreatedBy == _appSettings.UserId)
            {
                Title = "Tu prenegocio";
                DealBidderVisible = true;
                PriceVisible = true;
            }
            else
            {
                Title = "Prenegocio disponible";
                RequestPriceVisible = true;
                PriceVisible = false;
                DealBidderVisible = false;
            }
        }

        // Properties
        public string Title { get; private set; }

        public Deal Deal { get; private set; }

        public File FileSelected { get; set; }

        public string MainEvidenceFile { get; private set; }

        public int Position { get; set; }

        public bool RequestPriceVisible { get; private set; }

        public bool BidVisible { get; private set; }

        public bool DealBidderVisible { get; private set; }

        public bool PriceVisible { get; private set; }

        public IInteraction DiplayVideoFromSourceInteraction => _diplayVideoFromSourceInteraction;

        // Commands
        public SandboxedCommand GoBackCommand { get; private set; }

        public SandboxedCommand RequestPriceCommand { get; private set; }

        public SandboxedCommand ChangeMainEvidenceCommand { get; private set; }

        // Methods
        private async Task RequestPrice()
        {
            var confirmConfig = new ConfirmConfig()
                .SetTitle("¡Estas a un paso de comprar tu nueva tropa!")
                .SetMessage($"En unos minutos recibirás la cotización solicitada sobre el Prenegocio #{Deal.DealId}")
                .SetOkText("Aceptar")
                .SetCancelText("Cancelar");

            if (!await _userDialogs.ConfirmAsync(confirmConfig))
                return;

            _dialogsHelper.ShowDialog();

            RequestPriceVisible = false;

            BidVisible = true;

            PriceVisible = true;

            _dialogsHelper.HideDialog();
        }

        private async Task ChangeMainEvidence()
        {
            await MainThread.InvokeOnMainThreadAsync(() =>
            {
                if (FileSelected != null)
                    MainEvidenceFile = FileSelected.FilePath;

                this.OnPropertyChanged(nameof(MainEvidenceFile));

                _diplayVideoFromSourceInteraction.Raise();
            });

            FileSelected = null;
        }

        private async Task GoBack() => await Shell.Current.GoToAsync("..");
    }
}