﻿using Acr.UserDialogs;
using Newtonsoft.Json;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models.Market;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels.Base;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class NewPublishSecondStepViewModel : BaseViewModel, IQueryAttributable
    {

        private readonly IDealsService _dealsService;
        private readonly IStatesService _statesService;
        private readonly IMediaHelper _mediaHelper;
        private readonly IDialogsHelper _dialogsHelper;
        private readonly IAppSettings _appSettings;
        private readonly IUserDialogs _userDialogs;
        private readonly IProfileService _profileService;
        private readonly List<string> _dirtyZones = new List<string> {
            "Entre Ríos", "Santa Fe",
            "Chaco", "Corrientes",
            "Formosa", "Misiones",
            "Catamarca", "Jujuy",
            "La Rioja", "Salta",
            "Santiago Del Estero",
            "Tucumán", "Mendoza",
            "San Juan", "San Luis"
        };

        public SelectAddresOrCreate _addressPopup;
        public AddPersonOrSocietyPopupPage _societiesPopup;

        private Interaction _forceExpanderUpdateInteraction = new Interaction();
        public NewPublishSecondStepViewModel(ILogger logger,
                                   IDealsService dealsService,
                                   IStatesService statesService,
                                   IMediaHelper mediaHelper,
                                   IDialogsHelper dialogsHelper,
                                   IAppSettings appSettings,
                                   IUserDialogs userDialogs,
                                   IProfileService profileService)
            : base(logger)
        {
            _dealsService = dealsService;
            _statesService = statesService;
            _mediaHelper = mediaHelper;
            _dialogsHelper = dialogsHelper;
            _appSettings = appSettings;
            _userDialogs = userDialogs;
            _profileService = profileService;

            //DisplayName = _appSettings.UserName;
            CancelPublishCommand = new SandboxedCommand(CancelPublish);
            GoToThirdStepCommand = new SandboxedCommand(GoToThirdStep);
            SelectPersonOrSocietyCommand = new SandboxedCommand(SelectPersonOrSociety);
            SelectAddressCommand = new SandboxedCommand(SelectAddress);
        }

        public void ApplyQueryAttributes(IDictionary<string, string> query)
        {
            TroopDetails=JsonConvert.DeserializeObject<TroopDetails>(HttpUtility.UrlDecode(query["troopDetails"]));
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();           

            TroopCategorySelected = TroopDetails.BusinessType;

            switch (TroopCategorySelected)
            {
                case "Cria":
                    FinancingCategories = new ObservableCollection<string>
                        {
                            "Sin plazos"
                        };
                    break;

                case "Invernada":
                    FinancingCategories = new ObservableCollection<string>
                        {
                            "Contado",
                            "30 - 60 días",
                            "0 - 30 - 60 días",
                            "30 días",
                            "45 días",
                            "30 - 60 - 90 días",
                            "Otros"
                        };
                    break;

                case "Faena":
                    FinancingCategories = new ObservableCollection<string>
                        {
                            "Contado",
                            "7 días",
                            "15 días",
                            "21 días",
                            "30 días"
                        };
                    break;
            }

            await RefreshSocietiesAndPersons();
        }

        //Properties

        public ObservableCollection<SocietyOrPersonItemViewModel> SocietiesAndPersons { get; set; } = new ObservableCollection<SocietyOrPersonItemViewModel>();
        public ObservableCollection<AddressItemViewModel> Addresses { get; set; } = new ObservableCollection<AddressItemViewModel>();
        public string SuggestedPrice { get; set; }
        public string PersonOrSociety { get; set; }
        public string TroopLocation { get; set; }
        public string TroopCategorySelected { get; set; }
        public string _addressSelected = "Ubicación de tu tropa";
        public string AddressSelected
        {
            get => _addressSelected;
            set
            {
                _addressSelected = value;
                this.OnPropertyChanged(nameof(AddressSelected));

                if (TroopCategorySelected == "Invernada")
                {
                    var province = _addressSelected.Split(',')[1].Split('(')[0].Trim();
                    IsDirtyZone = _dirtyZones.Contains(province);
                    IsDirty = false;
                    IsMioMio = false;
                    IsTick = false;
                    CleanZoneSelected = false;
                    DirtyZoneSelected = false;
                    ZoneSelected = String.Empty;
                }


            }
        }
        public long AddressSelectedId { get; set; }
        public string Province { get; set; }
        public string Location { get; set; }
        public bool CleanZoneSelected { get; set; }
        public bool DirtyZoneSelected { get; set; }
        public string SocietyOrPersonSelected { get; set; } = "Sociedad o Persona física";
        public long SocietyOrPersonSelectedId { get; set; }
        public bool IsDirtyZone { get; set; }

        public string _zoneSelected;
        public string ZoneSelected
        {
            get => _zoneSelected;
            set
            {
                _zoneSelected = value;
                this.OnPropertyChanged(nameof(ZoneSelected));

                IsDirty = _zoneSelected.Equals("Sucia");
            }
        }
        public bool IsDirty { get; set; }
        public bool IsMioMio { get; set; }
        public bool IsTick { get; set; }
        public string Comments { get; set; }
        public string Street { get; set; }
        public int Number { get; set; }

        public ObservableCollection<string> FinancingCategories { get; private set; }
        private string _financingCategorySelected;
        public string FinancingCategorySelected
        {
            get => _financingCategorySelected;
            set
            {
                _financingCategorySelected = value;

                this.OnPropertyChanged(nameof(FinancingCategorySelected));


                if (_financingCategorySelected == "Otros")
                {
                    OtherFinancingCategorySelected = true;
                }
                else
                {
                    OtherFinancingCategorySelected = false;
                    FirstAnotherTerm = string.Empty;
                    SecondAnotherTerm = string.Empty;
                }


                _forceExpanderUpdateInteraction.Raise();

                this.OnPropertyChanged(nameof(OtherFinancingCategorySelected));
            }
        }
        public string PaymentMethodSelected { get; set; }
        public bool OtherFinancingCategorySelected { get; private set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public bool SecondSectionCompleted { get; set; }

        public string FirstAnotherTerm { get; set; }

        public string SecondAnotherTerm { get; set; }

        public string HeadOfPrebusiness { get; set; }

        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();
        public bool HasErrors { get; set; }

        public SandboxedCommand CancelPublishCommand { get; private set; }
        public SandboxedCommand GoToThirdStepCommand { get; private set; }
        public SandboxedCommand SelectPersonOrSocietyCommand { get; private set; }
        public SandboxedCommand SelectAddressCommand { get; private set; }
        public TroopDetails TroopDetails { get; set; }

        //Methods

        public async Task RefreshSocietiesAndPersons()
        {
            _dialogsHelper.ShowDialog();
            List<SocietiesAndPersonDto> societies = await _profileService.GetSocietiesAndPersonsAsync(long.Parse(_appSettings.UserId));
            SocietiesAndPersons.Clear();

            SocietiesAndPersons.Add(new SocietyOrPersonItemViewModel()
            {
                id = 0,
                Name = _appSettings.UserName,
                Type = (Enums.TypeSocieties)3,
            });

            foreach (var item in societies)
            {
                SocietiesAndPersons.Add(new SocietyOrPersonItemViewModel
                {
                    id = item.id,
                    Name = item.Name,
                    Type = item.Type,
                });
            }

            List<AddressDto> addresses = await _profileService.GetAllAddressesAsync(long.Parse(_appSettings.UserId));
            Addresses.Clear();

            foreach (var item in addresses)
                Addresses.Add(new AddressItemViewModel(item.Id, item.Street, item.Number.ToString(), item.Location, item.State, item.ZipCode));

            this.OnPropertyChanged(nameof(SocietiesAndPersons));
            _dialogsHelper.HideDialog();
        }

        private bool ValidateAll()
        {
            Errors.Clear();

            if (string.IsNullOrEmpty(SocietyOrPersonSelectedId.ToString()))
                Errors.Add(nameof(SocietyOrPersonSelected), "Debe seleccionar una opcion");

            if (string.IsNullOrEmpty(AddressSelectedId.ToString()))
                Errors.Add(nameof(AddressSelected), "Debe seleccionar una opcion");

            if (string.IsNullOrEmpty(SuggestedPrice) || SuggestedPrice == "0")
                Errors.Add(nameof(SuggestedPrice), "Debe especificar un valor mayor que 0");

            if (FinancingCategorySelected == null)
                Errors.Add(nameof(FinancingCategorySelected), "Debe seleccionar una opcion");

            if (PaymentMethodSelected == null)
                Errors.Add(nameof(PaymentMethodSelected), "Debe seleccionar una opcion");

            if (HeadOfPrebusiness == null)
                Errors.Add(nameof(HeadOfPrebusiness), "Debe seleccionar una opcion");

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }

        private async Task CancelPublish()
        {
            if (!await _dialogsHelper.ShowConfirmAsync("¿Está seguro que quiere cancelar la creación del prenegocio?"))
                return;

            await Shell.Current.GoToAsync("..");
        }

        private async Task GoToThirdStep()
        {

            if (!ValidateAll())
                return;

            if (OtherFinancingCategorySelected)
                FinancingCategorySelected = $"{FirstAnotherTerm} - {SecondAnotherTerm} días";

            PreDealDetail preDealDetails = new PreDealDetail
            {
                SuggestedPrice = SuggestedPrice,
                SocietyOrPerson = new SocietiesAndPerson {
                    Id = SocietyOrPersonSelectedId,
                    Name=SocietyOrPersonSelected
                },
                TroopLocation = new Address {
                   Id=AddressSelectedId,
                   State=Province,
                   Location=Location,
                   Street=Street
                },
                Province = Province,
                Location = Location,
                IsDirty = IsDirty,
                IsMioMio = IsMioMio,
                IsTick = IsTick,
                Comments = Comments,
                PaymentTerms = FinancingCategorySelected,
                PaymentMethod = PaymentMethodSelected,
                HeadOfPreBusiness = HeadOfPrebusiness

            };

            string serializedTroopDetails = JsonConvert.SerializeObject(TroopDetails);
            string serializedPreDealDetails = JsonConvert.SerializeObject(preDealDetails);

            await Shell.Current.GoToAsync($"NewPublishThirdStepPage?troopDetails={serializedTroopDetails}&preDealDetails={serializedPreDealDetails}");
        }

        public override void OnAppearing()
        {
            base.OnAppearing();
        }

        private async Task SelectPersonOrSociety()
        {
            
            _societiesPopup = new AddPersonOrSocietyPopupPage(SocietiesAndPersons);

            _societiesPopup.DataEventHandler += (popupsender, socandper) =>
            {
                SocietiesAndPerson obj = JsonConvert.DeserializeObject<SocietiesAndPerson>(socandper);

                SocietyOrPersonSelected = obj.Name;
                SocietyOrPersonSelectedId = obj.Id;
            };
            await PopupNavigation.Instance.PushAsync(_societiesPopup);
            await RefreshSocietiesAndPersons();
        }

        private async Task SelectAddress()
        {

            _addressPopup = new SelectAddresOrCreate(Addresses);

            _addressPopup.DataEventHandler += (popupsender, address) =>
            {
                Address add = JsonConvert.DeserializeObject<Address>(address);

                AddressSelectedId = add.Id;
                Province = add.State;
                Location = add.Location;
                Street = add.Street;
                Number = add.Number;
                AddressSelected = add.Street.Replace("\n", " - ");
            };

            await PopupNavigation.Instance.PushAsync(_addressPopup);
            await RefreshSocietiesAndPersons();
        }
    }
}
