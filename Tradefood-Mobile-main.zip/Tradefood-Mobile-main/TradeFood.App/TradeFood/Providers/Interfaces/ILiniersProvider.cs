﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public interface ILiniersProvider
    {
        Task<List<LiniersData>> GetCotizacionesLiniersAsync();
    }
}