﻿using Acr.UserDialogs;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System;
using System.Threading.Tasks;
using TradeFood.Enums;
using TradeFood.Resources;
using Xamarin.Essentials;

namespace TradeFood.Helpers
{
    public class MediaHelper : IMediaHelper
    {
        private readonly IUserDialogs _userDialogs;

        public MediaHelper(IUserDialogs userDialogs)
        {
            _userDialogs = userDialogs;
        }

        public Task<MediaFile> LoadImageFromSourceAsync(ImageSource source, string fileName, CameraDevice defaultCamera, PhotoSize photoSize = PhotoSize.Full, int compressionQuality = 100)
        {
            switch (source)
            {
                case ImageSource.Camera:
                    return this.TakePictureAsync(fileName, new StoreCameraMediaOptions
                    {
                        PhotoSize = photoSize,
                        CompressionQuality = compressionQuality,
                        Directory = "Evidencias_Tropas",
                        Name = $"{fileName}.jpg",
                        RotateImage = DeviceInfo.Platform == DevicePlatform.iOS,
                        DefaultCamera = defaultCamera
                    });
                case ImageSource.Gallery:
                    return this.LoadImageFromGalleryAsync(new PickMediaOptions
                    {
                        PhotoSize = photoSize,
                        CompressionQuality = compressionQuality
                    });
                case ImageSource.VideoGallery:
                    return this.LoadVideoFromGalleryAsync();
                default:
                    throw new NotImplementedException();
            }
        }

        public Task<MediaFile> RecordVideoAsync(string fileName, TimeSpan desiredLenght, VideoQuality quality = VideoQuality.High, int compressionQuality = 100)
        {
            return this.RecordNewVideoAsync(fileName, desiredLenght, quality, compressionQuality);
        }

        private async Task<MediaFile> TakePictureAsync(string fileName, StoreCameraMediaOptions customStoreCameraMediaOptions = null)
        {
            await CrossMedia.Current.Initialize();

            if (!await this.CheckCameraPermission() || !CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
            {
                _userDialogs.Alert("Lo sentimos pero la cámara no se encuentra disponible.", "Cámara no disponible", Strings.Accept);

                return null;
            }

            var storeMediaOptions = customStoreCameraMediaOptions ?? new StoreCameraMediaOptions
            {
                Directory = "Evidencias_Tropas",
                Name = $"{fileName}.jpg"
            };

            return await CrossMedia.Current.TakePhotoAsync(storeMediaOptions);
        }

        private async Task<MediaFile> LoadImageFromGalleryAsync(PickMediaOptions customPickMediaOptions = null)
        {
            await CrossMedia.Current.Initialize();

            if (!await this.CheckGalleryPermission())
            {
                _userDialogs.Alert("Galería no disponible", "Lo sentimos pero el acceso a la galería no se encuentra disponible.", Strings.Accept);

                return null;
            }

            return await CrossMedia.Current.PickPhotoAsync(customPickMediaOptions);
        }

        private async Task<MediaFile> LoadVideoFromGalleryAsync(PickMediaOptions customPickMediaOptions = null)
        {
            await CrossMedia.Current.Initialize();

            if (!await this.CheckGalleryPermission())
            {
                _userDialogs.Alert("Galería no disponible", "Lo sentimos pero el acceso a la galería no se encuentra disponible.", Strings.Accept);

                return null;
            }

            return await CrossMedia.Current.PickVideoAsync();
        }

        private async Task<MediaFile> RecordNewVideoAsync(string fileName, TimeSpan desiredLength, VideoQuality quality, int compressionQuality)
        {
            await CrossMedia.Current.Initialize();

            if (!await this.CheckCameraPermission() || !CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakeVideoSupported)
            {
                this._userDialogs.Alert("No se puede grabar video", Strings.ApplicationName, Strings.Accept);

                return null;
            }

            var storeVideoOptions = new StoreVideoOptions
            {
                CompressionQuality = compressionQuality,
                Quality = quality,
                DesiredLength = desiredLength,
                Directory = "Evidencias_Tropas",
                Name = $"{fileName}.mp4",
                RotateImage = true
            };

            return await CrossMedia.Current.TakeVideoAsync(storeVideoOptions);
        }

        private async Task<bool> CheckCameraPermission()
        {
            var cameraStatus = await Permissions.CheckStatusAsync<Permissions.Camera>();
            var storageStatus = await Permissions.CheckStatusAsync<Permissions.StorageWrite>();

            if (cameraStatus != PermissionStatus.Granted || storageStatus != PermissionStatus.Granted)
            {
                cameraStatus = await Permissions.RequestAsync<Permissions.Camera>();
                storageStatus = await Permissions.RequestAsync<Permissions.StorageWrite>();
            }

            return cameraStatus == PermissionStatus.Granted && storageStatus == PermissionStatus.Granted;
        }

        private async Task<bool> CheckGalleryPermission()
        {
            var photoStatus = await Permissions.CheckStatusAsync<Permissions.Photos>();
            var storageStatus = await Permissions.CheckStatusAsync<Permissions.StorageRead>();

            if (photoStatus != PermissionStatus.Granted || storageStatus != PermissionStatus.Granted)
            {
                photoStatus = await Permissions.RequestAsync<Permissions.Photos>();
                storageStatus = await Permissions.RequestAsync<Permissions.StorageRead>();
            }

            return photoStatus == PermissionStatus.Granted && storageStatus == PermissionStatus.Granted;
        }
    }
}