﻿using System;
using TradeFood.Helpers;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TradeFood.Extensions
{
    [ContentProperty("Text")]
    public class TranslateExtension : IMarkupExtension<BindingBase>
    {
        public string Text { get; set; }

        public string StringFormat { get; set; }

        public IValueConverter Converter { get; set; }

        object IMarkupExtension.ProvideValue(IServiceProvider serviceProvider) => ProvideValue(serviceProvider);

        public BindingBase ProvideValue(IServiceProvider serviceProvider)
        {
            var binding = new Binding
            {
                Mode = BindingMode.OneWay,
                Path = $"[{Text}]",
                Source = LocalizationResourceManagerHelper.Instance,
                StringFormat = StringFormat,
                Converter = Converter
            };

            return binding;
        }
    }
}