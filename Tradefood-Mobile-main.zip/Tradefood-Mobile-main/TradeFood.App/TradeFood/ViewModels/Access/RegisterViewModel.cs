﻿using Newtonsoft.Json;
using Rg.Plugins.Popup.Services;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Enums;
using TradeFood.Extensions;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Views;
using TradeFood.Views.Popups;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class RegisterViewModel : BaseViewModel
    {
        private readonly IStatesService _statesService;
        private readonly IAuthenticationService _authenticationService;
        private readonly IDialogsHelper _dialogsHelper;

        private List<ProvinceLocation> _locations = new List<ProvinceLocation>();

        private ClientType _selectedClientType;

        public RegisterViewModel(ILogger logger,
                                 IStatesService statesService,
                                 IAuthenticationService authenticationService,
                                 IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _statesService = statesService;
            _authenticationService = authenticationService;
            _dialogsHelper = dialogsHelper;

            SelectClientTypeCommand = new SandboxedCommand(SelectClientType);
            
            SelectProvinceCommand = new SandboxedCommand(SelectProvince);

            RegisterCommand = new SandboxedCommand(Register);

            GoBackCommand = new SandboxedCommand(GoBack);

            PickLocationCommand = new SandboxedCommand(PickLocation);

            GoToPreferencesCommand = new SandboxedCommand(GoToPreferences);
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            _dialogsHelper.ShowDialog();

            var provinces = await _statesService.GetProvincesAsync();

            Provinces.AddRange(provinces);
            
            DefaultProvinceSelected = 0;

            ClientTypes = new List<string>
            {
                "Productor Persona",
                "Productor Empresa",
                "Comisionista",
                "Consignataria",
                "Frigorífico"
            };

            DefaultClientTypeSelected = 0;

            this.OnPropertyChanged(nameof(ClientTypes));
            this.OnPropertyChanged(nameof(DefaultClientTypeSelected));
            this.OnPropertyChanged(nameof(DefaultProvinceSelected));

            _dialogsHelper.HideDialog();
        }

        // Properties
        public ObservableCollection<ProvinceLocation> Provinces { get; private set; } = new ObservableCollection<ProvinceLocation>();        

        public List<string> ClientTypes { get; private set; } = new List<string>();

        public string ClientTypeSelected { get; set; }

        public ProvinceLocation ProvinceSelected { get; set; }

        public ProvinceLocation LocationSelected { get; set; }

        public int DefaultClientTypeSelected { get; set; } = 0;

        public int DefaultProvinceSelected { get; set; } = 0;

        private string _profileTypeSelected;
        public string ProfileTypeSelected
        {
            get => _profileTypeSelected;
            set
            {
                _profileTypeSelected = value;

                this.OnPropertyChanged(nameof(ProfileTypeSelected));

                SetRegisterFormVisibilityAndClientType();
            }
        }

        public string WorkTypeSelected { get; set; }

        public string NameAndLastname { get; set; }

        public string BusinessName { get; set; }

        public string Id { get; set; }

        public string Cuit { get; set; }

        public string UserJob { get; set; }

        public string Email { get; set; }

        public string ContactNumber { get; set; }

        public string LocationTitle { get; set; }

        public string Password { get; set; }

        public bool TermsAndConditions { get; set; }

        public bool RegisterFormVisible { get; set; }

        public bool ProfileTypeVisible { get; set; }

        public bool IsCompanyRegisterVisible { get; set; }

        public bool WorkTypeVisible { get; set; }

        public bool LocationVisible { get; private set; }

        public bool HasErrors { get; set; }

        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();

        // Commands
        public SandboxedCommand SelectClientTypeCommand { get; private set; }

        public SandboxedCommand SelectProvinceCommand { get; private set; }

        public SandboxedCommand RegisterCommand { get; private set; }

        public SandboxedCommand GoToPreferencesCommand { get; private set; }

        public SandboxedCommand PickLocationCommand { get; private set; }

        public SandboxedCommand GoBackCommand { get; private set; }        

        // Methods
        private async Task GoBack() => await Shell.Current.GoToAsync("..");

        private async Task GoToPreferences() => await Shell.Current.GoToAsync("PreferencesPage");

        public async Task Register()
        {
            if (!ValidateAll())
                return;

            if (!TermsAndConditions)
            {
                _dialogsHelper.ShowAlert(Strings.YouMustAcceptTheTermsAndConditionsInOrderToContinue);

                return;
            }

            _dialogsHelper.ShowDialog();

            long? longId = null;
            long? longCuit = null;

            if (!string.IsNullOrEmpty(Id))
                longId = long.Parse(Id);

            if (!string.IsNullOrEmpty(Cuit))
                longCuit = long.Parse(Cuit);

            var signUp = new SignUp
            {
                ProfileType = _selectedClientType,
                NameAndLastname = NameAndLastname,
                BusinessName = BusinessName,
                NationalId = longId,
                Cuit = longCuit,
                UserJob = UserJob,
                Email = Email,
                PhoneNumber = ContactNumber,
                State = ProvinceSelected.Name,
                Location = LocationSelected.Name,
                Password = Password
            };

            var singUpResponse = await _authenticationService.SignUpAsync(signUp);

            var singUpResponseSerialized = JsonConvert.SerializeObject(singUpResponse);

            _dialogsHelper.HideDialog();

            await Shell.Current.GoToAsync($"/{nameof(RegisterValidationPage)}?signUpData={singUpResponseSerialized}");
        }

        private async Task SelectClientType()
        {
            await MainThread.InvokeOnMainThreadAsync(() =>
            {
                switch (ClientTypeSelected)
                {
                    case "Productor Persona":
                        _selectedClientType = ClientType.Productor_Persona;
                        ProfileTypeVisible = false;
                        RegisterFormVisible = true;
                        IsCompanyRegisterVisible = false;
                        WorkTypeVisible = false;
                        break;
                    case "Productor Empresa":
                        _selectedClientType = ClientType.Productor_Empresa;
                        ProfileTypeVisible = false;
                        RegisterFormVisible = true;
                        IsCompanyRegisterVisible = true;
                        WorkTypeVisible = false;
                        break;

                    case "Comisionista":
                        _selectedClientType = ClientType.Comisionista;
                        ProfileTypeVisible = false;
                        RegisterFormVisible = true;
                        IsCompanyRegisterVisible = false;
                        WorkTypeVisible = false;
                        break;

                    case "Frigorífico":
                        _selectedClientType = ClientType.Frigorífico;
                        ProfileTypeVisible = false;
                        RegisterFormVisible = true;
                        IsCompanyRegisterVisible = true;
                        WorkTypeVisible = true;
                        break;

                    case "Consignataria":
                        _selectedClientType = ClientType.Consignataria;
                        ProfileTypeVisible = false;
                        RegisterFormVisible = true;
                        IsCompanyRegisterVisible = true;
                        WorkTypeVisible = false;
                        break;
                }

                this.OnPropertyChanged(nameof(RegisterFormVisible));
                this.OnPropertyChanged(nameof(ProfileTypeVisible));
                this.OnPropertyChanged(nameof(IsCompanyRegisterVisible));
                this.OnPropertyChanged(nameof(WorkTypeVisible));
            });
        }

        private async Task SelectProvince()
        {
            _dialogsHelper.ShowDialog();

            _locations.Clear();

            var locations = await _statesService.GetLocationsForProvinceAsync(ProvinceSelected.Name);

            _locations.AddRange(locations);

            LocationVisible = true;

            LocationTitle = Strings.SearchLocation;

            _dialogsHelper.HideDialog();
        }

        private async Task PickLocation() => await PopupNavigation.Instance.PushAsync(new LocationPopupPage(_locations));

        private bool ValidateAll()
        {
            Errors.Clear();
            
            if (ClientTypeSelected == "Productor Persona" || ClientTypeSelected == "Comisionista")
            {
                EmptyStringValidator(NameAndLastname, nameof(NameAndLastname));
                EmptyStringValidator(Id, nameof(Id));
            }
            else
            {
                EmptyStringValidator(BusinessName, nameof(BusinessName));
                EmptyStringValidator(Cuit, nameof(Cuit));
            }

            if (!Email.IsValidEmail())
                Errors.Add(nameof(Email), Strings.TheEmailAddressIsInvalid);
            
            EmptyStringValidator(ContactNumber, nameof(ContactNumber));

            if (string.IsNullOrEmpty(Password) || !Password.IsValidPassword())
                Errors.Add(nameof(Password), Strings.MustBeAtLeastEightAlphanumericCharactersAndSymbols);

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }

        private void EmptyStringValidator(string toValidate, string resourceString)
        {
            if (string.IsNullOrEmpty(toValidate))
                Errors.Add(resourceString, string.Format(Strings.TheFieldXIsRequired, Strings.ResourceManager.GetString(resourceString)));
        }

        private void SetClientTypeSelected()
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                RegisterFormVisible = true;

                if (ClientTypeSelected == "Productor Empresa")
                    IsCompanyRegisterVisible = ProfileTypeSelected == "Empresa";

                this.OnPropertyChanged(nameof(RegisterFormVisible));
                this.OnPropertyChanged(nameof(IsCompanyRegisterVisible));
            });
        }

        private void SetRegisterFormVisibilityAndClientType()
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                RegisterFormVisible = true;

                this.OnPropertyChanged(nameof(RegisterFormVisible));
                this.OnPropertyChanged(nameof(IsCompanyRegisterVisible));
            });

            SetClientTypeSelected();
        }
    }
}