﻿using TradeFood.Helpers;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels;

namespace TradeFood.Views
{
    public partial class LoadingPage : BasePage
    {
        public LoadingPage()
        {
            InitializeComponent();

            this.BindingContext = new LoadingViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<IAppSettings>(),
                TypeLocator.Resolve<IDialogsHelper>());
        }

        protected override bool OnBackButtonPressed() => true;
    }
}