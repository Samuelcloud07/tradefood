﻿using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    class ProfilePreferencesSecondSectionViewModel : BaseViewModel
    {
        public readonly IStatesService _statesServices;
        private readonly IProfileService _profileService;
        private readonly IAppSettings _appSettings;
        public ProfilePreferencesSecondSectionViewModel(ILogger logger,
                                    IAppSettings appSettings,
                                    IProfileService profileService,
                                    IStatesService statesService)
            : base(logger)
        {

            GoBackCommand = new SandboxedCommand(GoBack);
            SavePreferencesCommand = new SandboxedCommand(SavePreferences);
            SelectProvincesCommand = new SandboxedCommand(SelectProvinces);
            SelectProvincesChoreCommand = new SandboxedCommand(SelectProvincesChore);
            SelectLocationsCommand = new SandboxedCommand(SelectLocations);

            _appSettings = appSettings;
            _profileService = profileService;
            _statesServices = statesService;
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            Provinces = await _statesServices.GetProvincesAsync();

            if (ProvincesCollection.Count == 0)
                foreach (var province in Provinces)
                {
                    ProvincesCollection.Add(new ProvinceOrLocationItemViewModel { Name = province.Name.Equals("Tierra del Fuego, Antártida e Islas del Atlántico Sur") ? "Tierra del fuego" : province.Name });
                }

            if (ProvincesCollectionChore.Count == 0)
                foreach (var province in Provinces)
                {
                    ProvincesCollectionChore.Add(new ProvinceOrLocationItemViewModel { Name = province.Name.Equals("Tierra del Fuego, Antártida e Islas del Atlántico Sur") ? "Tierra del fuego" : province.Name });
                }
        }

        public PreferencesDto PreferencesObject { get; set; }

        public List<ProvinceLocation> Provinces { get; private set; } = new List<ProvinceLocation>();

        public List<ProvinceLocation> Locations { get; private set; } = new List<ProvinceLocation>();

        public ObservableCollection<LocationsGroup> LocationsGroup { get; set; } = new ObservableCollection<LocationsGroup>();

        public ObservableCollection<LocationsGroup> LocationsGroupSelected { get; set; } = new ObservableCollection<LocationsGroup>();

        // Properties Wintering

        public ObservableCollection<ProvinceOrLocationItemViewModel> ProvincesCollection { get; set; } = new ObservableCollection<ProvinceOrLocationItemViewModel>();

        public ObservableCollection<ProvinceAndLocationItemViewModel> ProvincesSelected { get; set; } = new ObservableCollection<ProvinceAndLocationItemViewModel>();

        public ObservableCollection<PaymentTermsItemViewModel> WinteringPaymentTerms { get; set; } = new ObservableCollection<PaymentTermsItemViewModel>
        {
            new PaymentTermsItemViewModel("Contado"),
            new PaymentTermsItemViewModel("30 - 60 días"),
            new PaymentTermsItemViewModel("0 - 30 - 60 días"),
            new PaymentTermsItemViewModel("30 días"),
            new PaymentTermsItemViewModel("45 días"),
            new PaymentTermsItemViewModel("30 - 60 - 90 días")
        };

        public List<PaymentTermsItemViewModel> WinteringPaymentTermsSelected { get; set; } = new List<PaymentTermsItemViewModel>();

        public List<PaymentTermDto> PaymentTerms { get; set; } = new List<PaymentTermDto>();

        public int HeightPrices { get; set; }

        public int HeightProvincesWintering { get; set; }

        // End properties wintering

        // Properties Chore

        public ObservableCollection<ProvinceOrLocationItemViewModel> ProvincesCollectionChore { get; set; } = new ObservableCollection<ProvinceOrLocationItemViewModel>();

        public ObservableCollection<ProvinceAndLocationItemViewModel> ProvincesSelectedChore { get; set; } = new ObservableCollection<ProvinceAndLocationItemViewModel>();

        public List<PaymentTermsItemViewModel> ChorePaymentTermsSelected { get; set; } = new List<PaymentTermsItemViewModel>();

        public ObservableCollection<PaymentTermsItemViewModel> ChorePaymentTerms { get; set; } = new ObservableCollection<PaymentTermsItemViewModel>
        {
            new PaymentTermsItemViewModel("Contado"),
            new PaymentTermsItemViewModel("7 días"),
            new PaymentTermsItemViewModel("15 días"),
            new PaymentTermsItemViewModel("21 días"),
            new PaymentTermsItemViewModel("45 días"),
            new PaymentTermsItemViewModel("30 días")
        };

        public int HeightPricesChore { get; set; }

        public int HeightProvincesChore { get; set; }

        // End properties chore

        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();

        public bool HasErrors { get; set; }

        private bool ValidateAll()
        {
            Errors.Clear();

            if (PreferencesObject.IsBusinessTypeWintering)
            {
                if (ProvincesSelected.Count == 0)
                    Errors.Add(nameof(ProvincesSelected), Strings.YouMustSelectAtLeastOneProvince);

                if (WinteringPaymentTermsSelected.Count == 0)
                {
                    Errors.Add(nameof(WinteringPaymentTerms), Strings.YouMustSelectAtLeastOnePaymentTerm);
                }
                else
                {
                    foreach (var item in WinteringPaymentTermsSelected)
                    {
                        if (string.IsNullOrEmpty(item.MinPriceSelected) || string.IsNullOrEmpty(item.MaxPriceSelected))
                        {
                            Errors.Add(nameof(WinteringPaymentTermsSelected), Strings.YouMustSelectAMinimumAndMaximumAmount);
                            break;
                        }
                        else if (item.MaxPriceSelected.Equals(item.MinPriceSelected) || Int32.Parse(item.MaxPriceSelected) < Int32.Parse(item.MinPriceSelected))
                        {
                            Errors.Add(nameof(WinteringPaymentTermsSelected), Strings.MaximumCannotBeEqualToOrLessThanTheMinimum);
                            break;
                        }

                    }
                }

            }
            if (PreferencesObject.IsBusinessTypeChore)
            {
                if (ProvincesSelectedChore.Count == 0)
                    Errors.Add(nameof(ProvincesSelectedChore), Strings.YouMustSelectAtLeastOneProvince);

                if (ChorePaymentTermsSelected.Count == 0)
                {
                    Errors.Add(nameof(ChorePaymentTerms), Strings.YouMustSelectAtLeastOnePaymentTerm);
                }
                else
                {
                    foreach (var item in ChorePaymentTermsSelected)
                    {
                        if (string.IsNullOrEmpty(item.MinPriceSelected) || string.IsNullOrEmpty(item.MaxPriceSelected))
                        {
                            Errors.Add(nameof(ChorePaymentTermsSelected), Strings.YouMustSelectAMinimumAndMaximumAmount);
                            break;
                        }
                        else if (item.MaxPriceSelected.Equals(item.MinPriceSelected) || Int32.Parse(item.MaxPriceSelected) < Int32.Parse(item.MinPriceSelected))
                        {
                            Errors.Add(nameof(ChorePaymentTermsSelected), Strings.MaximumCannotBeEqualToOrLessThanTheMinimum);
                            break;
                        }

                    }
                }
            }


            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }


        //Commands
        public SandboxedCommand SelectProvincesCommand { get; private set; }
        public SandboxedCommand SelectProvincesChoreCommand { get; private set; }
        public SandboxedCommand SelectLocationsCommand { get; private set; }

        public SandboxedCommand SavePreferencesCommand { get; private set; }
        public SandboxedCommand GoBackCommand { get; private set; }

        // Methods
        private async Task SelectProvinces()
        {
            await PopupNavigation.Instance.PushAsync(new SelectProvincesPopupPage(ProvincesCollection, "Invernada"));
        }

        private async Task SelectProvincesChore()
        {
            await PopupNavigation.Instance.PushAsync(new SelectProvincesPopupPage(ProvincesCollectionChore, "Faena"));
        }

        private async Task SelectLocations()
        {
            await PopupNavigation.Instance.PushAsync(new SelectLocationsPopupPage(LocationsGroup));
        }

        private async Task SavePreferences()
        {
            if (!ValidateAll())
                return;

            StringBuilder sbWinteringProvinces = new StringBuilder("");
            StringBuilder sbChoreProvinces = new StringBuilder("");

            if (PreferencesObject.IsBusinessTypeWintering)
            {
                if (ProvincesSelected.Count > 0)
                {
                    for (int i = 0; i < ProvincesSelected.Count; i++)
                    {
                        if (ProvincesSelected.Count == 1)
                        {
                            sbWinteringProvinces.Append(ProvincesSelected[i].ProvinceName);
                        }
                        else if (i == (ProvincesSelected.Count - 1))
                        {
                            sbWinteringProvinces.Append(" y ");
                            sbWinteringProvinces.Append(ProvincesSelected[i].ProvinceName);
                        }
                        else if (i == (ProvincesSelected.Count - 2))
                        {
                            sbWinteringProvinces.Append(ProvincesSelected[i].ProvinceName);
                        }
                        else
                        {
                            sbWinteringProvinces.Append(ProvincesSelected[i].ProvinceName);
                            sbWinteringProvinces.Append(", ");
                        }
                    }
                }
                WinteringPaymentTermsSelected.ForEach((payment) =>
                {
                    PaymentTerms.Add(new PaymentTermDto
                    {
                        BusinessType = "wintering",
                        Name = payment.Name,
                        Selected = true,
                        MinPrice = string.IsNullOrEmpty(payment.MinPriceSelected) ? 0 : Int32.Parse(payment.MinPriceSelected),
                        MaxPrice = string.IsNullOrEmpty(payment.MaxPriceSelected) ? 0 : Int32.Parse(payment.MaxPriceSelected)
                    });
                });
            }

            if (PreferencesObject.IsBusinessTypeChore)
            {
                if (ProvincesSelectedChore.Count > 0)
                {
                    for (int i = 0; i < ProvincesSelectedChore.Count; i++)
                    {
                        if (ProvincesSelectedChore.Count == 1)
                        {
                            sbChoreProvinces.Append(ProvincesSelectedChore[i].ProvinceName);
                        }
                        else if (i == (ProvincesSelectedChore.Count - 1))
                        {
                            sbChoreProvinces.Append(" y ");
                            sbChoreProvinces.Append(ProvincesSelectedChore[i].ProvinceName);
                        }
                        else if (i == (ProvincesSelectedChore.Count - 2))
                        {
                            sbChoreProvinces.Append(ProvincesSelectedChore[i].ProvinceName);
                        }
                        else
                        {
                            sbChoreProvinces.Append(ProvincesSelectedChore[i].ProvinceName);
                            sbChoreProvinces.Append(", ");
                        }
                    }
                }
                ChorePaymentTermsSelected.ForEach((payment) =>
                {
                    PaymentTerms.Add(new PaymentTermDto
                    {
                        BusinessType = "chore",
                        Name = payment.Name,
                        Selected = true,
                        MinPrice = string.IsNullOrEmpty(payment.MinPriceSelected) ? 0 : Int32.Parse(payment.MinPriceSelected),
                        MaxPrice = string.IsNullOrEmpty(payment.MaxPriceSelected) ? 0 : Int32.Parse(payment.MaxPriceSelected)
                    });
                });
            }

            PreferencesObject.DestinationStatesWintering = sbWinteringProvinces.ToString();
            PreferencesObject.DestinationStatesChore = sbChoreProvinces.ToString();
            PreferencesObject.PaymentTerms = PaymentTerms;

            await _profileService.AddProfilePreferences(long.Parse(_appSettings.UserId), PreferencesObject);

            await Shell.Current.GoToAsync("../../..");
        }
        private async Task GoBack()
        {
            await Shell.Current.GoToAsync("..");
        }
    }
}
