﻿using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.ApiClient.ApisInterfaces;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class WheaterApiProvider : TradeFoodBaseApiProvider, IWheaterApiProvider
    {
        public WheaterApiProvider(IAppHttpClient httpClientSingleton,
                                  IApiExceptionManager apiExceptionManager)
            : base(httpClientSingleton, apiExceptionManager)
        {
        }

        public async Task<WheaterData> GetWheaterAsync(string lat, string lon)
        {
            var wheater = await this.ExecuteRequest<TradeFoodApiResponse<WheaterData>>(
                () => this.GetRestServiceFor<IWeatherApi>().GetWheaterAsync(lat, lon)).ConfigureAwait(false);

            return wheater.Data;
        }
    }
}