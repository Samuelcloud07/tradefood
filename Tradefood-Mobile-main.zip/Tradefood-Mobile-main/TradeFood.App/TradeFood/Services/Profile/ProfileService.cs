﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Providers;


namespace TradeFood.Services
{
    class ProfileService : IProfileService
    {
        private readonly IProviderFactory _providerFactory;

        public ProfileService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }
        public Task<string> TestAsync()
        {
            return _providerFactory.Create<IProfileProvider>().TestAsync();
        }

        public Task<CommercialReferenceDto> GetCommercialReferenceAsync(long userId)
        {
            return _providerFactory.Create<IProfileProvider>().GetCommercialReferenceAsync(userId);
        }

        public Task<bool> AddCommercialReferenceAsync(string userId, CommercialReferenceDto commercialReference)
        {
            return _providerFactory.Create<IProfileProvider>().AddCommercialReferenceAsync(userId, commercialReference);
        }

        public Task<bool> AddSocietiesAndPersonsAsync(long userId, SocietiesAndPersonDto societiesAndPerson)
        {
            return _providerFactory.Create<IProfileProvider>().AddSocietiesAndPersonsAsync(userId, societiesAndPerson);
        }

        public Task<List<SocietiesAndPersonDto>> GetSocietiesAndPersonsAsync(long userId)
        {
            return _providerFactory.Create<IProfileProvider>().GetSocietiesAndPersonsAsync(userId);
        }

        public Task<bool> AddAddressSocietiesAsync(long userId, long societiesId, AddressDto address)
        {
            return _providerFactory.Create<IProfileProvider>().AddAddressSocietiesAsync(userId, societiesId, address);
        }

        public Task<bool> DeleteSocietiesAsync(long userId, long societiesId)
        {
            return _providerFactory.Create<IProfileProvider>().DeleteSocietiesAsync(userId, societiesId);
        }

        public Task<bool> UpdateSocietiesAsync(long userId, SocietiesAndPersonDto societiesAndPersons)
        {
            return _providerFactory.Create<IProfileProvider>().UpdateSocietiesAsync(userId, societiesAndPersons);
        }

        public Task<bool> UpdateAddressAsync(long userId, AddressDto address)
        {
            return _providerFactory.Create<IProfileProvider>().UpdateAddressAsync(userId, address);
        }

        public Task<List<AddressDto>> GetAddressesAsync(long userId)
        {
            return _providerFactory.Create<IProfileProvider>().GetAddressesAsync(userId);
        }

        public Task<List<AddressDto>> GetAllAddressesAsync(long userId)
        {
            return _providerFactory.Create<IProfileProvider>().GetAllAddressesAsync(userId);
        }

        public Task<bool> AddAddressAsync(AddressDto addressDto, long userId)
        {
            return _providerFactory.Create<IProfileProvider>().AddAddressAsync(addressDto, userId);
        }

        public Task<ProfileStats> GetProfileStats()
        {
            return _providerFactory.Create<IProfileProvider>().GetProfileStats();
        }

        public Task<PreferencesDto> GetProfilePreferences(long userId)
        {
            return _providerFactory.Create<IProfileProvider>().GetProfilePreferences(userId);
        }

        public Task<bool> AddProfilePreferences(long userId, PreferencesDto preferences)
        {
            return _providerFactory.Create<IProfileProvider>().AddProfilePreferences(userId, preferences);
        }
    }
}
