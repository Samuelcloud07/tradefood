﻿using System;
using Xamarin.Forms;

namespace TradeFood.Components
{
    public partial class CustomDatePickerComponent : StackLayout
    {
        // Bindable Properties
        public static readonly BindableProperty DateProperty = BindableProperty.Create(
            nameof(Date),
            typeof(DateTime),
            typeof(CustomDatePickerComponent),
            default(DateTime),
            BindingMode.TwoWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomDatePickerComponent)bindable;

                view.customDatePicker.Date = (DateTime)newVal;
            }
        );

        public CustomDatePickerComponent()
        {
            InitializeComponent();
        }

        // Event Handlers
        public event EventHandler<DateChangedEventArgs> DateSelected;

        // Properties
        public DateTime Date
        {
            get => (DateTime)GetValue(DateProperty);
            set => SetValue(DateProperty, value);
        }

        // Methods
        private void DatePicker_Tapped(object sender, EventArgs e)
        {
            this.customDatePicker.Focus();
        }

        private void DatePicker_DateSelected(object sender, DateChangedEventArgs e)
        {
            this.Date = this.customDatePicker.Date;

            this.DateSelected?.Invoke(this, e);
        }
    }
}