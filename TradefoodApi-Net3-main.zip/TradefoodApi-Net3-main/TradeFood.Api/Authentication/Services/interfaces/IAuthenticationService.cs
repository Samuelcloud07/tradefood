﻿using Authentication.Models.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Authentication.Services
{
    public interface IAuthenticationService
    {
        Task<List<PlanetDto>> GetPlanetsAsync();
    }
}