﻿namespace TradeFood.Providers
{
    public interface IAgroNewsLocalProvider : IAgroNewsProvider
    {
    }
}