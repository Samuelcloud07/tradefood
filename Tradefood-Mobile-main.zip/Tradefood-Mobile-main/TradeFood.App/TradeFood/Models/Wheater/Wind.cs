﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class Wind
    {
        [JsonProperty("speed")]
        public double Speed { get; set; }

        [JsonProperty("deg")]
        public long Deg { get; set; }

        [JsonProperty("gust")]
        public long Gust { get; set; }
    }
}