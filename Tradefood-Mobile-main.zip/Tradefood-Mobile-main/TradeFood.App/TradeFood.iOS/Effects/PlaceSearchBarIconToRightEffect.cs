﻿using System;
using System.ComponentModel;
using TradeFood.iOS.Effects;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportEffect(typeof(PlaceSearchBarIconToRightEffect), nameof(PlaceSearchBarIconToRightEffect))]
namespace TradeFood.iOS.Effects
{
    public class PlaceSearchBarIconToRightEffect : PlatformEffect
    {
        protected override void OnAttached()
        {
            UISearchBar searchBar = Control as UISearchBar;

            if (searchBar is null)
                throw new NotImplementedException();

            searchBar.ShowsCancelButton = false;

            searchBar.SearchTextField.BackgroundColor = Color.Transparent.ToUIColor();
            searchBar.SearchTextField.TextAlignment = UITextAlignment.Left;

            searchBar.SearchTextField.LeftView = null;
        }

        protected override void OnDetached()
        {
        }

        protected override void OnElementPropertyChanged(PropertyChangedEventArgs args)
        {
            base.OnElementPropertyChanged(args);

            if (args.PropertyName == "Text")
            {
                UISearchBar searchBar = Control as UISearchBar;

                searchBar.ShowsCancelButton = false;
            }
        }
    }
}