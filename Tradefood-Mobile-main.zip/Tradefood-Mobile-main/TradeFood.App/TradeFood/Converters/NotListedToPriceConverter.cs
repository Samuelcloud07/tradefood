﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class NotListedToPriceConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var textPrice = (string)value;

            return textPrice.Contains("No cotiza") ? textPrice : $"${textPrice}";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}