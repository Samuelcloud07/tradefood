﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class Main
    {
        [JsonProperty("temp")]
        public int Temp { get; set; }

        [JsonProperty("tempMin")]
        public int TempMin { get; set; }

        [JsonProperty("tempMax")]
        public int TempMax { get; set; }

        [JsonProperty("pressure")]
        public long Pressure { get; set; }

        [JsonProperty("humidity")]
        public long Humidity { get; set; }

        [JsonProperty("grndLevel")]
        public long GrndLevel { get; set; }
    }
}