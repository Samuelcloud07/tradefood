﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using TradeFood.Models.Market;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class ChoreWeightsToStringConverter : IValueConverter

    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string stringWeights = "";
            var weightsList = (List<TroopCategory>)value;

            for (int i = 1; i <= weightsList.Count; i++)
            {
                stringWeights += $"{weightsList[i - 1].AverageWeightAmount} kg.";
                if (i < weightsList.Count)
                    stringWeights += " - ";
            }

            return stringWeights;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
