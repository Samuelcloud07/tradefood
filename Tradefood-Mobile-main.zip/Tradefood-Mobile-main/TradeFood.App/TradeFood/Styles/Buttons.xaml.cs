﻿using Xamarin.Forms;

namespace TradeFood.Styles
{
    public partial class Buttons : ResourceDictionary
    {
        public Buttons()
        {
            InitializeComponent();
        }
    }
}