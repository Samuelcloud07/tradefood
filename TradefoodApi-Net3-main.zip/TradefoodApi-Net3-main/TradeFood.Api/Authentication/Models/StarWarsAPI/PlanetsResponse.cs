﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Authentication.Models
{
    public class PlanetsResponse
    {
        [JsonProperty("count")]
        public long Count { get; set; }

        [JsonProperty("next")]
        public Uri Next { get; set; }

        [JsonProperty("previous")]
        public object Previous { get; set; }

        [JsonProperty("results")]
        public List<Planet> Results { get; set; }
    }
}