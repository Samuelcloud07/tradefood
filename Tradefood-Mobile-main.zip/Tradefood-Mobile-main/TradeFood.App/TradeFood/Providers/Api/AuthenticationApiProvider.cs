﻿using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.ApiClient.ApisInterfaces;
using TradeFood.Models;
using TradeFood.Settings;

namespace TradeFood.Providers
{
    public class AuthenticationApiProvider : TradeFoodBaseApiProvider, IAuthenticationApiProvider
    {
        private readonly IAppSettings _appSettings;

        public AuthenticationApiProvider(IAppHttpClient httpClientSingleton,
                                         IApiExceptionManager apiExceptionManager,
                                         IAppSettings appSettings)
            : base(httpClientSingleton, apiExceptionManager)
        {
            _appSettings = appSettings;
        }

        public async Task<LoginResponse> LoginAsync(SignIn signIn)
        {
            var signInResponse = await this.ExecuteRequest<TradeFoodApiResponse<LoginResponse>>(
                () => this.GetRestServiceFor<IAuthenticationApi>().LoginAsync(signIn)).ConfigureAwait(false);

            _appSettings.ClientType = signInResponse.Data.ProfileType.ToString();
            _appSettings.UserEmail = signInResponse.Data.Email;
            _appSettings.UserName = (!string.IsNullOrEmpty(signInResponse.Data.NameAndLastname))
                ? signInResponse.Data.NameAndLastname
                : signInResponse.Data.BusinessName;
            _appSettings.UserId = signInResponse.Data.UserId;
            _appSettings.PhoneNumber = signInResponse.Data.PhoneNumber;
            _appSettings.State = signInResponse.Data.State;
            _appSettings.Location = signInResponse.Data.Location;

            return signInResponse.Data;
        }

        public async Task<RequestNewPasswordResponse> RequestPasswordResetAsync(string email)
        {
            var requestNewPasswordResponse = await this.ExecuteRequest<TradeFoodApiResponse<RequestNewPasswordResponse>>(
                () => this.GetRestServiceFor<IAuthenticationApi>().RequestPasswordResetAsync(email)).ConfigureAwait(false);

            return requestNewPasswordResponse.Data;
        }

        public async Task ResetPasswordAsync(ResetUserPassword resetUserPassword)
        {
            await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IAuthenticationApi>().ResetPasswordAsync(resetUserPassword)).ConfigureAwait(false);
        }

        public async Task<LoginResponse> SignUpAsync(SignUp signUp)
        {
            var signUpResponse = await this.ExecuteRequest<TradeFoodApiResponse<LoginResponse>>(
                () => this.GetRestServiceFor<IAuthenticationApi>().SignUpAsync(signUp)).ConfigureAwait(false);

            return signUpResponse.Data;
        }

        public async Task<LoginResponse> ConfirmEmailAsync(EmailConfirmation emailConfirmation)
        {
            var confirmEmailResponse = await this.ExecuteRequest<TradeFoodApiResponse<LoginResponse>>(
                () => this.GetRestServiceFor<IAuthenticationApi>().ConfirmEmailAsync(emailConfirmation)).ConfigureAwait(false);

            return confirmEmailResponse.Data;
        }

        public async Task ResendEmailConfirmationAsync(string email)
        {
            await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IAuthenticationApi>().ResendEmailConfirmationAsync(email)).ConfigureAwait(false);
        }

        public async Task ChangePasswordAsync(ResetUserPassword resetUserPassword)
        {
            await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IAuthenticationApi>().ChangePasswordAsync(resetUserPassword)).ConfigureAwait(false);
        }
    }
}