﻿using Newtonsoft.Json;
using System;

namespace TradeFood.Models
{
    public class TradeFoodApiErrorResponse
    {
        [JsonProperty("errorMessage")]
        public string ErrorMessage { get; set; }

        [JsonProperty("result")]
        public string Result { get; set; }

        [JsonProperty("httpCode")]
        public int HttpCodeStatus { get; set; }
    }
}