﻿namespace TradeFood.Providers
{
    public interface IStatesApiProvider : IStatesProvider
    {
    }
}