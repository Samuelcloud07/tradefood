﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class StringCompletedToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var completedText = (string)value;

            return completedText == "Completa"
                ? Color.FromHex("#00724D")
                : Color.FromHex("#A10B07");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}