﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace TradeFood.Models
{
    public class GrainData
    {
        [JsonProperty("publicationDate")]
        public string PublicationDate { get; set; }

        [JsonProperty("cereales")]
        public List<Grain> Cereales { get; set; }
    }
}