﻿using Xamarin.Forms;

namespace TradeFood.Effects
{
    public class PlaceSearchBarIconToRightEffect : RoutingEffect
    {
        public PlaceSearchBarIconToRightEffect()
            : base("TradeFood.PlaceSearchBarIconToRightEffect")
        {
        }
    }
}