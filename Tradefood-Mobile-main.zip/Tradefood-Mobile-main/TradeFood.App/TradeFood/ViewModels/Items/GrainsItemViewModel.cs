﻿using System.ComponentModel;
using TradeFood.Models;

namespace TradeFood.ViewModels
{
    public class GrainsItemViewModel : INotifyPropertyChanged
    {
        public GrainsItemViewModel(Grain grain)
        {
            GrainData = grain;
        }

        public Grain GrainData { get; private set; }

        public bool GrainSelected { get; set; }

        // INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}