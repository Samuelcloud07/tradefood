﻿using PropertyChanged;
using System;
using System.Collections;
using Xamarin.Forms;

namespace TradeFood.Components
{
    [SuppressPropertyChangedWarnings]
    public partial class CustomPickerComponent : StackLayout
    {
        // Bindable Properties
        public static readonly BindableProperty TitleProperty = BindableProperty.Create(
            nameof(Title),
            typeof(string),
            typeof(CustomPickerComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomPickerComponent)bindable;

                view.title.Text = (string)newVal;
                view.title.IsVisible = true;

                if (string.IsNullOrEmpty(view.title.Text))
                {
                    view.title.IsVisible = false;
                    view.title.HeightRequest = 0;
                }
            }
        );

        public static readonly BindableProperty PickerTitleProperty = BindableProperty.Create(
            nameof(PickerTitle),
            typeof(string),
            typeof(CustomPickerComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomPickerComponent)bindable;

                view.dropDownPicker.Title = (string)newVal;
            }
        );

        public static readonly BindableProperty ItemsSourceProperty = BindableProperty.Create(
            nameof(ItemsSource),
            typeof(IList),
            typeof(CustomPickerComponent),
            default(IList),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomPickerComponent)bindable;

                view.dropDownPicker.ItemsSource= (IList)newVal;
            }
        );

        public static readonly BindableProperty SelectedItemProperty = BindableProperty.Create(
            nameof(SelectedItem),
            typeof(object),
            typeof(CustomPickerComponent),
            null,
            BindingMode.TwoWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomPickerComponent)bindable;

                view.dropDownPicker.SelectedItem = (object)newVal;
            }
        );

        public static readonly BindableProperty SelectedIndexProperty = BindableProperty.Create(
            nameof(SelectedIndex),
            typeof(int),
            typeof(CustomPickerComponent),
            -1,
            BindingMode.TwoWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomPickerComponent)bindable;

                view.dropDownPicker.SelectedIndex = (int)newVal;
            }
        );

        public static readonly BindableProperty ErrorTextProperty = BindableProperty.Create(
            nameof(ErrorText),
            typeof(string),
            typeof(CustomPickerComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomPickerComponent)bindable;

                view.errorText.Text = (string)newVal;
            }
        );

        public static readonly BindableProperty HasErrorProperty = BindableProperty.Create(
            nameof(HasError),
            typeof(bool),
            typeof(CustomPickerComponent),
            default(bool),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomPickerComponent)bindable;

                view.errorText.IsVisible = (bool)newVal;
            }
        );

        public CustomPickerComponent()
        {
            InitializeComponent();

            this.SelectedItem = this.dropDownPicker.SelectedItem;
        }

        // Event Handlers
        public event EventHandler<EventArgs> SelectedIndexChanged;

        // Properties
        public string Title
        {
            get => (string)GetValue(TitleProperty);
            set => SetValue(TitleProperty, value);
        }

        public string PickerTitle
        {
            get => (string)GetValue(PickerTitleProperty);
            set => SetValue(PickerTitleProperty, value);
        }

        public IList ItemsSource
        {
            get => (IList)GetValue(ItemsSourceProperty);
            set => SetValue(ItemsSourceProperty, value);
        }

        public BindingBase ItemDisplayBinding
        {
            set => this.dropDownPicker.ItemDisplayBinding = value;
        }

        public object SelectedItem
        {
            get => (object)GetValue(SelectedItemProperty);
            set => SetValue(SelectedItemProperty, value);
        }

        public int SelectedIndex
        {
            get => (int)GetValue(SelectedIndexProperty);
            set => SetValue(SelectedIndexProperty, value);
        }

        public void PickerFocused()
        {
            this.dropDownPicker.Focus();
        }

        private void PickerTapped(object sender, EventArgs e)
        {
            this.dropDownPicker.Focus();
        }

        public string ErrorText
        {
            get => (string)GetValue(ErrorTextProperty);
            set => SetValue(ErrorTextProperty, value);
        }

        public bool HasError
        {
            get => (bool)GetValue(HasErrorProperty);
            set => SetValue(HasErrorProperty, value);
        }


        // Methods
        private void CustomPickerSelectedIndexChanged(object sender, EventArgs e)
        {
            this.SelectedItem = this.dropDownPicker.SelectedItem;

            this.SelectedIndexChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}