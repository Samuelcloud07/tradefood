﻿using SQLite;
using System.Collections.Generic;

namespace TradeFood.Models
{
    public abstract class BaseEntityModel<T> : IComparableByUniqueProperty
    {
        [PrimaryKey]
        public virtual T Id { get; set; }

        public bool EqualsByUniqueProperty(IComparableByUniqueProperty compareTo)
        {
            if (compareTo == null || this.GetType() != compareTo.GetType())
                return false;

            var entity = compareTo as BaseEntityModel<T>;

            return entity != null && EqualityComparer<T>.Default.Equals(this.Id, entity.Id);
        }
    }

    public abstract class BaseEntityModel : BaseEntityModel<long>
    {
    }
}