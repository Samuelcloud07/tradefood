﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace TradeFood.ViewModels
{
    public class ProvinceOrLocationItemViewModel : INotifyPropertyChanged
    {
        public string Name { get; set; }
        private bool _selected;
        public bool Selected
        {
            get { return _selected; }
            set
            {
                _selected = value;
                OnPropertyChanged(nameof(Selected));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
