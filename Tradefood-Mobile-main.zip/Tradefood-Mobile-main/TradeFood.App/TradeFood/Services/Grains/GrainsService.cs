﻿using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Providers;

namespace TradeFood.Services
{
    public class GrainsService : IGrainsService
    {
        private readonly IProviderFactory _providerFactory;

        public GrainsService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }

        public Task<GrainData> GetGrainsQuotationAsync()
        {
            return _providerFactory.Create<IGrainsProvider>().GetGrainsQuotationAsync();
        }
    }
}