﻿using TradeFood.ViewModels;
using TradeFood.Sandbox;
using PropertyChanged;
using System;
using System.Threading.Tasks;

namespace TradeFood.Commands
{
    [AddINotifyPropertyChangedInterface]
    public class SandboxedCommand : IDelegateCommand
    {
        private readonly DelegateCommand _delegateCommand;
        private readonly Action<Exception> _onException;

        public SandboxedCommand(Func<Task> task, Func<bool> canExecute = null, Action<Exception> onException = null)
        {
            _onException = onException;

            _delegateCommand = new DelegateCommand(() => NotifyTask = SandboxedNotifyTask.Create(task, _onException), canExecute);
        }

        public NotifyTask NotifyTask { get; private set; }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute() => _delegateCommand.CanExecute();

        public bool CanExecute(object parameter) => _delegateCommand.CanExecute(parameter);

        public void Execute() => _delegateCommand.Execute();

        public void Execute(object parameter) => _delegateCommand.Execute(parameter);

        protected virtual void OnException(Exception ex) => _onException?.Invoke(ex);

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    [AddINotifyPropertyChangedInterface]
    public class SandboxedCommand<T> : IDelegateCommand<T>
    {
        private readonly DelegateCommand<T> _delegateCommand;
        private readonly Action<Exception> _onException;

        public SandboxedCommand(Func<T, Task> task, Func<T, bool> canExecute = null, Action<Exception> onException = null)
        {
            _onException = onException;

            _delegateCommand = new DelegateCommand<T>(t => NotifyTask = SandboxedNotifyTask.Create(() => task(t), _onException), canExecute);
        }

        public NotifyTask NotifyTask { get; private set; }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute() => _delegateCommand.CanExecute();

        public bool CanExecute(object parameter) => _delegateCommand.CanExecute(parameter);

        public bool CanExecute(T parameter) => _delegateCommand.CanExecute(parameter);

        public void Execute() => _delegateCommand.Execute();

        public void Execute(object parameter) => _delegateCommand.Execute(parameter);

        public void Execute(T parameter) => _delegateCommand.Execute(parameter);

        protected virtual void OnException(Exception ex) => _onException?.Invoke(ex);

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}