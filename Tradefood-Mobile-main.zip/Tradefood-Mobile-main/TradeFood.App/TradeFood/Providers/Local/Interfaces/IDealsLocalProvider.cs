﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public interface IDealsLocalProvider : IDealsProvider
    {
        Task<List<Deal>> PersistDealsAsync(IEnumerable<Deal> deals);
    }
}