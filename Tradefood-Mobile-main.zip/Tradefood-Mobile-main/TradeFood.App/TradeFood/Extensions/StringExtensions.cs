﻿using System.Text.RegularExpressions;

namespace TradeFood.Extensions
{
    public static class StringExtensions
    {
        public static bool IsValidPassword(this string password)
        {
            return !string.IsNullOrEmpty(password)
                && Regex.IsMatch(password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$");
        }

        public static bool IsValidEmail(this string email)
        {
            return !string.IsNullOrEmpty(email)
                && Regex.IsMatch(email, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }

        public static bool IsValidPhoneNumber(this string phoneNumber)
        {
            return !string.IsNullOrEmpty(phoneNumber)
            && Regex.IsMatch(phoneNumber, @"/[\(]?[\+]?(\d{2}|\d{3})[\)]?[\s]?((\d{6}|\d{8})|(\d{3}[\*\.\-\s]){3}|(\d{2}[\*\.\-\s]){4}|(\d{4}[\*.\-\s]){2})|\d{8}|\d{10}|\d{12}/");
        }


    }
}