﻿using System.Windows.Input;

namespace TradeFood.Commands
{
    public interface IDelegateCommand : ICommand
    {
        void RaiseCanExecuteChanged();

        void Execute();

        bool CanExecute();
    }

    public interface IDelegateCommand<T> : ICommand
    {
        void RaiseCanExecuteChanged();

        void Execute(T parameter);

        bool CanExecute(T parameter);
    }
}