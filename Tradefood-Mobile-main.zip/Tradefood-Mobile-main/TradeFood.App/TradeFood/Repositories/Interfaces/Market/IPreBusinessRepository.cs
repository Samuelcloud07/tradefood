﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Repositories
{
    public interface IPreBusinessRepository : ISQLiteRepository<PreBusiness>
    {
        Task<List<PreBusiness>> GetAllPreBusinessAsync();

        Task<PreBusiness> PersistPreBusinesseAsync(PreBusiness preBusiness);

        Task<List<PreBusiness>> PersistPreBusinessesAsync(IEnumerable<PreBusiness> preBusinesses);

        Task DeletePreBusinessAsync(PreBusiness preBusiness);
    }
}