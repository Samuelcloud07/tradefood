﻿using System.Threading.Tasks;
using TradeFood.Exceptions;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class AuthenticationLocalProvider : IAuthenticationLocalProvider
    {
        public AuthenticationLocalProvider()
        {
        }

        public Task<LoginResponse> ConfirmEmailAsync(EmailConfirmation emailConfirmation)
        {
            throw new NoInternetException();
        }

        public Task<LoginResponse> LoginAsync(SignIn signIn)
        {
            throw new NoInternetException();
        }

        public Task<RequestNewPasswordResponse> RequestPasswordResetAsync(string email)
        {
            throw new NoInternetException();
        }

        public Task ResendEmailConfirmationAsync(string email)
        {
            throw new NoInternetException();
        }

        public Task ResetPasswordAsync(ResetUserPassword resetUserPassword)
        {
            throw new NoInternetException();
        }

        public Task<LoginResponse> SignUpAsync(SignUp signUp)
        {
            throw new NoInternetException();
        }
        public Task ChangePasswordAsync(ResetUserPassword resetUserPassword)
        {
            throw new NoInternetException();
        }
    }
}