﻿using TradeFood.Helpers;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.ViewModels;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace TradeFood.Views
{
    public partial class RegisterValidationPage : BasePage
    {
        private RegisterValidationViewModel _vm;

        public RegisterValidationPage()
        {
            InitializeComponent();

            _vm = new RegisterValidationViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<IAuthenticationService>(),
                TypeLocator.Resolve<IDialogsHelper>());

            this.BindingContext = _vm;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            var safeInsets = On<iOS>().SafeAreaInsets();

            safeInsets.Bottom = -35;

            content.Padding = safeInsets;
        }

        protected override bool OnBackButtonPressed()
        {
            _vm.GoBackCommand.Execute(null);

            return true;
        }
    }
}