﻿using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Models.Market.Dtos;

namespace TradeFood.ApiClient.ApisInterfaces
{
    public interface IDealsApi
    {
        [Get("/deals/Deals/deals")]
        Task<TradeFoodApiResponse<List<Deal>>> GetAllDealsAsync();

        [Get("/dealsfunction/Deals/begin-file-upload?fileName={fileName}")]
        Task<TradeFoodApiResponse<string>> BeginFileUploadAsync(string fileName);

        [Get("/dealsfunction/Deals/end-file-upload?fileHandle={fileHandle}&fileSize={fileSize}&dealId={dealId}&isThumbnail={isThumbnail}")]
        Task<TradeFoodApiResponse<bool>> EndFileUploadAsync(string fileHandle, long fileSize, string dealId, bool isThumbnail);

        [Post("/DealsFunction/Deals/create-deal?userId={userId}")]
        Task<TradeFoodApiResponse<Deal>> CreateDealAsync(string userId, [Body(BodySerializationMethod.Serialized)] DealRequest deal);
        
        [Post("/dealsfunction/Deals/upload-chunk")]
        Task<TradeFoodApiResponse<bool>> UploadChunkAsync([Body(BodySerializationMethod.Serialized)] MediaChunk mediaChunk);

        //New endpoints 
        [Post("/dealsfunction/Deals/create-deal-chore?userId={userId}")]
        Task<TradeFoodApiResponse<DealDto>> CreateChoreDealAsync(string userId, [Body(BodySerializationMethod.Serialized)] DealDto deal);

        [Post("/dealsfunction/Deals/create-deal-wintering?userId={userId}")]
        Task<TradeFoodApiResponse<DealDto>> CreateWinteringDealAsync(string userId, [Body(BodySerializationMethod.Serialized)] DealDto deal);

        [Get("/dealsfunction/Deals/deals")]
        Task<TradeFoodApiResponse<List<DealApiDto>>> GetDealsAsync();

        [Get("/dealsfunction/Deals/get-stats-type-deals")]
        Task<TradeFoodApiResponse<DealsStats>> GetDealsStats();
    }
}