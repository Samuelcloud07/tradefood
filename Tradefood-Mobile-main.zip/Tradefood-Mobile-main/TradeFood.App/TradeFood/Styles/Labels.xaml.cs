﻿using Xamarin.Forms;

namespace TradeFood.Styles
{
    public partial class Labels : ResourceDictionary
    {
        public Labels()
        {
            InitializeComponent();
        }
    }
}