﻿using System.ComponentModel;
namespace TradeFood.ViewModels.Items
{
    public class BreedItemViewModel : INotifyPropertyChanged
    {
        public BreedItemViewModel(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }

        public bool Selected { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}