﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Services
{
    public interface IDollarService
    {
        Task<List<DollarData>> GetDollarQuotesAsync();
    }
}