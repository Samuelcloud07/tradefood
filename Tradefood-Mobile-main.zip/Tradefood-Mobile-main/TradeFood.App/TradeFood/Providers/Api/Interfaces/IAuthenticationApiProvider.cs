﻿namespace TradeFood.Providers
{
    public interface IAuthenticationApiProvider : IAuthenticationProvider
    {
    }
}