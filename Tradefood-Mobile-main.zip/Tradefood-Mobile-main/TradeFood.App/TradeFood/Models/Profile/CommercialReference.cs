﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Profile
{
    public class CommercialReference
    {
        public string Name { get; set; }
        public string Comment { get; set; }
    }
}
