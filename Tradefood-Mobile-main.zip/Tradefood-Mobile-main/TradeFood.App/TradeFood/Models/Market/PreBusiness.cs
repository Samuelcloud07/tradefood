﻿using SQLiteNetExtensions.Attributes;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace TradeFood.Models
{
    public class PreBusiness : BaseEntityModel
    {
        public string DealId { get; set; }

        public string DealStatus { get; set; }

        public string TroopCategory { get; set; }

        public List<string> TroopType { get; set; }

        public string Amount { get; set; }

        public string AmountFemale { get; set; }

        public string AmountMale { get; set; }

        public string Destination { get; set; }

        public string GeographicDestination { get; set; }

        public string WeightAmount { get; set; }

        public int TroopQuality { get; set; }

        public string Vacunation { get; set; }

        public string BodyHealth { get; set; }

        [TextBlob(nameof(EvidencePathsBlobed))]
        public List<string> EvidencePaths { get; set; }

        public string Comments { get; set; }

        public string SuggestedPrice { get; set; }

        public string PaymentMethod { get; set; }

        public string FinancingCategory { get; set; }

        public string AnotherFinancingTerm { get; set; }

        public string Province { get; set; }

        public string Location { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public string PersonInCharge { get; set; }

        [JsonIgnore]
        public string EvidencePathsBlobed { get; set; }
    }
}