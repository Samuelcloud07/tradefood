﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace TradeFood.Models
{
    public class Grain
    {
        [JsonProperty("tipo")]
        public string Tipo { get; set; }

        [JsonProperty("cotizacion")]
        public List<GrainQuotation> Cotizacion { get; set; }
    }
}