﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using TradeFood.Commands;
using TradeFood.Models;
using TradeFood.Models.Market.Dtos;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels.Base;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels.Market
{
    public class NewDealDetailsViewModel : BaseViewModel, IQueryAttributable
    {
        private readonly IAppSettings _appSettings;

        private Interaction _diplayVideoFromSourceInteraction = new Interaction();
        public NewDealDetailsViewModel(ILogger logger,
                                       IAppSettings appSettings)
            : base(logger)
        {
            _appSettings = appSettings;

            ChangeMainEvidenceCommand = new SandboxedCommand(ChangeMainEvidence);
        }

        public void ApplyQueryAttributes(IDictionary<string, string> query)
        {
            Deal = JsonConvert.DeserializeObject<DealApiDto>(HttpUtility.UrlDecode(query["dealDetails"]));

            if(MainEvidenceFile != null)
                MainEvidenceFile = Deal.EvidenceFiles.FirstOrDefault().FilePath;

            Title =Deal.CreatedBy == _appSettings.UserId
                ? "Tu prenegocio"
                : "Prenegocio Disponible";

            IsSingleGender = Deal.Amount != 0;

            AnimalsQuantity = Deal.Amount == 0
                ? (int)Deal.FemaleAmount + (int)Deal.MaleAmount
                : AnimalsQuantity = (int)Deal.Amount;

            IsSellerVisible = Deal.CreatedBy == _appSettings.UserId
                ? true
                : false;

            BreedCollectionViewHeight = Deal.BreedType.Count * 25;

            if (Deal.BusinessType == "Invernada")
            {
                if (Deal.TroopCategory.Any(x => x.Name == "Vacas"))
                {
                    IsTeethVisible = true;
                    TeethHeight = -1;
                }

                AreaType = Deal.IsdirtyArea == true ? "Sucia" : "Limpia";
            }
            else if (Deal.BusinessType == "Faena")
            {
                if (Deal.TroopCategory.Any(x => x.Name == "Vacas") || Deal.TroopCategory.Any(x => x.Name == "Toros"))
                {
                    IsSubCategoryVisible = true;

                    if (Deal.TroopSubCategory == "Gorda" || Deal.TroopSubCategory == "Carnicera")
                        IsNutritionalTratementVisible = true;
                }
            }
        }

        //properties
        public DealApiDto Deal { get; set; }

        public File FileSelected { get; set; }

        public string Title { get; private set; }
        
        public string MainEvidenceFile { get; private set; }
        
        public string AreaType { get; private set; }

        public int AnimalsQuantity { get; set; }

        public int BreedCollectionViewHeight { get; set; }

        public int TeethHeight { get; set; } = 0;
        
        public int Position { get; set; }
        
        public bool IsTeethVisible { get; set; } = false;

        public bool IsSingleGender { get; set; }
        
        public bool IsSubCategoryVisible { get; set; }
        
        public bool IsNutritionalTratementVisible { get; set; } = false;

        public bool IsSellerVisible { get; set; }

        public IInteraction DiplayVideoFromSourceInteraction => _diplayVideoFromSourceInteraction;

        //Commands
        public SandboxedCommand ChangeMainEvidenceCommand { get; private set; }

        //Methods
        private async Task ChangeMainEvidence()
        {
            await MainThread.InvokeOnMainThreadAsync(() =>
            {
                if (FileSelected != null)
                    MainEvidenceFile = FileSelected.FilePath;

                this.OnPropertyChanged(nameof(MainEvidenceFile));

                _diplayVideoFromSourceInteraction.Raise();
            });

            FileSelected = null;
        }
    }
}