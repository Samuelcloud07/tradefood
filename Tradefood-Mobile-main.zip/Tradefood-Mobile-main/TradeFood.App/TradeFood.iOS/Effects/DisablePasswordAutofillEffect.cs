﻿using System;
using TradeFood.iOS.Effects;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportEffect(typeof(DisablePasswordAutofillEffect), nameof(DisablePasswordAutofillEffect))]
namespace TradeFood.iOS.Effects
{
    public class DisablePasswordAutofillEffect : PlatformEffect
    {
        protected override void OnAttached()
        {
            if (!(this.Control is UITextField textField))
                throw new NotImplementedException();

            if (UIDevice.CurrentDevice.CheckSystemVersion(12, 0))
                textField.TextContentType = UITextContentType.OneTimeCode;
        }

        protected override void OnDetached()
        {
        }
    }
}