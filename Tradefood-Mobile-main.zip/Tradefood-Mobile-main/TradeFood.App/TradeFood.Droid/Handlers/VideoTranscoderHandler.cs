﻿using Android.Graphics;
using Android.Media;
using Android.OS;
using Java.Lang;
using OtaliaStudios.TranscoderLib;
using OtaliaStudios.TranscoderLib.Strategy;
using OtaliaStudios.TranscoderLib.Strategy.Size;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using TradeFood.Droid.Handlers;
using TradeFood.Handlers;
using Xamarin.Forms;

[assembly: Dependency(typeof(VideoTranscoderHandler))]
namespace TradeFood.Droid.Handlers
{
    public class VideoTranscoderHandler : IVideoTranscoderHandler
    {
        private class AVAssetExportSession : Java.Lang.Object, ITranscoderListener
        {
            private string _assetPath;

            private SemaphoreSlim _semaphore;

            public string OutputPath { get; set; }

            public AVAssetExportSession(string assetPath)
            {
                _assetPath = assetPath;

                _semaphore = new SemaphoreSlim(1);
            }

            public async Task ExportTaskAsync()
            {
                DefaultVideoStrategy videoStrategy = new DefaultVideoStrategy.Builder()
                    .AddResizer(new ExactResizer(720, 1280))
                    .BitRate(4096)
                    .FrameRate(40)
                    .KeyFrameInterval(3f)
                    .Build();

                DefaultAudioStrategy audioStrategy = new DefaultAudioStrategy.Builder()
                    .SampleRate(44100)
                    .BitRate(96)
                    .Build();

                await _semaphore.WaitAsync();

                Transcoder.Into(OutputPath)
                    .AddDataSource(_assetPath)
                    .SetVideoTrackStrategy(videoStrategy)
                    .SetAudioTrackStrategy(audioStrategy)
                    .SetListener(this)
                    .Transcode();

                await _semaphore.WaitAsync();
            }

            public void OnTranscodeCanceled()
            {
                _semaphore.Release();
            }

            public void OnTranscodeCompleted(int successCode)
            {
                _semaphore.Release();
            }

            public void OnTranscodeFailed(Throwable exception)
            {
                _semaphore.Release();
            }

            public void OnTranscodeProgress(double progress)
            {
            }
        }

        public async Task<string> TranscodeVideoAsync(string sourceVideoPath)
        {
            AVAssetExportSession export = new AVAssetExportSession(sourceVideoPath);

            string outputFilePath = System.IO.Path.Combine(
                System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal),
                $"{System.IO.Path.GetRandomFileName().Split('.')[0]}.mp4"
            );

            export.OutputPath = outputFilePath;

            await export.ExportTaskAsync();

            MemoryStream output = new MemoryStream();
            using (System.IO.Stream source = File.OpenRead(outputFilePath))
                await source.CopyToAsync(output);

            output.Seek(0, SeekOrigin.Begin);

            return outputFilePath;
        }

        public Task<string> GenerateThumbnail(string sourceVideoPath)
        {
            TaskCompletionSource<string> tcs = new TaskCompletionSource<string>();

            Bitmap bitmapThumbnail = ThumbnailUtils.CreateVideoThumbnail(new Java.IO.File(sourceVideoPath), new Android.Util.Size(1280, 720), new CancellationSignal());

            if (bitmapThumbnail != null)
            {
                MemoryStream ms = new MemoryStream();

                bitmapThumbnail.Compress(Bitmap.CompressFormat.Png, 60, ms);

                string outputFilePath = System.IO.Path.Combine(
                    System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal),
                    $"{System.IO.Path.GetRandomFileName().Split('.')[0]}.png"
                );

                using (var fileStream = File.Create(outputFilePath))
                {
                    ms.Seek(0, SeekOrigin.Begin);

                    ms.CopyTo(fileStream);
                }

                tcs.SetResult(outputFilePath);

                return tcs.Task;
            }

            tcs.SetResult(string.Empty);

            return tcs.Task;
        }
    }
}