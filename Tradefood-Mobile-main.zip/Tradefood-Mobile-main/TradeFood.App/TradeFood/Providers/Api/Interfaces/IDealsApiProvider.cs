﻿namespace TradeFood.Providers
{
    public interface IDealsApiProvider : IDealsProvider
    {
    }
}