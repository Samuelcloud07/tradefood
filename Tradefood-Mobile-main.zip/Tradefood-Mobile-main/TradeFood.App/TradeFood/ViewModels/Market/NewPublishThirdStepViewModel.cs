﻿using Newtonsoft.Json;
using Rg.Plugins.Popup.Services;
using System;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Handlers;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Models.Market;
using TradeFood.Models.Market.Dtos;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    class NewPublishThirdStepViewModel : BaseViewModel
    {
        private readonly IDealsService _dealsService;
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        private string _dealId = string.Empty;

        public NewPublishThirdStepViewModel(ILogger logger,
                                            IDealsService dealsService,
                                            IAppSettings appSettings,
                                            IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _dealsService = dealsService;
            _appSettings = appSettings;
            _dialogsHelper = dialogsHelper;

            CancelPublishCommand = new SandboxedCommand(CancelPublish);
            PublishBusinessCommand = new SandboxedCommand(PublishBusiness);
        }


        // properties
        public TroopDetails TroopDetails { get; set; }

        public PreDealDetail PreDealDetails { get; set; }

        //UI Properties
        public string MaleAndFemale { get; set; }
        public string Breeds { get; set; }
        public int BreedsHeight { get; set; }
        public string YieldPercentText { get; set; }
        public bool IsSubcategoryVisible { get; set; } = false;
        public bool IsNutritionalTratementVisible { get; set; } = false;
        public bool IsMultipleGenderVisible { get; set; } = false;
        public int MultipleGenderHeight { get; set; } = 0;
        public bool IsOnlyGenderVisible { get; set; } = false;
        public int OnlyGenderHeight { get; set; } = 0;
        public bool IsTeethVisible { get; set; } = false;
        public int TeethHeight { get; set; } = 0;
        public string HealthColor { get; private set; }
        public string AreaColor { get; private set; }
        public string AreaText { get; private set; }


        //Commands
        public SandboxedCommand PublishBusinessCommand { get; private set; }
        public SandboxedCommand CancelPublishCommand { get; private set; }
        //Methods

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            MaleAndFemale = $"{TroopDetails.MaleQuantity} Machos y {TroopDetails.FemaleQuantity} Hembras";                       

            if (TroopDetails.BusinessType == "Faena")
            {                

                if (TroopDetails.TroopCategories.Any(x => x.Name == "Vacas") || TroopDetails.TroopCategories.Any(x => x.Name == "Toros"))
                {
                    IsSubcategoryVisible = true;

                    if (TroopDetails.ChoreSubCategory == "Gorda" || TroopDetails.ChoreSubCategory == "Carnicera")                    
                        IsNutritionalTratementVisible = true;                    
                }
            }

            if (TroopDetails.BusinessType == "Invernada")
            {
                if (TroopDetails.TroopCategories.Any(x => x.Name == "Vacas"))
                {
                    IsTeethVisible = true;
                    TeethHeight = -1;
                }                
            }

            BreedsHeight = TroopDetails.Breeds.Count * 25;

            if (TroopDetails.MaleQuantity > 0 && TroopDetails.FemaleQuantity > 0)
            {
                IsMultipleGenderVisible = true;
                MultipleGenderHeight = -1;
                OnlyGenderHeight = 0;
                IsOnlyGenderVisible = false;
            }

            if (TroopDetails.MaleQuantity == 0 && TroopDetails.FemaleQuantity == 0)
            {
                IsMultipleGenderVisible = false;
                MultipleGenderHeight = 0;
                OnlyGenderHeight = -1;
                IsOnlyGenderVisible = true;
            }

            SetColors();
        }

        private void SetColors()
        {
            if (PreDealDetails.IsDirty == true)
            {
                AreaColor = "#a10b07";
                AreaText = "Sucia";
            }
            else
            {
                AreaColor = "#00724d";
                AreaText = "Limpia";
            }
        }

        private async Task PublishBusiness()
        {
            //await PrebusinessCreationValidate();

            await PrebusinessCreation();

            string troopCategories = "";
            for (int i = 0; i < TroopDetails.TroopCategories.Count; i++)
            {
                troopCategories += TroopDetails.TroopCategories[i].Name;
                troopCategories += ",";
                troopCategories += TroopDetails.TroopCategories[i].AverageWeightAmount;
                troopCategories += ",";
            }

            string breeds = "";
            for (int i = 0; i < TroopDetails.Breeds.Count; i++)
            {
                breeds += TroopDetails.Breeds[i];
                breeds += ",";
            }

            _dealId = Guid.NewGuid().ToString().Split('-').Last();

            DealDto newDeal = new DealDto
            {
                DealId = _dealId,
                SaleType = TroopDetails.SellType,
                Yield = Convert.ToString(TroopDetails.YieldPercent),
                Destination = TroopDetails.GeographicDestination,
                FitChina = TroopDetails.ChinaSuitable,
                TroopSubCategory = TroopDetails.ChoreSubCategory,
                CommentsPopurri = TroopDetails.MedleyComments,
                NutritionalTreatment = new NutritionalTreatment { Days = TroopDetails.LockdownDays, TreatmentType = TroopDetails.NutritionalTratemet },
                DealStatus = 0,
                CreatedBy = _appSettings.UserId,
                TroopCategory = troopCategories,
                BreedType = breeds,
                Amount = Convert.ToString(TroopDetails.AnimalsQuantity),
                MaleAmount = TroopDetails.MaleQuantity,
                FemaleAmount = TroopDetails.FemaleQuantity,
                Quality = TroopDetails.TroopQuality,
                SuggestedPrice = PreDealDetails.SuggestedPrice,
                PaymentMethod = PreDealDetails.PaymentMethod,
                FinancingCategory = PreDealDetails.PaymentTerms,
                Province = PreDealDetails.Province,
                Location = PreDealDetails.Location,
                FromDate = DateTime.Now,
                ToDate = DateTime.Now.AddDays(21),
                PersonInCharge = PreDealDetails.HeadOfPreBusiness,
                Comments = PreDealDetails.Comments,
                Roughing = TroopDetails.Roughing,
                Teeth = TroopDetails.TeethQuantity,
                TroopWeightType = TroopDetails.TroopWeightType,
                MinimumTip = TroopDetails.MinimumWeight,
                MaximumTip = TroopDetails.MaximumWeight,
                AverageWeightAmount = TroopDetails.AverageWeight,
                Status = new TroopStatus
                {
                    BodyState = TroopDetails.BodyState,
                    Healthy = TroopDetails.Health,
                    IsGelded = TroopDetails.IsGelded,
                    IsWeaned = TroopDetails.IsWeaned,
                    IsLiquidBrand = TroopDetails.LiquidBrand
                },
                IsDirtyArea = PreDealDetails.IsDirty,
                IsMioMio = PreDealDetails.IsMioMio,
                IsTick = PreDealDetails.IsTick,
                TroopLocation = new Address
                {
                    Id = PreDealDetails.TroopLocation.Id,
                },
                SocietiesAndPerson = new SocietiesAndPerson
                {
                    Id = PreDealDetails.SocietyOrPerson.Id
                }
            };

            try
            {
                switch (TroopDetails.BusinessType)
                {
                    case ("Faena"):
                        await _dealsService.CreateChoreDealAsync(newDeal.CreatedBy, newDeal);
                        break;
                    case ("Invernada"):
                        await _dealsService.CreateWinteringDealAsync(newDeal.CreatedBy, newDeal);
                        break;
                    case ("Cría"):
                        throw new Exception("Business type Cría not supported yet");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            //EVIDENCIA

            var videoTranscoderHandler = DependencyService.Get<IVideoTranscoderHandler>();

            string firstVideoEvidencePath = string.Empty;
            string secondVideoEvidencePath = string.Empty;
            string thirdVideoEvidencePath = string.Empty;

            string videoThumbnailPath = string.Empty;

            if (!string.IsNullOrEmpty(TroopDetails.FirstVideoEvidencePath))
            {
                firstVideoEvidencePath = await videoTranscoderHandler.TranscodeVideoAsync(TroopDetails.FirstVideoEvidencePath);

                videoThumbnailPath = await videoTranscoderHandler.GenerateThumbnail(firstVideoEvidencePath);
            }

            if (!string.IsNullOrEmpty(TroopDetails.SecondVideoEvidencePath))
            {
                secondVideoEvidencePath = await videoTranscoderHandler.TranscodeVideoAsync(TroopDetails.SecondVideoEvidencePath);

                if (string.IsNullOrEmpty(videoThumbnailPath))
                    videoThumbnailPath = await videoTranscoderHandler.GenerateThumbnail(secondVideoEvidencePath);
            }

            if (!string.IsNullOrEmpty(TroopDetails.ThirdVideoEvidencePath))
            {
                thirdVideoEvidencePath = await videoTranscoderHandler.TranscodeVideoAsync(TroopDetails.ThirdVideoEvidencePath);

                if (string.IsNullOrEmpty(videoThumbnailPath))
                    videoThumbnailPath = await videoTranscoderHandler.GenerateThumbnail(thirdVideoEvidencePath);
            }

            await UploadFiles(!string.IsNullOrEmpty(TroopDetails.FirstEvidencePath) ? TroopDetails.FirstEvidencePath : firstVideoEvidencePath);

            await UploadFiles(!string.IsNullOrEmpty(TroopDetails.SecondEvidencePath) ? TroopDetails.SecondEvidencePath : secondVideoEvidencePath);

            await UploadFiles(!string.IsNullOrEmpty(TroopDetails.ThirdEvidencePath) ? TroopDetails.ThirdEvidencePath : thirdVideoEvidencePath);

            await UploadFiles(videoThumbnailPath, true);

            if (System.IO.File.Exists(firstVideoEvidencePath))
                System.IO.File.Delete(firstVideoEvidencePath);

            if (System.IO.File.Exists(secondVideoEvidencePath))
                System.IO.File.Delete(secondVideoEvidencePath);

            if (System.IO.File.Exists(thirdVideoEvidencePath))
                System.IO.File.Delete(thirdVideoEvidencePath);

            if (System.IO.File.Exists(videoThumbnailPath))
                System.IO.File.Delete(videoThumbnailPath);

            _dialogsHelper.HideDialog();
            //

            await Shell.Current.GoToAsync(nameof(NewMarketPage));
        }

        private async Task CancelPublish()
        {
            if (!await _dialogsHelper.ShowConfirmAsync("¿Está seguro que quiere cancelar la creación del prenegocio?"))
                return;

            await Shell.Current.GoToAsync("..");
        }

        private async Task PrebusinessCreationValidate() => await PopupNavigation.Instance.PushAsync(new PrebusinessValidateFinishPopupPage());

        private async Task PrebusinessCreation() => await PopupNavigation.Instance.PushAsync(new PrebusinessFinishPopupPage());

        private async Task UploadFiles(string filePath, bool isThumbnail = false)
        {
            if (string.IsNullOrEmpty(filePath))
                return;

            var fileName = filePath.Split('/').Last();

            var fileHandle = await _dealsService.BeginFileUploadAsync(fileName);

            var fileStream = System.IO.File.OpenRead(filePath);

            try
            {
                // Enviar archivo en pedazos de 512 KB a la vez
                int maxChunkSize = (512 * 1024);
                var buffer = new byte[maxChunkSize];
                long fileSize = 0;
                long totalBytesRead = 0;

                var bytesRead = 0;
                fileSize = fileStream.Length;

                do
                {
                    var position = fileStream.Position;
                    bytesRead = await fileStream.ReadAsync(buffer, 0, buffer.Length);

                    // Si los bytes leídos son más pequeños que el búfer, se enviará el último trozo.
                    // Reduce el buffer para que quepan los últimos bytes para optimizar el uso de la memoria.
                    if (bytesRead < buffer.Length)
                        Array.Resize(ref buffer, bytesRead);

                    var base64Data = Convert.ToBase64String(buffer);

                    var chunk = new MediaChunk
                    {
                        FileHandle = fileHandle,
                        Data = base64Data,
                        StartAt = position.ToString()
                    };

                    await _dealsService.UploadChunkAsync(chunk);

                    totalBytesRead += bytesRead;
                } while (bytesRead > 0);



                await _dealsService.EndFileUploadAsync(fileHandle, fileSize, _dealId, isThumbnail);
            }
            finally
            {
                fileStream.Close();
            }
        }
    }
}
