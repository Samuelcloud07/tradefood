﻿using System.Threading.Tasks;

namespace TradeFood.SecureRepository
{
    public interface ISecureStorageRepository
    {
        Task<string> GetAccessToken();

        Task SetAccessToken(string accessToken);
    }
}