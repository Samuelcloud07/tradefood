﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace TradeFood.ApiClient
{
    public class HttpLoggingHandler : DelegatingHandler
    {
        private readonly string[] types = { "html", "text", "xml", "json", "txt", "x-www-form-urlencoded" };

        public HttpLoggingHandler(HttpMessageHandler innerHandler = null)
            : base(innerHandler ?? new HttpClientHandler())
        {
        }

        //protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        //{
        //    var totalElapsedTime = Stopwatch.StartNew();

        //    Debug.WriteLine("========Request Start========");
        //    Debug.WriteLine($"Request: {request}");
        //    if (request.Content != null)
        //    {
        //        var content = await request.Content.ReadAsStringAsync().ConfigureAwait(false);
        //        Debug.WriteLine($"Request Content: {content}");
        //    }
        //    Debug.WriteLine("========Request End========");
        //    Debug.Write("========Response Start========");

        //    var responseElapsedTime = Stopwatch.StartNew();
        //    var response = await base.SendAsync(request, cancellationToken);

        //    Debug.WriteLine($"Response: {response}");
        //    if (response.Content != null)
        //    {
        //        var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
        //        Debug.WriteLine($"Response Content: {content}");
        //    }

        //    responseElapsedTime.Stop();
        //    Debug.WriteLine($"Response elapsed time: {responseElapsedTime.ElapsedMilliseconds} ms.");

        //    totalElapsedTime.Stop();
        //    Debug.WriteLine($"Total elapsed time: {totalElapsedTime.ElapsedMilliseconds} ms.");

        //    Debug.Write("========Response End========");

        //    return response;
        //}

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            await Task.Delay(1, cancellationToken).ConfigureAwait(false);

            var start = DateTime.Now;
            var msg = $"{request.RequestUri.PathAndQuery} - Request";

            Debug.WriteLine($"{msg}========Request Start========");
            Debug.WriteLine($"{msg} {request.Method} {request.RequestUri.PathAndQuery} {request.RequestUri.Scheme}/{request.Version}");
            Debug.WriteLine($"{msg} Host: {request.RequestUri.Scheme}://{request.RequestUri.Host}");

            foreach (var header in request.Headers)
                Debug.WriteLine($"{msg} {header.Key}: {string.Join(", ", header.Value)}");

            if (request.Content != null)
            {
                foreach (var header in request.Content.Headers)
                    Debug.WriteLine($"{msg} {header.Key}: {string.Join(", ", header.Value)}");

                Debug.WriteLine($"{msg} Content:");

                if (request.Content is StringContent || IsTextBasedContentType(request.Headers) || IsTextBasedContentType(request.Content.Headers))
                {
                    var result = await request.Content.ReadAsStringAsync();

                    Debug.WriteLine($"{msg} {string.Join("", result.Cast<char>().Take(256))}...");
                }
            }

            var response = await base.SendAsync(request, cancellationToken).ConfigureAwait(false);

            Debug.WriteLine($"{msg}========Request End========");

            msg = $"[{request.RequestUri.PathAndQuery} - Response]";

            Debug.Write($"{msg}========Response Start========");

            Debug.WriteLine($"{msg} {request.RequestUri.Scheme.ToUpper()}/{response.Version} {(int)response.StatusCode}{response.ReasonPhrase}");

            foreach (var header in response.Headers)
                Debug.WriteLine($"{msg} {header.Key}: {string.Join(", ", header.Value)}");

            if (response.Content != null)
            {
                foreach (var header in response.Content.Headers)
                    Debug.WriteLine($"{msg} {header.Key}: {string.Join(", ", header.Value)}");

                Debug.WriteLine($"{msg} Content:");

                if (response.Content is StringContent || IsTextBasedContentType(response.Headers) || IsTextBasedContentType(response.Content.Headers))
                {
                    var result = await response.Content.ReadAsStringAsync();

                    Debug.WriteLine($"{msg} {string.Join("", result.Cast<char>().Take(256))}...");
                }
            }

            Debug.WriteLine($"{msg} Duration: {DateTime.Now - start}");
            Debug.Write($"{msg}========Response End========");

            return response;
        }

        private bool IsTextBasedContentType(HttpHeaders headers)
        {
            if (!headers.TryGetValues("Content-Type", out IEnumerable<string> values))
                return false;

            var header = string.Join(" ", values).ToLowerInvariant();

            return types.Any(t => header.Contains(t));
        }
    }
}