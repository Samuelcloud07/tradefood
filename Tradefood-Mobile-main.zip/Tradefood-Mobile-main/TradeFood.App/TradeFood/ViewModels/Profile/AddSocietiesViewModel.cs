﻿using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Extensions;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.ViewModels.Profile
{
    public class AddSocietiesViewModel : BaseViewModel
    {
        private readonly IStatesService _statesServices;
        private readonly IDialogsHelper _dialogsHelper;
        private readonly IAppSettings _appSettings;
        private readonly IProfileService _profileService;

        long UserId = 0;
        private List<ProvinceLocation> _locations = new List<ProvinceLocation>();

        public AddSocietiesViewModel(ILogger logger,
                                   IStatesService statesService,
                                   IDialogsHelper dialogsHelper,
                                   IAppSettings appSettings,
                                   IProfileService profileService)
                                   : base(logger)
        {
            _statesServices = statesService;
            _dialogsHelper = dialogsHelper;
            _appSettings = appSettings;
            _profileService = profileService;

            SelectProvinceCommand = new SandboxedCommand(SelectProvince);
            PickLocationCommand = new SandboxedCommand(PickLocation);
            AddSocietiesCommand = new SandboxedCommand(AddSocieties);
        }
        //Properties
        public List<ProvinceLocation> Provinces { get; private set; } = new List<ProvinceLocation>();
        public List<ProvinceLocation> Locations { get; private set; } = new List<ProvinceLocation>();

        //Razon social
        public string NameSocieties { get; set; }
        public string Cuit { get; set; }
        public string ReferencesComercial { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        //Address
        public ProvinceLocation ProvinceSelected { get; set; }
        public ProvinceLocation LocationSelected { get; set; }
        public string LocationTitle { get; set; }
        public int DefaultProvinceSelected { get; set; } = 0;
        public string Street { get; set; } = "";
        public int? Number { get; set; } = null;
        public bool WithoutNumber { get; set; }
        public string ZipCode { get; set; }
        public string FloorDepartment { get; set; }
        public string Observations { get; set; }
        // Errors
        public bool HasErrors { get; set; }
        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();

        //Commands
        public SandboxedCommand SelectProvinceCommand { get; private set; }
        public SandboxedCommand PickLocationCommand { get; private set; }
        public SandboxedCommand AddSocietiesCommand { get; private set; }

        //Methods
        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            Provinces = await _statesServices.GetProvincesAsync();

            UserId = (long)Convert.ToDouble(_appSettings.UserId);

            DefaultProvinceSelected = 0;
            this.OnPropertyChanged(nameof(DefaultProvinceSelected));
        }

        public async Task SelectProvince()
        {
            //Locations = await _statesServices.GetLocationsForProvinceAsync(ProvinceSelected.Name);
            _dialogsHelper.ShowDialog();

            _locations.Clear();

            var locations = await _statesServices.GetLocationsForProvinceAsync(ProvinceSelected.Name);

            _locations.AddRange(locations);

            //LocationVisible = true;

            LocationTitle = Strings.SearchLocation;

            _dialogsHelper.HideDialog();
        }
        private async Task PickLocation()
        {
            await PopupNavigation.Instance.PushAsync(new LocationPopupPage(_locations));
        }

        public async Task AddSocieties()
        {
            if (!ValidateAll())
                return;

            var newAddress = new AddressDto
            {
                State = ProvinceSelected.Name,
                Location = LocationSelected.Name,
                Street = Street,
                Number = (int)Number,
                WithoutNumber = WithoutNumber,
                ZipCode = ZipCode,
                FloorDepartment = FloorDepartment,
                Observations = Observations
            };

            var addSocieties = new SocietiesAndPersonDto
            {
                Type = (Enums.TypeSocieties)1,
                Name = NameSocieties,
                Cuit = Cuit,
                CommercialReference = ReferencesComercial,
                Email = Email,
                ContactNumber = ContactNumber,
                Addresses = new List<AddressDto>()
            };

            addSocieties.Addresses.Add(newAddress);

            await _profileService.AddSocietiesAndPersonsAsync(UserId, addSocieties);

            MessagingCenter.Send<AddSocietiesViewModel>(this, "SociedadAgregada");

            await Shell.Current.GoToAsync("..");
        }

        private bool ValidateAll()
        {
            Errors.Clear();

            // Colocar validaciones
            if (String.IsNullOrEmpty(NameSocieties))
            {
                Errors.Add(nameof(NameSocieties), Strings.YouMustEnterABusinessName);
            }

            if (String.IsNullOrEmpty(Cuit))
            {
                Errors.Add(nameof(Cuit), Strings.YouMustEnterACuit);
            }

            if (String.IsNullOrEmpty(ReferencesComercial))
            {
                Errors.Add(nameof(ReferencesComercial), Strings.YouMustEnterAReferencesComercial);
            }

            if (String.IsNullOrEmpty(Email))
            {
                Errors.Add(nameof(Email), Strings.YouMustEnterAEmail);
            }
            else if (!Email.IsValidEmail())
            {
                Errors.Add(nameof(Email), Strings.TheEmailAddressIsInvalid);
            }

            if (String.IsNullOrEmpty(ContactNumber))
            {
                Errors.Add(nameof(ContactNumber), Strings.YouMustEnterAContactNumber);
            }

            if (ProvinceSelected == null)
            {
                Errors.Add(nameof(ProvinceSelected), Strings.YouMustEnterAProvince);
            }

            if (LocationSelected == null && ProvinceSelected != null)
            {
                Errors.Add(nameof(ProvinceSelected), Strings.YouMustEnterALocation);
            }

            if (String.IsNullOrEmpty(Street))
            {
                Errors.Add(nameof(Street), Strings.YouMustEnterAStreet);
            }

            if (Number == null)
            {
                Errors.Add(nameof(Number), Strings.YouMustEnterANumber);
            }

            if (String.IsNullOrEmpty(ZipCode))
            {
                Errors.Add(nameof(ZipCode), Strings.YouMustEnterAZipCode);
            }
            //---------------------------------------

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }
    }
}
