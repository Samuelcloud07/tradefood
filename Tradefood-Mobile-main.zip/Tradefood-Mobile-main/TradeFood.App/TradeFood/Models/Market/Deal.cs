﻿using System;
using System.Collections.Generic;
using TradeFood.Enums;

namespace TradeFood.Models
{
    public class Deal
    {
        
        public string DealId { get; set; }

        public DealStatus DealStatus { get; set; }

        public string CreatedBy { get; set; }

        public string TroopCategory { get; set; }

        public string TroopType { get; set; }

        public string Amount { get; set; }

        public string Destination { get; set; }

        public string GeographicDestination { get; set; }

        public string WeightAmount { get; set; }

        public List<File> EvidenceFiles { get; set; }

        public string DealThumbnails { get; set; }

        public string Comments { get; set; }

        public string SuggestedPrice { get; set; }

        public string PaymentMethod { get; set; }

        public string FinancingCategory { get; set; }

        public string Province { get; set; }

        public string Location { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public string PersonInCharge { get; set; }

    }
}