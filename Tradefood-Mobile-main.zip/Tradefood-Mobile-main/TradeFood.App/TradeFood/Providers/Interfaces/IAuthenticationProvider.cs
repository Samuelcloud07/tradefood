﻿using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public interface IAuthenticationProvider
    {
        Task<LoginResponse> LoginAsync(SignIn signIn);

        Task<RequestNewPasswordResponse> RequestPasswordResetAsync(string email);

        Task ResetPasswordAsync(ResetUserPassword resetUserPassword);

        Task<LoginResponse> SignUpAsync(SignUp signUp);

        Task<LoginResponse> ConfirmEmailAsync(EmailConfirmation emailConfirmation);

        Task ResendEmailConfirmationAsync(string email);

        Task ChangePasswordAsync(ResetUserPassword resetUserPassword);
    }
}