﻿using Newtonsoft.Json;
using System.ComponentModel;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Enums;
using TradeFood.Models;
using TradeFood.Views;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class DealItemViewModel : INotifyPropertyChanged
    {
        public DealItemViewModel(Deal dealItem,
                                 ClientType clientType)
        {
            Deal = dealItem;

            if (dealItem.EvidenceFiles.Count > 0)
            {
                if (!string.IsNullOrEmpty(dealItem.EvidenceFiles[0].FilePath))
                    FirstEvidencePath = dealItem.EvidenceFiles[0].FilePath;
            }

            DealThumbnail = dealItem.DealThumbnails;

            if (clientType == ClientType.Productor_Empresa || clientType == ClientType.Productor_Persona || clientType == ClientType.Comisionista)
                PriceVisible = true;

            OpenDealDetailsCommand = new SandboxedCommand(OpenDealDetails);
        }

        // Properties
        public Deal Deal { get; private set; }

        // Commands
        public SandboxedCommand OpenDealDetailsCommand { get; private set; }

        public string FirstEvidencePath { get; private set; }

        public string DealThumbnail { get; private set; }

        public bool PriceVisible { get; private set; }

        // Methods
        private async Task OpenDealDetails()
        {
            var dealDeails = JsonConvert.SerializeObject(Deal);

            await Shell.Current.GoToAsync($"{nameof(DealDetailsPage)}?dealDetails={dealDeails}");
        }

        // INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}