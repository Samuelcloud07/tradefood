﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class DisplayNameToInitialsConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (string.IsNullOrEmpty((string)value) || string.IsNullOrWhiteSpace((string)value))
                return "?";

            string[] splited = ((string)value).Split(new char[0], StringSplitOptions.RemoveEmptyEntries);

            return splited.Length > 1
                ? $"{splited[0].Substring(0, 1)}{splited[1].Substring(0, 1)}"
                : $"{splited[0].Substring(0, 1)}";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}