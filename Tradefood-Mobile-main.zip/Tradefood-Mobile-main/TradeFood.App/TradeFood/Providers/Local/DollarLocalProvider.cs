﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Exceptions;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class DollarLocalProvider : IDollarLocalProvider
    {
        public Task<List<DollarData>> GetDollarQuotesAsync()
        {
            throw new NoInternetException();
        }
    }
}