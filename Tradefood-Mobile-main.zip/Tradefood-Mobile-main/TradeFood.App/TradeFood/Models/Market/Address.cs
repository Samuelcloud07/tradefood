﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market
{
    public class Address
    {
        public long Id { get; set; }
        public string State { get; set; }
        public string Location { get; set; }
        public string Street { get; set; }
        public int Number { get; set; }
        public bool WithoutNumber { get; set; }
        public string ZipCode { get; set; }
        public string FloorDepartment { get; set; }
        public string Observations { get; set; }
        public long TradeFoodClientId { get; set; }
        public long? SocietiesAndPersonId { get; set; }
    }
}
