﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;

namespace TradeFood.ViewModels
{
    class ProfilePreferencesCompleteViewModel : BaseViewModel
    {
        private readonly IProfileService _profileService;
        private readonly IAppSettings _appSettings;
        public ProfilePreferencesCompleteViewModel(ILogger logger,
                                    IAppSettings appSettings,
                                    IProfileService profileService)
            : base(logger)
        {
            _appSettings = appSettings;
            _profileService = profileService;
        }

        protected override async Task InitializeAsync()
        {
            PreferencesObject = await _profileService.GetProfilePreferences(long.Parse(_appSettings.UserId));
            WinteringCategories = PreferencesObject.WinteringCategory;
            ChoreCategories = PreferencesObject.ChoreCategory;
            ChoreSubCategories = PreferencesObject.ChoreSubCategory;
            GeographicDestination = PreferencesObject.DestinationChore;
            PaymentTermsWintering = PreferencesObject.PaymentTerms.Where((payment) => payment.BusinessType.Equals("wintering")).ToList();
            PaymentTermsChore = PreferencesObject.PaymentTerms.Where((payment) => payment.BusinessType.Equals("chore")).ToList();
            IsWinteringNotification = PreferencesObject.IsBusinessTypeWintering;
            IsChoreNotification = PreferencesObject.IsBusinessTypeChore;

            await base.InitializeAsync();
        }

        public PreferencesDto PreferencesObject { get; set; }

        //Wintering
        public List<PaymentTermDto> PaymentTermsWintering { get; set; } = new List<PaymentTermDto>();

        public string WinteringCategories { get; set; }

        //Chore

        public string ChoreCategories { get; set; }

        public string ChoreSubCategories { get; set; }

        public string GeographicDestination { get; set; }

        public List<PaymentTermDto> PaymentTermsChore { get; set; } = new List<PaymentTermDto>();

        // Used for collectionview height
        public int HeightPaymentTermsSelectedWintering { get; set; }

        public int HeightRangePaymentTermsWintering { get; set; }

        public int HeightPaymentTermsSelectedChore { get; set; }

        public int HeightRangePaymentTermsChore { get; set; }

        // Used for hide
        public bool IsWinteringNotification { get; set; }

        public bool IsChoreNotification { get; set; }

        public bool ShowPrebusinessDetail { get; set; }

        public bool ShowTroopDetail { get; set; }

        public bool ShowEditIconPrebusinessDetail { get; set; }

        public bool ShowCheckIconPrebusinessDetail { get; set; } = true;

        public bool ShowEditIconTroopDetail { get; set; }

        public bool ShowCheckIconTroopDetail { get; set; } = true;

        public bool ShowSubCategories { get; set; }

    }
}
