using Acr.UserDialogs;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Models.Market;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels.Items;
using TradeFood.Views;
using Xamarin.Forms;

namespace TradeFood.ViewModels.Market
{
    internal class DealsFiltersViewModel : BaseViewModel
    {
        private readonly IDealsService _dealsService;
        private readonly IStatesService _statesService;
        private readonly IMediaHelper _mediaHelper;
        private readonly IDialogsHelper _dialogsHelper;
        private readonly IAppSettings _appSettings;
        private readonly IUserDialogs _userDialogs;

        public DealsFiltersViewModel(ILogger logger,
                                   IDealsService dealsService,
                                   IStatesService statesService,
                                   IMediaHelper mediaHelper,
                                   IDialogsHelper dialogsHelper,
                                   IAppSettings appSettings,
                                   IUserDialogs userDialogs)
            : base(logger)
        {
            _dealsService = dealsService;
            _statesService = statesService;
            _mediaHelper = mediaHelper;
            _dialogsHelper = dialogsHelper;
            _appSettings = appSettings;
            _userDialogs = userDialogs;

            ApplyFiltersCommand = new SandboxedCommand(ApplyFilters);

            MinWeightOptions = new List<string>
            {
                "100","200","300","400","500","600"
            };

            MaxWeightOptions = new List<string>
            {
                "200","300","400","500","600","700"
            };

            MaxPriceOptions = new List<string>();
            MinPriceOptions = new List<string>();

            for (var i = 100; i <= 1000; i = i + 100)
            {
                MaxPriceOptions.Add(i.ToString());
                MinPriceOptions.Add(i.ToString());
            }
            MinPriceOptions.RemoveAt(MinPriceOptions.Count - 1);
            MaxPriceOptions.RemoveAt(0);
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            WinteringCategories = new ObservableCollection<TroopCategoryItemViewModel>
            {
                new TroopCategoryItemViewModel("Terneros","Male"){Selected=true},
                new TroopCategoryItemViewModel("Terneras","Female"){Selected=true},
                new TroopCategoryItemViewModel("Vacas","Female"){Selected=true},
                new TroopCategoryItemViewModel("Novillitos","Male"){Selected=true},
                new TroopCategoryItemViewModel("Vaquillonas","Female"){Selected=true}
            };

            ChoreCategories = new ObservableCollection<TroopCategoryItemViewModel>
            {
                new TroopCategoryItemViewModel("Novillos","Male"){Selected=true},
                new TroopCategoryItemViewModel("Mej","Male"){Selected=true},
                new TroopCategoryItemViewModel("Novillitos","Male"){Selected=true},
                new TroopCategoryItemViewModel("Vaquillonas","Female"){Selected=true},
                new TroopCategoryItemViewModel("Vacas","Female"){Selected=true},
                new TroopCategoryItemViewModel("Toros","Male"){Selected=true}
            };

            WinteringHeight = WinteringCategories.Count * 40;
            ChoreHeight = ChoreCategories.Count * 40;
        }

        //Properties

        private bool _showForm { get; set; } = false;
        public bool ShowForm
        {
            get { return _showForm; }
            set
            {
                _showForm = value;
                this.OnPropertyChanged(nameof(ShowForm));
            }
        }

        //Commands
        public SandboxedCommand ApplyFiltersCommand { get; private set; }


        //Properties
        public ObservableCollection<TroopCategoryItemViewModel> WinteringCategories { get; set; }
        public ObservableCollection<TroopCategoryItemViewModel> ChoreCategories { get; set; }

        private List<ProvinceLocation> _locations = new List<ProvinceLocation>();

        public string _businessTypeSelected;
        public int WinteringHeight { get; set; }
        public int ChoreHeight { get; set; }
        public string BusinessTypeSelected
        {
            get => _businessTypeSelected;
            set
            {
                _businessTypeSelected = value;

                this.OnPropertyChanged(nameof(BusinessTypeSelected));
            }
        }
        public bool IsDestinationVisible { get; set; } = false;
        public bool IsTypeVisible { get; set; } = false;
        public bool IsOddOrUnoddVisible { get; set; } = false;
        public bool IsDirtyZoneVisible { get; set; } = false;

        public string _troopWeightTypeSelected;
        public string TroopWeightTypeSelected
        {
            get => _troopWeightTypeSelected;
            set
            {
                _troopWeightTypeSelected = value;

                this.OnPropertyChanged(nameof(TroopWeightTypeSelected));
            }
        }
        public List<string> MinWeightOptions { get; set; }
        public List<string> MaxWeightOptions { get; set; }
        public string ChoreMinWeightSelected { get; set; } = "100";
        public string ChoreMaxWeigthSelected { get; set; } = "700";
        public string WinteringMinWeightSelected { get; set; } = "100";
        public string WinteringMaxWeightSelected { get; set; } = "700";
        public string MinPriceSelected { get; set; } = "100";
        public string MaxPriceSelected { get; set; } = "1000";
        public List<string> MinPriceOptions { get; set; }
        public List<string> MaxPriceOptions { get; set; }

        public async Task ApplyFilters()
        {
            var listCategoriesSelected = new List<TroopCategory>();

            foreach (var c in ChoreCategories)
            {
                if (c.Selected == true)
                {
                    listCategoriesSelected.Add(
                    new TroopCategory
                    {
                        Name = c.Name,
                        Gender = c.Gender,
                        AverageWeightAmount = c.AverageWeight
                    });
                }
            }

            foreach (var c in WinteringCategories)
            {
                if (c.Selected == true)
                {
                    listCategoriesSelected.Add(
                    new TroopCategory
                    {
                        Name = c.Name,
                        Gender = c.Gender,
                        AverageWeightAmount = c.AverageWeight
                    });
                }
            }

            var dealFilters = new NewDealFilters
            {
                CategoriesSelected = listCategoriesSelected,
                WinteringMinWeight = int.Parse(WinteringMinWeightSelected),
                WinteringMaxWeight = int.Parse(WinteringMaxWeightSelected),
                ChoreMinWeight = int.Parse(ChoreMinWeightSelected),
                ChoreMaxWeight = int.Parse(ChoreMaxWeigthSelected),
                MinPrice = int.Parse(MinPriceSelected),
                MaxPrice = int.Parse(MaxPriceSelected)
            };

            MessagingCenter.Send<NewMarketPage, NewDealFilters>(new NewMarketPage(), "filters", dealFilters);

            await Shell.Current.Navigation.PopAsync();
        }


    }
}
