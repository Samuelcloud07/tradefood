﻿using Polly;
using Refit;
using System;
using System.Net;
using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.Exceptions;

namespace TradeFood.Providers
{
    public class BaseApiProvider
    {
        private readonly IAppHttpClient _httpClientSingleton;
        private readonly IApiExceptionManager _apiExceptionManager;

        protected BaseApiProvider(IAppHttpClient httpClientSingleton,
                                  IApiExceptionManager apiExceptionManager)
        {
            _httpClientSingleton = httpClientSingleton;
            _apiExceptionManager = apiExceptionManager;
        }

        protected T GetRestServiceFor<T>() => RestService.For<T>(
            _httpClientSingleton.HttpClient,
            new RefitSettings { ContentSerializer = new NewtonsoftJsonContentSerializer() }
        );

        protected async Task ExecuteRequest(Func<Task> action)
        {
            try
            {
                await Policy.Handle<WebException>().WaitAndRetryAsync(4, WebExceptionHandleRetryAttempt)
                    .ExecuteAsync(action)
                    .ConfigureAwait(false);
            }
            catch (ApiException ex)
            {
                await _apiExceptionManager.HandleHttpStatusCodeAsync(ex).ConfigureAwait(false);
            }
        }

        protected async Task<TResult> ExecuteRequest<TResult>(Func<Task<TResult>> action)
        {
            try
            {
                return await Policy<TResult>.Handle<WebException>().WaitAndRetryAsync(4, WebExceptionHandleRetryAttempt)
                    .ExecuteAsync(action)
                    .ConfigureAwait(false);
            }
            catch (ApiException ex)
            {
                return await _apiExceptionManager.HandleHttpStatusCodeAsync<TResult>(ex).ConfigureAwait(false);
            }
        }

        private TimeSpan WebExceptionHandleRetryAttempt(int retryAttempt)
        {
            if (retryAttempt < 4)
                return TimeSpan.FromMilliseconds(300 * retryAttempt);

            throw new NoInternetException();
        }
    }
}