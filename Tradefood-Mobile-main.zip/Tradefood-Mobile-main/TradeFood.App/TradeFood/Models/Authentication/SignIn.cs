﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class SignIn
    {
        [JsonProperty("idIssued")]
        public long IdIssued { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }
    }
}