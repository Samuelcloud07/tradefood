﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using TradeFood.Models;

namespace TradeFood.ViewModels
{
    public class ProvinceAndLocationItemViewModel : INotifyPropertyChanged
    {
        public ProvinceAndLocationItemViewModel(string name)
        {
            ProvinceName = name;
        }
        public string ProvinceName { get; set; }
        public List<ProvinceLocation> Locations { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
