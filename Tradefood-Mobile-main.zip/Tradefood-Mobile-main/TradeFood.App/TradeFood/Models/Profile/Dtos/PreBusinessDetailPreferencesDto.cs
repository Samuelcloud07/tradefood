﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeFood.ViewModels;

namespace TradeFood.Models.Profile.Dtos
{
    public class PreBusinessDetailPreferencesDto
    {
        public List<ProvinceOrLocationItemViewModel> ProvincesWinteringSelected { get; set; } = new List<ProvinceOrLocationItemViewModel>();
        public List<ProvinceOrLocationItemViewModel> ProvincesChoreSelected { get; set; } = new List<ProvinceOrLocationItemViewModel>();
        public List<PaymentTermsItemViewModel> WinteringPaymentTermsSelected { get; set; } =
        new List<PaymentTermsItemViewModel>();

        public List<PaymentTermsItemViewModel> ChorePaymentTermsSelected { get; set; } =
        new List<PaymentTermsItemViewModel>();
    }
}
