﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using Xamarin.Essentials;

namespace TradeFood.ViewModels
{
    public class InquiriesViewModel : BaseViewModel
    {
        private readonly IAppSettings _appSettings;

        private readonly string _questions;

        public InquiriesViewModel(ILogger logger,
                                  IAppSettings appSettings)
            : base(logger)
        {
            _appSettings = appSettings;

            _questions = 
                $"1. ¿Cuál es el precio de referencia de mercado Liniers?" +
                $"{Environment.NewLine}" +
                $"2. ¿Cómo cargo un lote/pre-negocio dentro de la plataforma?" +
                $"{Environment.NewLine}" +
                $"3. ¿Qué características debe tener la filmación para que sea buena?" +
                $"{Environment.NewLine}" +
                $"4. ¿Que documentación necesito para generar un pre negocio?";

            PostNewQuestionCommand = new SandboxedCommand(PostNewQuestion);
        }

        public override void OnAppearing()
        {
            base.OnAppearing();

            Inquiries.Clear();

            AddNewInquirie($"Buenos días {_appSettings.UserName}!{Environment.NewLine}¿En qué puedo ayudarte?", string.Empty, false, true);

            AddNewInquirie(_questions, string.Empty, false, false);
        }

        // Properties
        public ObservableCollection<InquirieItemViewModel> Inquiries { get; private set; } = new ObservableCollection<InquirieItemViewModel>();

        public string NewQuestion { get; set; }

        // Commands
        public SandboxedCommand PostNewQuestionCommand { get; private set; }

        // Methods
        private async Task PostNewQuestion()
        {
            AddNewInquirie(NewQuestion, _appSettings.UserName, true);

            var response = SetChatbotResponse();

            await MainThread.InvokeOnMainThreadAsync(() =>
            {
                AddNewInquirie(response, string.Empty, false, true);

                AddNewInquirie(_questions, string.Empty, false, false);

                NewQuestion = string.Empty;

                this.OnPropertyChanged(nameof(Inquiries));
            });
        }

        private void AddNewInquirie(string text, string username = "", bool isUserPost = false, bool isPreviousUserPost = false)
        {
            Inquiries.Add(new InquirieItemViewModel(text, username, isUserPost, isPreviousUserPost));
        }

        private string SetChatbotResponse()
        {
            switch (NewQuestion)
            {
                case "1":
                    return "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";

                case "2":
                    return "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

                case "3":
                    return "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.";

                case "4":
                    return "Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.";

                default:
                    return $"Lo sentimos, esa no es una opción válida." +
                        $"{Environment.NewLine}" +
                        $"{Environment.NewLine}" +
                        $"Por favor ingresa una de las siguientes opciones:";
            }
        }
    }
}