﻿using System.ComponentModel;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Models;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class AgroNewsItemViewModel : INotifyPropertyChanged
    {
        public AgroNewsItemViewModel(NewsReport newsReport)
        {
            Report = newsReport;

            ViewFullReportCommand = new SandboxedCommand(ViewFullReport);
        }

        // Properties
        public NewsReport Report { get; private set; }

        // Commands
        public SandboxedCommand ViewFullReportCommand { get; private set; }

        // Methods
        private async Task ViewFullReport()
        {
            await Browser.OpenAsync(Report.Url, new BrowserLaunchOptions
            {
                LaunchMode = BrowserLaunchMode.SystemPreferred,
                TitleMode = BrowserTitleMode.Show,
                PreferredToolbarColor = Color.FromHex("#7B1E21"),
                PreferredControlColor = Color.White
            });
        }


        // INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}