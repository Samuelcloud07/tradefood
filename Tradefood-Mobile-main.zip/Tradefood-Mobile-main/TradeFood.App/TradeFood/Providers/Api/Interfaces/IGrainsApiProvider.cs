﻿namespace TradeFood.Providers
{
    public interface IGrainsApiProvider : IGrainsProvider
    {
    }
}