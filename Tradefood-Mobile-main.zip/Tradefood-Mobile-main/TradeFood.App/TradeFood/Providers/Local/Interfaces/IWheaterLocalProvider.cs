﻿namespace TradeFood.Providers
{
    public interface IWheaterLocalProvider : IWheaterProvider
    {
    }
}