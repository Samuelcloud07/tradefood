﻿using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Enums;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Settings;
using TradeFood.Views;
using TradeFood.Views.Popups;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class SocietyOrPersonItemViewModel : INotifyPropertyChanged
    {

        private readonly IAppSettings _appSettings;

        public SocietyOrPersonItemViewModel()
        {
            GoToOptionsFirstCommand = new SandboxedCommand(GoToOptionsFirst);

            GoToOptionsCommand = new SandboxedCommand(GoToOptions);

            GoToAdressCommand = new SandboxedCommand(GoToAddres);

            GoToPersonalDataCommand = new SandboxedCommand(GoToPersonalData);

            _appSettings = TypeLocator.Resolve<IAppSettings>();

            ClientType = _appSettings.ClientType;


        }

        //Properties
        public string ClientType { get; set; }
        //Properties SocietyOrPerson
        public long id { get; set; }
        public bool IsActive { get; set; } //Pueden desactivar
        public TypeSocieties Type { get; set; }
        public string Name { get; set; }
        public string Cuit { get; set; }
        public string CommercialReference { get; set; }

        public bool IsComercialReference
        {
            get => CommercialReference.Equals(string.Empty);
        }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public IList<AddressDto> Addresses { get; set; } //Una razon social, tiene muchas direcciones.
        public int HeightAddresses { get; set; } = 50;

        public string Tag
        {
            get
            {
                if (Type == TypeSocieties.RazonSocial || Type == TypeSocieties.RazonMatarife)
                    return "SOCIEDAD";
                else
                    return "PERS. FISICA";
            }
        }

        private bool _selected;
        public bool Selected
        {
            get => _selected;
            set
            {
                _selected = value;
                OnPropertyChanged(nameof(Selected));
            }
        }

        public bool NotMatarife { get; set; }
        //Condicionales

        public string IsDniOrCuit
        {
            get
            {
                if (Type == TypeSocieties.PersonaFisica)
                {
                    return "DNI:";
                }
                else
                {
                    return "CUIT:";
                }

            }
        }

        public string PersonalData
        {
            get
            {
                switch (ClientType)
                {
                    case "Frigorífico":
                        return "Datos de Frigorífico";

                    default: return "Datos personales";
                }
            }
        }

        public string AddresTypeText
        {
            get
            {
                switch (ClientType)
                {
                    case "Productor_Persona":
                        if (Type == TypeSocieties.PersonaFisica)
                            return "Domicilio de la persona fisica:";
                        else
                            return "Domicilio de la sociedad:";
                    case "Productor_Empresa":
                        return "Domicilio de la sociedad:";
                    case "Comisionista":
                        if (Type == TypeSocieties.PersonaFisica)
                            return "Domicilio de la persona fisica:";
                        else
                            return "Domicilio de la sociedad:";
                    case "Consignataria":
                        return "Domicilio de la sociedad:";
                    case "Frigorífico":
                        if (Type == TypeSocieties.RazonMatarife)
                            return "Domicilio de establicimiento faenador:";
                        else
                            return "Domicilio de la sociedad:";
                    default: return "";
                }
            }
        }
        public string IsBusinessNameOrFarmAdressButton
        {
            get
            {
                if (Type == TypeSocieties.PersonaFisica)
                {
                    return "Agregar domicilio de la hacienda +";
                }
                else
                {
                    return "Agregar domicilio de la razón social +";
                }

            }
        }

        public bool DisplayFinancialData
        {
            get
            {
                if (Type == TypeSocieties.PersonaFisica)
                {
                    return true;
                }

                else
                {
                    return false;
                }

            }
        }

        // Commands
        public SandboxedCommand GoToOptionsFirstCommand { get; private set; }
        public SandboxedCommand GoToOptionsCommand { get; private set; }
        public SandboxedCommand GoToAdressCommand { get; private set; }

        public SandboxedCommand GoToPersonalDataCommand { get; private set; }

        //Methods
        private async Task GoToOptionsFirst()
        {
            await PopupNavigation.Instance.PushAsync(new SocietyOrPersonOptionsPopupPage(id, true));
        }

        private async Task GoToOptions()
        {
            await PopupNavigation.Instance.PushAsync(new SocietyOrPersonOptionsPopupPage(id, false));
        }

        private async Task GoToAddres()
        {
            if (DeviceInfo.Platform != DevicePlatform.UWP)
                await Shell.Current.GoToAsync($"AddAdressPage?idsocietiespersons={id}");
            else
                await PopupNavigation.Instance.PushAsync(new AddAdressPopupPage());
        }

        private async Task GoToPersonalData()
        {
            if (DeviceInfo.Platform != DevicePlatform.UWP)
                await Shell.Current.GoToAsync(nameof(PersonalDataPage));
            else
                await PopupNavigation.Instance.PushAsync(new AddReferencePopupPage());
        }



        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
