﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Models.Market.Dtos;
using TradeFood.Views;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class DealApiItemViewModel : INotifyPropertyChanged
    {
        public DealApiItemViewModel(DealApiDto deal)
        {
            Deal = deal;

            if (deal.EvidenceFiles.Count > 0)
            {
                if (!string.IsNullOrEmpty(deal.EvidenceFiles[0].FilePath))
                    FirstEvidencePath = deal.EvidenceFiles[0].FilePath;
            }

            DealThumbnail = deal.DealThumbnails;

            OpenDealDetailsCommand = new SandboxedCommand(OpenDealDetails);
        }

        //Properties
        public DealApiDto Deal { get; set; }
        public string FirstEvidencePath { get; private set; }
        public string DealThumbnail { get; private set; }
        public  SandboxedCommand OpenDealDetailsCommand { get; set; }


        //Methods
        private async Task OpenDealDetails()
        {
            string dealDetails = JsonConvert.SerializeObject(Deal);

            await Shell.Current.GoToAsync($"NewDealDetailsPage?dealDetails={dealDetails}");
        }

        //Interface implementation
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
