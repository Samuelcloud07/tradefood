﻿using System.Threading.Tasks;
using Xamarin.Essentials;

namespace TradeFood.SecureRepository
{
    public class SecureStorageRepository : ISecureStorageRepository
    {
        private const string ACCESS_TOKEN_KEY = "AccessToken";

        public async Task<string> GetAccessToken()
        {
            return await SecureStorage.GetAsync(ACCESS_TOKEN_KEY);
        }

        public async Task SetAccessToken(string accessToken)
        {
            await SecureStorage.SetAsync(ACCESS_TOKEN_KEY, accessToken);
        }
    }
}