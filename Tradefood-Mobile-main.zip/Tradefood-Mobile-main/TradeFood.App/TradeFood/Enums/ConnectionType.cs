﻿namespace TradeFood.Enums
{
    public enum ConnectionType
    {
        Disconnected,
        Connected
    }
}