﻿using Xamarin.Forms;

namespace TradeFood.Styles
{
    public partial class Colors : ResourceDictionary
    {
        public Colors()
        {
            InitializeComponent();
        }
    }
}