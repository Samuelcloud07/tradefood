﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market
{
    public class TroopStatus
    {
        public bool IsLiquidBrand { get; set; }
        public bool IsGelded { get; set; }
        public bool IsWeaned { get; set; }
        public string Healthy { get; set; }
        public string BodyState { get; set; }

    }
}
