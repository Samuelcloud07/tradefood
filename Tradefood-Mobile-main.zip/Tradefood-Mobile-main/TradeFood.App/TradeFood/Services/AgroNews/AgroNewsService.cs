﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Providers;

namespace TradeFood.Services
{
    public class AgroNewsService : IAgroNewsService
    {
        private readonly IProviderFactory _providerFactory;

        public AgroNewsService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }

        public Task<List<NewsReport>> GetAgroNewsAsync()
        {
            return _providerFactory.Create<IAgroNewsProvider>().GetAgroNewsAsync();
        }
    }
}