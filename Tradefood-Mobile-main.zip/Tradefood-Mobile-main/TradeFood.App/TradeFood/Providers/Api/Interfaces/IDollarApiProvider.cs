﻿namespace TradeFood.Providers
{
    public interface IDollarApiProvider : IDollarProvider
    {
    }
}