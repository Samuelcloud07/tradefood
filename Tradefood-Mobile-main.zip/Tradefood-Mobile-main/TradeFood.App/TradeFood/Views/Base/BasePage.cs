﻿using TradeFood.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace TradeFood.Views
{
    public class BasePage : ContentPage
    {
        public BasePage()
        {
            On<iOS>().SetUseSafeArea(true);
        }

        // Properties
        public BaseViewModel ViewModel => BindingContext as BaseViewModel;

        // Methods
        protected override void OnAppearing()
        {
            base.OnAppearing();

            this.SetupBinding(BindingContext);
        }

        protected override void OnDisappearing()
        {
            this.TearDownBinding(BindingContext);

            base.OnDisappearing();
        }

        protected void SetupBinding(object bindingContext)
        {
            if (bindingContext is BaseViewModel vm)
                vm.OnAppearing();
        }

        protected void TearDownBinding(object bindingContext)
        {
            if (bindingContext is BaseViewModel vm)
                vm.OnDisappearing();
        }
    }
}