﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using TradeFood.Models.Market;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    class TroopCategoryListToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var troopCategoriesList = (List<TroopCategory>)value;
            string categories = "";

            for (int i = 1; i <= troopCategoriesList.Count; i++)
            {
                categories += $"{troopCategoriesList[i - 1].Name}";

                if ((troopCategoriesList.Count - 2) >= i)
                    categories += ", ";

                if ((troopCategoriesList.Count - 2) < i && i < troopCategoriesList.Count)
                    categories += " y ";
            }

            return categories;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
