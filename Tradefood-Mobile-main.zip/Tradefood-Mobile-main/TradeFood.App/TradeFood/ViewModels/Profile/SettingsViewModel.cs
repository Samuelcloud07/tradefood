﻿using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Services.Loggin;
using TradeFood.Views;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    class SettingsViewModel : BaseViewModel
    {
        public SettingsViewModel(ILogger logger)
            :base(logger)
        {
            GoToChangePasswordCommand = new SandboxedCommand(GoToChagePassword);
        }

        //Commands
        public SandboxedCommand GoToChangePasswordCommand { get; private set; }

        //Methods

        public async Task GoToChagePassword() => await Shell.Current.GoToAsync(nameof(ChangePasswordPage));
    }
}