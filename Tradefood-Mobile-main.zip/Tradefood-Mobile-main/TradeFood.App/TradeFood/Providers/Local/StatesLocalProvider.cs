﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Exceptions;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class StatesLocalProvider : IStatesLocalProvider
    {
        public Task<List<ProvinceLocation>> GetProvincesAsync()
        {
            throw new NoInternetException();
        }

        public Task<List<ProvinceLocation>> GetLocationsForProvinceAsync(string provincia)
        {
            throw new NoInternetException();
        }
    }
}