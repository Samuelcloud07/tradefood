﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Models.Market.Dtos;
using TradeFood.Providers;

namespace TradeFood.Services
{
    public class DealsService : IDealsService
    {
        private readonly IProviderFactory _providerFactory;

        public DealsService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }

        public Task<List<Deal>> GetAllDealsAsync()
        {
            return _providerFactory.Create<IDealsProvider>().GetAllDealsAsync();
        }

        public Task<string> BeginFileUploadAsync(string fileName)
        {
            return _providerFactory.Create<IDealsProvider>().BeginFileUploadAsync(fileName);
        }

        public Task<bool> EndFileUploadAsync(string fileHandle, long fileSize, string dealId, bool isThumbnail)
        {
            return _providerFactory.Create<IDealsProvider>().EndFileUploadAsync(fileHandle, fileSize, dealId, isThumbnail);
        }

        public Task<Deal> CreateDealAsync(string userId, DealRequest deal)
        {
            return _providerFactory.Create<IDealsProvider>().CreateDealAsync(userId, deal);
        }

        public Task<bool> UploadChunkAsync(MediaChunk mediaChunk)
        {
            return _providerFactory.Create<IDealsProvider>().UploadChunkAsync(mediaChunk);
        }

        public Task<DealDto> CreateChoreDealAsync(string userId, DealDto deal)
        {
            return _providerFactory.Create<IDealsProvider>().CreateChoreDealAsync(userId, deal);
        }

        public Task<DealDto> CreateWinteringDealAsync(string userId, DealDto deal)
        {
            return _providerFactory.Create<IDealsProvider>().CreateWinteringDealAsync(userId, deal);
        }

        public Task<List<DealApiDto>> GetDealsAsync()
        {
            return _providerFactory.Create<IDealsProvider>().GetDealsAsync();
        }

        public Task<DealsStats> GetDealsStats()
        {
            return _providerFactory.Create<IDealsProvider>().GetDealsStats();
        }
    }
}