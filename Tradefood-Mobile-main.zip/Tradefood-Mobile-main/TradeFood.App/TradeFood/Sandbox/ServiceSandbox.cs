﻿using Acr.UserDialogs;
using TradeFood.Enums;
using TradeFood.Exceptions;
using TradeFood.Extensions;
using TradeFood.Resources;
using TradeFood.Services.Loggin;
using System;
using System.Threading.Tasks;
using TradeFood.Helpers;

namespace TradeFood.Sandbox
{
    public class ServiceSandbox : IServiceSandbox
    {
        private readonly ILogger _logger;
        private readonly IDialogsHelper _dialogsHelper;
        private readonly IUserDialogs _userDialogs;

        private bool noInternetExceptionAlertAlreadyOpen;

        public ServiceSandbox(ILogger logger,
                              IDialogsHelper dialogsHelper,
                              IUserDialogs userDialogs)
        {
            _logger = logger;
            _dialogsHelper = dialogsHelper;
            _userDialogs = userDialogs;
        }

        public async Task Run(Func<Task> task, bool isRunningInForeground = true)
        {
            _logger.LogEvent(AppLogLevel.Info, $"{task.Method.Name} Executed.");

            try
            {
                await Task.Yield();

                await task();
            }
            catch (NoInternetException)
            {
                if (isRunningInForeground)
                {
                    _dialogsHelper.HideDialog();

                    if (!noInternetExceptionAlertAlreadyOpen)
                    {
                        noInternetExceptionAlertAlreadyOpen = true;

                        await _dialogsHelper.ShowAlertAsync(Strings.WithoutConnectionPleaseTryAgainLater);

                        noInternetExceptionAlertAlreadyOpen = false;
                    }
                 }
            }
            catch (AggregateException ex)
            {
                _dialogsHelper.HideDialog();

                _logger.LogException(ex, ex.InnerException ?? null);
            }
            catch (NotFoundException ex)
            {
                if (isRunningInForeground)
                {
                    _dialogsHelper.HideDialog();

                    _dialogsHelper.ShowAlert(ex.Message);
                }

                _logger.LogException(ex, ex.InnerException ?? null);
            }
            catch (ServiceAuthenticationException ex)
            {
                if (isRunningInForeground)
                {
                    _dialogsHelper.HideDialog();

                    _dialogsHelper.ShowAlert(Strings.YouAreNotAuthorizedToDoThis, Strings.Error);

                    _logger.LogException(ex, ex.InnerException ?? null);
                }
            }
            catch (Exception genericEx) when(!(genericEx is NoInternetException)
                                             && !(genericEx is OperationCanceledException))
            {
                HandleUnHandledCrashException(genericEx, isRunningInForeground);
            }

        }

        private void HandleUnHandledCrashException(Exception ex, bool isRunningInForeground)
        {
            _dialogsHelper.HideDialog();

            if (isRunningInForeground)
            {
                var toastConfig = new ToastConfig(Strings.WeWereUnableToPerformTheOperationDueToASystemIssue)
                    .SetDuration(TimeSpan.FromSeconds(3))
                    .SetAction(new ToastAction()
                    {
                        Text = "Detalles",
                        Action = () => ShowErrorMessage(ex)
                    });

                _userDialogs.Toast(toastConfig);
            }

            _logger.LogException(ex, ex.InnerException ?? null);

            throw ex;
        }

        private void ShowErrorMessage(Exception ex)
        {
            _userDialogs.Alert(ex.MessageRecurse(), "Detalle error");
        }
    }
}