﻿using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.OS;
using Acr.UserDialogs;
using Plugin.CurrentActivity;
using PanCardView.Droid;
using Android.Content.Res;

namespace TradeFood.Droid
{
    [Activity(
        Label = "TradeFood",
        Icon = "@mipmap/icon",
        Theme = "@style/MainTheme",
        MainLauncher = true,
        ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize,
        ScreenOrientation = ScreenOrientation.Portrait)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            Rg.Plugins.Popup.Popup.Init(this);

            Xamarin.Essentials.Platform.Init(this, savedInstanceState);

            global::Xamarin.Forms.Forms.Init(this, savedInstanceState);

            CardsViewRenderer.Preserve();

            UserDialogs.Init(this);
            CrossCurrentActivity.Current.Init(this, savedInstanceState);
            FFImageLoading.Forms.Platform.CachedImageRenderer.Init(true);

            Plugin.InputKit.Platforms.Droid.Config.Init(this, savedInstanceState);

            LoadApplication(new App());
        }

        public override Android.Content.Res.Resources Resources
        {
            get
            {
                Android.Content.Res.Resources resource = base.Resources;

                Configuration configuration = new Configuration();

                configuration.SetToDefaults();

                if (Build.VERSION.SdkInt >= BuildVersionCodes.NMr1)
                    return CreateConfigurationContext(configuration).Resources;
                else
                {
                    resource.UpdateConfiguration(configuration, resource.DisplayMetrics);

                    return resource;
                }
            }
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}