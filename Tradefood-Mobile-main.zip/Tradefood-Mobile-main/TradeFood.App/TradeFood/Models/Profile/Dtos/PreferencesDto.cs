﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Profile.Dtos
{
    public class PreferencesDto
    {
        public bool IsBusinessTypeBrood { get; set; }
        public bool IsBusinessTypeChore { get; set; }
        public bool IsBusinessTypeWintering { get; set; }
        //Destino Faena
        public string DestinationChore { get; set; }
        //Categoria
        public string BroodCategory { get; set; }
        public string WinteringCategory { get; set; }
        public string ChoreCategory { get; set; }

        //SubCategoria
        public string ChoreSubCategory { get; set; }
        public string DestinationStatesChore { get; set; } //solo provincias

        public string DestinationStatesWintering { get; set; } //solo provincias

        public string DestinationStatesBrood { get; set; } //solo provincias
        public int? MinWeightBrood { get; set; }
        public int? MaxWeightBrood { get; set; }
        public int? MinWeightChore { get; set; }
        public int? MaxWeightChore { get; set; }
        public int? MinWeightWintering { get; set; }
        public int? MaxWeightWintering { get; set; }

        public bool TroopWeightType { get; set; }
        public bool UnevenTroopWeightType { get; set; }
        public List<PaymentTermDto> PaymentTerms { get; set; }
    }
}
