﻿using Xamarin.Forms;

namespace TradeFood.Effects
{
    public class RemoveSearchBarUnderlineEffect : RoutingEffect
    {
        public RemoveSearchBarUnderlineEffect()
            : base("TradeFood.RemoveSearchBarUnderlineEffect")
        {
        }
    }
}