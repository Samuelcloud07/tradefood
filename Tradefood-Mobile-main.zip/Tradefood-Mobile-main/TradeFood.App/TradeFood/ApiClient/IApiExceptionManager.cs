﻿using Refit;
using System.Threading.Tasks;

namespace TradeFood.ApiClient
{
    public interface IApiExceptionManager
    {
        Task HandleHttpStatusCodeAsync(ApiException ex);

        Task<T> HandleHttpStatusCodeAsync<T>(ApiException ex);
    }
}