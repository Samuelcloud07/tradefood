﻿using Acr.UserDialogs;
using System;
using System.Threading.Tasks;
using TradeFood.Resources;
using Xamarin.Essentials;

namespace TradeFood.Helpers
{
    public class DialogsHelper : IDialogsHelper
    {
        private readonly IUserDialogs _userDialogs;

        public DialogsHelper(IUserDialogs userDialogs)
        {
            _userDialogs = userDialogs;
        }

        public void ShowDialog()
        {
            MainThread.BeginInvokeOnMainThread(() => _userDialogs.ShowLoading("Cargando...", MaskType.Clear));
        }

        public void ShowDialog(string text)
        {
            MainThread.BeginInvokeOnMainThread(() => _userDialogs.ShowLoading(text, MaskType.Clear));
        }

        public void HideDialog()
        {
            MainThread.BeginInvokeOnMainThread(() => _userDialogs.HideLoading());
        }

        public IDisposable ShowAlert(string message, string title = null)
        {
            if (string.IsNullOrEmpty(title))
                title = Strings.ApplicationName;

            return _userDialogs.Alert(message, title, Strings.Accept);
        }

        public async Task ShowAlertAsync(string message, string title = null)
        {
            if (string.IsNullOrEmpty(title))
                title = Strings.ApplicationName;

            await MainThread.InvokeOnMainThreadAsync(async () =>
            {
                await _userDialogs.AlertAsync(message, title, Strings.Accept);
            });
        }

        public async Task<bool> ShowConfirmAsync(string message)
        {
            return await _userDialogs.ConfirmAsync(message, Strings.ApplicationName, Strings.Yes, Strings.No);
        }

        public async Task<bool> ShowConfirmAsync(string message,string title)
        {
            return await _userDialogs.ConfirmAsync(message, title, Strings.Yes, Strings.No);
        }
    }
}