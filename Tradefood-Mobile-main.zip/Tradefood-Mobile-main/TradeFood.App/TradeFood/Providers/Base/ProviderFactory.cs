﻿using System;
using System.Collections.Generic;
using TradeFood.Enums;
using Xamarin.Essentials;

namespace TradeFood.Providers
{
    public interface IProviderFactory
    {
        T Create<T>(bool localProvider = false);
    }

    public class ProviderFactory : IProviderFactory
    {
        private readonly Dictionary<KeyValuePair<Type, ConnectionType>, Type> _providersByConnectionType = new Dictionary<KeyValuePair<Type, ConnectionType>, Type>();

        public ProviderFactory()
        {
            AddProviderByConnectionType<IStatesProvider, IStatesApiProvider, IStatesLocalProvider>();
            AddProviderByConnectionType<ILiniersProvider, ILiniersApiProvider, ILiniersLocalProvider>();
            AddProviderByConnectionType<IDollarProvider, IDollarApiProvider, IDollarLocalProvider>();
            AddProviderByConnectionType<IGrainsProvider, IGrainsApiProvider, IGrainsLocalProvider>();
            AddProviderByConnectionType<IAuthenticationProvider, IAuthenticationApiProvider, IAuthenticationLocalProvider>();
            AddProviderByConnectionType<IWheaterProvider, IWheaterApiProvider, IWheaterLocalProvider>();
            AddProviderByConnectionType<IAgroNewsProvider, IAgroNewsApiProvider, IAgroNewsLocalProvider>();
            AddProviderByConnectionType<IDealsProvider, IDealsApiProvider, IDealsLocalProvider>();
            AddProviderByConnectionType<IProfileProvider,IProfileApiProvider,IProfileLocalProvider>();
        }

        private ConnectionType ConnectionMode => Connectivity.NetworkAccess == NetworkAccess.Internet
            ? ConnectionType.Connected
            : ConnectionType.Disconnected;

        public virtual T Create<T>(bool localProvider = false)
        {
            var key = new KeyValuePair<Type, ConnectionType>(typeof(T), localProvider
                                                                            ? ConnectionType.Disconnected
                                                                            : ConnectionMode);

            if (!_providersByConnectionType.TryGetValue(key, out Type providerType))
                throw new KeyNotFoundException($"El tipo {typeof(T).FullName} no está configurado en el ProviderFactory.");

            return (T)TypeLocator.Resolve(providerType);
        }

        private void AddProviderByConnectionType<TProvider, TApiProvider, TLocalProvider>()
        {
            _providersByConnectionType.Add(new KeyValuePair<Type, ConnectionType>(typeof(TProvider), ConnectionType.Connected), typeof(TApiProvider));
            _providersByConnectionType.Add(new KeyValuePair<Type, ConnectionType>(typeof(TProvider), ConnectionType.Disconnected), typeof(TLocalProvider));
        }
    }
}