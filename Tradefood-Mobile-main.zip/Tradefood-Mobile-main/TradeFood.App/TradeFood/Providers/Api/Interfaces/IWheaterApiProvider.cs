﻿namespace TradeFood.Providers
{
    public interface IWheaterApiProvider : IWheaterProvider
    {
    }
}