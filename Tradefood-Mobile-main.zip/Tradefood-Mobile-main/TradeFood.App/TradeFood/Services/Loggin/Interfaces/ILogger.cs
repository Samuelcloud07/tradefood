﻿using TradeFood.Enums;
using System;
using System.Collections.Generic;

namespace TradeFood.Services.Loggin
{
    public interface ILogger
    {
        void LogEvent(AppLogLevel level, string message);
        void LogEvent(AppLogLevel level, string message, Dictionary<string, string> dict);
        void LogException(Exception ex, object data = null, Dictionary<string, string> dict = null);
    }
}