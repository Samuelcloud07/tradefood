﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading.Tasks;
using TradeFood.Services.Loggin;
using TradeFood.Enums;
using TradeFood.Sandbox;
using System.Windows.Input;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public abstract class BaseViewModel : INotifyPropertyChanged
    {
        private ILogger _logger;

        public BaseViewModel(ILogger logger)
        {
            _logger = logger;

            // sends Event to AppCenter
            _logger.LogEvent(AppLogLevel.Info, $"{this.GetType().Name} Created");

            SandboxedNotifyTask.Create(() => InitializeAsync());

            OpenCloseDrawerCommand = new Command(OpenCloseDrawer);
        }

        protected NotifyTask LoadTask { get; set; }

        protected virtual Task InitializeAsync() => Task.CompletedTask;

        public virtual void OnAppearing()
        {
        }

        public virtual void OnDisappearing()
        {
        }

        // Commands
        public ICommand OpenCloseDrawerCommand { get; private set; }

        // Methods
        protected bool SetProperty<T>(ref T backingStore, T value, string propertyName = "", Action onChanged = null)
        {
            if (EqualityComparer<T>.Default.Equals(backingStore, value))
                return false;

            backingStore = value;
            onChanged?.Invoke();
            OnPropertyChanged(propertyName);

            return true;
        }

        private void OpenCloseDrawer()
        {
            Shell.Current.FlyoutIsPresented = !Shell.Current.FlyoutIsPresented;
        }

        // INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}