﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Common.Controllers
{
    public abstract class BaseController : ControllerBase
    {
        private readonly ILogger<BaseController> _logger;

        public BaseController(ILogger<BaseController> logger)
        {
            _logger = logger;
        }

        protected async Task<IActionResult> ExecuteAsync<T>(Func<Task<T>> task)
        {
            var response = await ControllerDispacher.DispatchResponse(task, _logger);

            // Determinar según el resultado del http code
            switch (response.HttpCode)
            {
                case HttpStatusCode.Unauthorized:
                    return Unauthorized();

                case HttpStatusCode.Forbidden:
                    return StatusCode((int)HttpStatusCode.Forbidden, response);

                case HttpStatusCode.InternalServerError:
                    return StatusCode((int)HttpStatusCode.InternalServerError, response);

                case HttpStatusCode.BadRequest:
                    return BadRequest(response);

                case HttpStatusCode.NotFound:
                    return NotFound(response);

                default:
                    return Ok(response);
            }
        }

        protected async Task<IActionResult> ExecuteAsync(Func<Task> task)
        {
            return await ExecuteAsync(async () =>
            {
                await task.Invoke();

                return true;
            });
        }
    }
}