﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeFood.ViewModels.Items;

namespace TradeFood.Models.Profile.Dtos
{
    public class TroopDetailPreferencesDto
    {

        // Invernada
        public bool IsEqualTroop { get; set; }

        public bool IsNotEqualTroop { get; set; }

        public string WinteringCategoriesSelected { get; set; }

        public string MinWeightWinteringSelected { get; set; }

        public string MaxWeightWinteringSelected { get; set; }


        //Faena
        public string ChoreCategoriesSelected { get; set; }

        public string SubCategoriesSelected { get; set; }

        public string GeographicDestinationSelected { get; set; }

        public string MinWeightChoreSelected { get; set; }

        public string MaxWeightChoreSelected { get; set; }
    }
}
