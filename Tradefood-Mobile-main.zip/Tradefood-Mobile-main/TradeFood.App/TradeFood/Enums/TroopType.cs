﻿namespace TradeFood.Enums
{
    public enum TroopType
    {
        Terneros,
        Terneras,
        Terneros_as,
        Vacas,
        Novillitos,
        Vaquillonas,
        Vaquillonas_Preñadas,
        Vacas_Preñadas,
        Vaquillonas_para_entorar,
        Vacas_para_entorar,
        Novillo,
        Novillito,
        Vaquillona,
        Toro
    }
}