﻿using System;

namespace Common.Exceptions
{
    public class InternalException : Exception
    {
        public InternalException(string errorMessage)
            : base($"Internal Exception : {errorMessage}")
        {
        }
    }
}