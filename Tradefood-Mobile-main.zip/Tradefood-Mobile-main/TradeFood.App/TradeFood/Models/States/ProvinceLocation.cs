﻿using Newtonsoft.Json;
using System.ComponentModel;

namespace TradeFood.Models
{
    public class ProvinceLocation
    {
        [JsonProperty("nombre")]
        public string Name { get; set; }

    }
}