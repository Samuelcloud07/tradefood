using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Settings;
using TradeFood.Services.Loggin;
using Xamarin.Forms;
using System;
using System.Linq;
using TradeFood.Helpers;
using Rg.Plugins.Popup.Services;
using TradeFood.Views.Popups;

namespace TradeFood.ViewModels
{
    public class AddAdressViewModel : BaseViewModel
    {
        private readonly IStatesService _statesServices;
        private readonly IAppSettings _appSettings;
        private readonly IProfileService _profileService;
        private readonly IDialogsHelper _dialogsHelper;

        long UserId = 0;
        private List<ProvinceLocation> _locations = new List<ProvinceLocation>();

        public AddAdressViewModel(ILogger logger,
                                  IStatesService statesService,
                                  IDialogsHelper dialogsHelper,
                                  IAppSettings appSettings,
                                  IProfileService profileService)
            : base(logger)
        {
            _statesServices = statesService;
            _dialogsHelper = dialogsHelper;
            _appSettings = appSettings;
            _profileService = profileService;

            SelectProvinceCommand = new SandboxedCommand(SelectProvince);
            PickLocationCommand = new SandboxedCommand(PickLocation);
            AddAddressCommand = new SandboxedCommand(AddAddress);
        }

        //Properties
        public List<ProvinceLocation> Provinces { get; private set; } = new List<ProvinceLocation>();

        public List<ProvinceLocation> Locations { get; private set; } = new List<ProvinceLocation>();

        public ProvinceLocation ProvinceSelected { get; set; }

        public ProvinceLocation LocationSelected { get; set; }

        public string Street { get; set; }

        public int? Number { get; set; }

        public bool WithoutNumber { get; set; }

        public string ZipCode { get; set; }

        public string FloorDepartment { get; set; }

        public long IdSocietiesPerson { get; set; }

        public string Observations { get; set; }

        public string ClientType { get; set; }

        public string AddAdressTitle
        {
            get
            {
                if (ClientType == "Frigorífico")
                    return "Agregá el domicilio del Frigorífico";
                else if (ClientType == "Productor_Persona" || ClientType == "Comisionista")
                    return "Agregá el domicilio de la hacienda";
                else
                    return "Agregá el domicilio de la razón social";
            }
        }

        public bool HasErrors { get; set; }

        public string LocationTitle { get; set; }

        public int DefaultProvinceSelected { get; set; } = 0;

        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();

        //Commands
        public SandboxedCommand SelectProvinceCommand { get; private set; }

        public SandboxedCommand PickLocationCommand { get; private set; }
        
        public SandboxedCommand AddAddressCommand { get; private set; }

        //Methods
        protected override async Task InitializeAsync()
        {
            _dialogsHelper.ShowDialog();

            await base.InitializeAsync();

            Provinces = await _statesServices.GetProvincesAsync();

            ClientType = _appSettings.ClientType;

            UserId = (long)Convert.ToDouble(_appSettings.UserId);

            _dialogsHelper.HideDialog();
        }

        private bool ValidateAll()
        {
            Errors.Clear();

            // Colocar validaciones

            if (ProvinceSelected == null)
                Errors.Add(nameof(ProvinceSelected), Strings.YouMustEnterAProvince);
            
            if (LocationSelected == null)
                Errors.Add(nameof(LocationSelected), Strings.YouMustEnterALocation);

            if (string.IsNullOrEmpty(Street))
                Errors.Add(nameof(Street), Strings.YouMustEnterAStreet);

            if (Number == null)
                Errors.Add(nameof(Number), Strings.YouMustEnterANumber);

            if (string.IsNullOrEmpty(ZipCode))
                Errors.Add(nameof(ZipCode), Strings.YouMustEnterAZipCode);

            //---------------------------------------

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }

        public async Task SelectProvince()
        {
            //Locations = await _statesServices.GetLocationsForProvinceAsync(ProvinceSelected.Name);
            _dialogsHelper.ShowDialog();

            _locations.Clear();

            var locations = await _statesServices.GetLocationsForProvinceAsync(ProvinceSelected.Name);

            _locations.AddRange(locations);

            //LocationVisible = true;

            LocationTitle = Strings.SearchLocation;

            _dialogsHelper.HideDialog();
        }

        private async Task PickLocation() => await PopupNavigation.Instance.PushAsync(new LocationPopupPage(_locations));

        private async void CreateAddressProfile() 
        {
            var newAddress = new AddressDto
            {
                State = ProvinceSelected.Name,
                Location = LocationSelected.Name,
                Street = Street,
                Number = (int)Number,
                WithoutNumber = WithoutNumber,
                ZipCode = ZipCode,
                FloorDepartment = FloorDepartment,
                Observations = Observations
            };

            if (await _dialogsHelper.ShowConfirmAsync("¿Deseas agregar esta nueva direccion a tu perfil?", "Agregar nueva direccion")) 
            {
                await _profileService.AddAddressAsync(newAddress, UserId);
                MessagingCenter.Send<AddAdressViewModel>(this, "DireccionAgregada");
                await Shell.Current.GoToAsync("..");
            }
        }

        private async void CreateAddressSocieties()
        {
            var newAddress = new AddressDto
            {
                State = ProvinceSelected.Name,
                Location = LocationSelected.Name,
                Street = Street,
                Number = (int)Number,
                WithoutNumber = WithoutNumber,
                ZipCode = ZipCode,
                FloorDepartment = FloorDepartment,
                Observations = Observations
            };

            if (await _dialogsHelper.ShowConfirmAsync("¿Deseas agregar esta nueva direccion a tu sociedad?", "Agregar nueva direccion"))
            {
                await _profileService.AddAddressSocietiesAsync(UserId, IdSocietiesPerson, newAddress);
                MessagingCenter.Send<AddAdressViewModel>(this, "DireccionAgregada");
                await Shell.Current.GoToAsync("..");
            }
        }


        public Task AddAddress()
        {
            if (!ValidateAll())
                return Task.CompletedTask;

            switch (ClientType)
            {
                case "Productor_Persona":
                    if (IdSocietiesPerson == 0)
                        CreateAddressProfile();
                    else
                        CreateAddressSocieties();
                    break;

                case "Productor_Empresa":                    
                    if (IdSocietiesPerson == 0)
                        CreateAddressProfile();
                    else
                        CreateAddressSocieties();                    
                    break;

                case "Comisionista":                    
                    if (IdSocietiesPerson == 0)
                        CreateAddressProfile();
                    else
                        CreateAddressSocieties();                    
                    break;

                case "Consignataria":                    
                    if (IdSocietiesPerson == 0)
                        CreateAddressProfile();
                    else
                        CreateAddressSocieties();                    
                    break;

                case "Frigorífico":                    
                    if (IdSocietiesPerson == 0)
                        CreateAddressProfile();
                    else
                        CreateAddressSocieties();                    
                    break;
            }

            return Task.CompletedTask;
        }
    }
}