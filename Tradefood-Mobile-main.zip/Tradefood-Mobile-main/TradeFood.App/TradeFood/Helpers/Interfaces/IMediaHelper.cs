﻿using Plugin.Media.Abstractions;
using System;
using System.Threading.Tasks;
using TradeFood.Enums;

namespace TradeFood.Helpers
{
    public interface IMediaHelper
    {
        Task<MediaFile> LoadImageFromSourceAsync(ImageSource source, string fileName, CameraDevice defaultCamera, PhotoSize photoSize = PhotoSize.Full, int compressionQuality = 100);

        Task<MediaFile> RecordVideoAsync(string fileName, TimeSpan desiredLenght, VideoQuality quality = VideoQuality.High, int compressionQuality = 100);
    }
}