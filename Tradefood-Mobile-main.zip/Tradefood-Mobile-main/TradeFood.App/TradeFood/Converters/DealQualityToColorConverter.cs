﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class DealQualityToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var quality = (int?)value;

            if (quality < 4)
                return Color.FromHex("#A10b07");
            else
                return quality < 7 ? Color.FromHex("#97691E") : Color.FromHex("#00724D");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}