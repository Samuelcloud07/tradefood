﻿using System.Collections.Generic;
using TradeFood.Models;

namespace TradeFood.ViewModels
{
    public class LocationsGroup : List<ProvinceLocation>
    {
        public string Name { get; private set; }

        public LocationsGroup(string name, List<ProvinceLocation> locations) : base(locations)
        {
            Name = name;
        }
    }
}
