﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using TradeFood.Models;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class GetFirstItemFromFileListConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var list = (List<File>)value;

            return list.FirstOrDefault().FilePath;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}