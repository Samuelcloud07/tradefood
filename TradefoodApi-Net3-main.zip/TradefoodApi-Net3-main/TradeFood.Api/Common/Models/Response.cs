﻿using System.Net;

namespace Common.Models
{
    public class Response
    {
        public string ErrorMessage { get; set; }

        public string Result { get; set; }

        public string Log { get; set; }

        public HttpStatusCode HttpCode { get; set; }
    }

    public class Response<T> : Response
    {
        public T Data { get; set; }
    }
}