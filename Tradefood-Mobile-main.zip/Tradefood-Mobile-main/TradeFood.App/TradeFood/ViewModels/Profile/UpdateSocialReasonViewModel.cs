﻿using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Extensions;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.ViewModels.Profile
{
    internal class UpdateSocialReasonViewModel : BaseViewModel
    {
        private IProfileService _profileService;
        private IAppSettings _appSettings;
        private readonly IStatesService _statesService;
        private readonly IDialogsHelper _dialogsHelper;

        public UpdateSocialReasonViewModel(ILogger logger,
                                           IProfileService profileService,
                                           IAppSettings appSettings,
                                           IStatesService statesService,
                                           IDialogsHelper dialogsHelper)
            :base(logger)
        {
            _profileService = profileService;
            _appSettings = appSettings;
            _statesService = statesService;
            _dialogsHelper = dialogsHelper;

            UpdateSocialReasonCommand = new SandboxedCommand(UpdateSocialReason);
            SelectProvinceCommand = new SandboxedCommand(SelectProvince);
            SelectLocationCommand = new SandboxedCommand(SelectLocation);
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            _dialogsHelper.ShowDialog();

            UserId = (long)Convert.ToDouble(_appSettings.UserId);

            SocialReasons = await _profileService.GetSocietiesAndPersonsAsync(UserId);

            await InitializaedProperties();

            _dialogsHelper.HideDialog();
        }

        private async Task InitializaedProperties()
        {
            SocialReason = SocialReasons.Find(s => s.id == Id);

            LabelMainText = LabelText(SocialReason.Type.ToString());

            Email = SocialReason.Email;

            ContactNumber = SocialReason.ContactNumber;

            Street = SocialReason.Addresses[0].Street;

            Number = SocialReason.Addresses[0].Number == 0 ? "" : SocialReason.Addresses[0].Number.ToString();

            WithoutNumber = SocialReason.Addresses[0].WithoutNumber;

            FloorDepartment = SocialReason.Addresses[0].FloorDepartment;

            ZipCode = SocialReason.Addresses[0].ZipCode;

            Observations = SocialReason.Addresses[0].Observations;

            HideFields = HideFieldTypeSocieties();

            var provinces = await _statesService.GetProvincesAsync();

            Provinces.AddRange(provinces);

            ProvinceSelected = provinces.Find(p => p.Name == SocialReason.Addresses[0].State);

            var locations = await _statesService.GetLocationsForProvinceAsync(SocialReason.Addresses[0].State);

            Locations.AddRange(locations);

            LocationSelected = locations.Find(l => l.Name == SocialReason.Addresses[0].Location);

            LocationTitle = SocialReason.Addresses[0].Location;

            this.OnPropertyChanged(nameof(Provinces));
        }

        //Properties
        public long Id { get; set; }
        public long UserId { get; set; }
        public bool HideFields { get; set; } = false;
        public string LabelMainText { get; set; }
        public List<SocietiesAndPersonDto> SocialReasons { get; set; }
        public SocietiesAndPersonDto SocialReason { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public ObservableCollection<ProvinceLocation> Provinces { get; private set; } = new ObservableCollection<ProvinceLocation>();
        public ObservableCollection<ProvinceLocation> Locations { get; private set; } = new ObservableCollection<ProvinceLocation>();
        public ProvinceLocation ProvinceSelected { get; set; }
        public ProvinceLocation LocationSelected { get; set; }
        public string Street { get; set; }
        public string Number { get; set; }
        public bool WithoutNumber { get; set; }
        public string FloorDepartment { get; set; }
        public string ZipCode { get; set; }
        public string Observations { get; set; }
        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();
        public bool HasErrors { get; set; }
        public string LocationTitle { get; set; }

        public int DefaultProvinceSelected { get; set; } = 0;

        //Commands

        public SandboxedCommand SelectProvinceCommand { get; private set; }
        public SandboxedCommand SelectLocationCommand { get; private set; }
        public SandboxedCommand UpdateSocialReasonCommand { get; private set; }

        //Methods
        public async Task SelectProvince()
        {
            _dialogsHelper.ShowDialog();

            Locations.Clear();
            LocationSelected = null;

            var locations = await _statesService.GetLocationsForProvinceAsync(ProvinceSelected.Name);

            Locations.AddRange(locations);

            if (!ProvinceSelected.Name.Equals(SocialReason.Addresses[0].State))
                LocationTitle = "Buscar localidad";

            _dialogsHelper.HideDialog();
        }

        public async Task UpdateSocialReason()
        {
            if (!ValidateAll())
                return;

            int? intNumber = null;

            if(!WithoutNumber && !string.IsNullOrEmpty(Number))
                intNumber = int.Parse(Number);

            var UpdatedSocialReason = new SocietiesAndPersonDto
            {
                id = SocialReason.id,
                IsActive = SocialReason.IsActive,
                Type = SocialReason.Type,
                Name = SocialReason.Name,
                Cuit = SocialReason.Cuit,
                CommercialReference = SocialReason.CommercialReference,
                Email = Email,
                ContactNumber = ContactNumber,
                Addresses = new List<AddressDto>()
            };
            

            var UpdatedAddresses = new AddressDto
            {
                Id = SocialReason.Addresses[0].Id,
                State = !string.IsNullOrEmpty(ProvinceSelected.Name) ? ProvinceSelected.Name : SocialReason.Addresses[0].State,
                Location = !string.IsNullOrEmpty(LocationSelected.Name) ? LocationSelected.Name : SocialReason.Addresses[0].Location,
                Street = Street,
                Number = intNumber == null ? 0 : intNumber,
                WithoutNumber = WithoutNumber,
                FloorDepartment = FloorDepartment,
                ZipCode = ZipCode,
                Observations = Observations
            };

            UpdatedSocialReason.Addresses.Add(UpdatedAddresses);

            await _profileService.UpdateSocietiesAsync(UserId, UpdatedSocialReason);
            MessagingCenter.Send<UpdateSocialReasonViewModel>(this, "SociedadEditada");
            await Shell.Current.GoToAsync("..");
        }

        public bool HideFieldTypeSocieties() 
        {
            return SocialReason.Type == Enums.TypeSocieties.RazonSocial;
        }

        public string LabelText(string type) 
        {
            switch (type)
            {
                case "PersonaFisica":
                    return $"Edita la informacíon cargada sobre la persona física \"{SocialReason.Name}\"";
                case "RazonSocial":
                    return $"Edita la informacíon cargada sobre la rázon social \"{SocialReason.Name}\"";
                case "RazonMatarife":
                    return $"Edita la informacíon cargada sobre la rázon social Matarife \"{SocialReason.Name}\"";
                default: return "";
            }
        }

        public SocietiesAndPersonDto GetSelectedSocialReason()
        {
            var result = SocialReasons.Find(s => s.id == Id);
            return result;
        }

        private bool ValidateAll()
        {
            Errors.Clear();

            if(SocialReason.Type != Enums.TypeSocieties.PersonaFisica && SocialReason.Type != Enums.TypeSocieties.RazonMatarife)
            {
                if (!Email.IsValidEmail())
                    Errors.Add(nameof(Email), Strings.TheEmailAddressIsInvalid);

                if (!ContactNumber.IsValidPhoneNumber())
                    Errors.Add(nameof(ContactNumber), Strings.ThePhoneNumberIsInvalid);
            }

            EmptyStringValidator(Street, nameof(Street));

            if (LocationSelected == null)
            {
                Errors.Add(nameof(ProvinceSelected), Strings.YouMustEnterALocation);
            }

            if (!WithoutNumber)
                EmptyStringValidator(Number, nameof(Number));

            EmptyStringValidator(ZipCode, nameof(ZipCode));

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();
            
            return !Errors.Any();
        }

        private void EmptyStringValidator(string toValidate, string resourceString)
        {
            if(string.IsNullOrEmpty(toValidate))
                Errors.Add(resourceString, string.Format(Strings.TheFieldXIsRequired, Strings.ResourceManager.GetString(resourceString)));
        }

        private async Task SelectLocation()
        {
            await PopupNavigation.Instance.PushAsync(new LocationPopupPage(Locations.ToList()));
        }
    }
}
