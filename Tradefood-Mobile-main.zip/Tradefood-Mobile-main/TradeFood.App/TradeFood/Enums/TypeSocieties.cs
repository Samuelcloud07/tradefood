﻿namespace TradeFood.Enums
{
    public enum TypeSocieties
    {
        PersonaFisica,
        RazonSocial,
        RazonMatarife,
        Mi_Perfil
    }
}
