﻿using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public interface IGrainsProvider
    {
        Task<GrainData> GetGrainsQuotationAsync();
    }
}