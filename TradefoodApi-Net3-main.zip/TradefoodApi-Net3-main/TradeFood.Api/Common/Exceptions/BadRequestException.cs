﻿using System;

namespace Common.Exceptions
{
    public class BadRequestException : Exception
    {
    }
}