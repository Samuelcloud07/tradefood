﻿using Microcharts;
using SkiaSharp;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Repositories;
using TradeFood.Sandbox;

namespace TradeFood.ViewModels
{
    public class LiniersItemViewModel : INotifyPropertyChanged
    {
        public LiniersItemViewModel(LiniersData liniersData)
                                    
        {
            LinierQuote = liniersData;

            LoadTask = SandboxedNotifyTask.Create(() => GenerateLiniersDataCharts());
        }

        public NotifyTask LoadTask { get; set; }

        public LiniersData LinierQuote { get; private set; }

        public ObservableCollection<ChartEntry> LiniersDataCharts { get; private set; } = new ObservableCollection<ChartEntry>();

        // Methods
        private async Task GenerateLiniersDataCharts()
        {
            var liniersRepository = TypeLocator.Resolve<ILiniersRepository>();

            var liniersQuotes = await liniersRepository.GetLiniersQuotesByCategoryAsync(LinierQuote.Category);

            liniersQuotes = liniersQuotes.OrderBy(lq => lq.Date).ToList();

            foreach (var liniersQuote in liniersQuotes)
            {
                LiniersDataCharts.Add(new ChartEntry(float.Parse(liniersQuote.Max))
                {
                    Label = liniersQuote.Date.ToString("dd/MM"),
                    ValueLabel = liniersQuote.Max,
                    ValueLabelColor = SKColor.Parse("#717276"),
                    Color = SKColor.Parse("#7B1E21")
                });
            }
        }

        // INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}