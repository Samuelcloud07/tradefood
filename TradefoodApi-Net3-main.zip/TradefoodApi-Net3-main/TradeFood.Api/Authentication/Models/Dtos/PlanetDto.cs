﻿using Newtonsoft.Json;

namespace Authentication.Models.Dtos
{
    public class PlanetDto
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("rotation_period")]
        public long RotationPeriod { get; set; }

        [JsonProperty("orbital_period")]
        public long OrbitalPeriod { get; set; }

        [JsonProperty("diameter")]
        public long Diameter { get; set; }

        [JsonProperty("climate")]
        public string Climate { get; set; }

        [JsonProperty("terrain")]
        public string Terrain { get; set; }

        [JsonProperty("surface_water")]
        public string SurfaceWater { get; set; }

        [JsonProperty("population")]
        public string Population { get; set; }
    }
}