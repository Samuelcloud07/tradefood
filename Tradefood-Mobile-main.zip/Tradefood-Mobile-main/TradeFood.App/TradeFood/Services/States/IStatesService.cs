﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Services
{
    public interface IStatesService
    {
        Task<List<ProvinceLocation>> GetProvincesAsync();

        Task<List<ProvinceLocation>> GetLocationsForProvinceAsync(string provincia);
    }
}