﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.ApiClient.ApisInterfaces;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class StatesApiProvider : TradeFoodBaseApiProvider, IStatesApiProvider
    {
        public StatesApiProvider(IAppHttpClient httpClientSingleton,
                                 IApiExceptionManager apiExceptionManager)
            : base(httpClientSingleton, apiExceptionManager)
        {
        }

        public async Task<List<ProvinceLocation>> GetProvincesAsync()
        {
            var provinces = await this.ExecuteRequest<TradeFoodApiResponse<List<ProvinceLocation>>>(
                () => this.GetRestServiceFor<IStatesApi>().GetProvincesAsync()).ConfigureAwait(false);

            return provinces.Data;
        }

        public async Task<List<ProvinceLocation>> GetLocationsForProvinceAsync(string provincia)
        {
            var locations = await this.ExecuteRequest<TradeFoodApiResponse<List<ProvinceLocation>>>(
                () => this.GetRestServiceFor<IStatesApi>().GetLocationsForProvinceAsync(provincia)).ConfigureAwait(false);

            return locations.Data;
        }
    }
}