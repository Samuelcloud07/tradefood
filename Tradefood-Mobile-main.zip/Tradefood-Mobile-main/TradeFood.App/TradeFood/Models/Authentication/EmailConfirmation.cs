﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class EmailConfirmation
    {
        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("emailConfirmationToken")]
        public string EmailConfirmationToken { get; set; }
    }
}