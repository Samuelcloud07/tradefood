﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace TradeFood.Handlers
{
    public interface IVideoTranscoderHandler
    {
        Task<string> TranscodeVideoAsync(string sourceVideoPath);

        Task<string> GenerateThumbnail(string sourceVideoPath);
    }
}