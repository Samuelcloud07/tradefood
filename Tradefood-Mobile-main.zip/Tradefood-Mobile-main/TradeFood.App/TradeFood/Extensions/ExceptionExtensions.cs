﻿using System;
using System.Text;

namespace TradeFood.Extensions
{
    public static class ExceptionExtensions
    {
        public static string MessageRecurse(this Exception ex) => ex.MessageRecurse(new StringBuilder()).ToString();

        private static StringBuilder MessageRecurse(this Exception ex, StringBuilder stringBuilder)
        {
            stringBuilder.AppendLine($"{ex.Message}");

            if (ex.InnerException != null)
                return ex.InnerException.MessageRecurse(stringBuilder);

            return stringBuilder;
        }
    }
}