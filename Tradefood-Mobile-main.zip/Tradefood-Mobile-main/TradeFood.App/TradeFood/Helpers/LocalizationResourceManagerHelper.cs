﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Threading;
using TradeFood.Extensions;
using TradeFood.Resources;
using Xamarin.Essentials;

namespace TradeFood.Helpers
{
    public class LocalizationResourceManagerHelper : INotifyPropertyChanged
    {
        private const string LanguageKey = nameof(LanguageKey);

        static readonly Lazy<LocalizationResourceManagerHelper> currentHolder = new Lazy<LocalizationResourceManagerHelper>(() => new LocalizationResourceManagerHelper());

        public static LocalizationResourceManagerHelper Instance => currentHolder.Value;

        private LocalizationResourceManagerHelper()
        {
            SetCulture(new CultureInfo(Preferences.Get(LanguageKey, CurrentCulture.TwoLetterISOLanguageName)));
        }

        public string this[string text]
        {
            get => Strings.ResourceManager.GetString(text, Strings.Culture);
        }

        public void SetCulture(CultureInfo language)
        {
            Thread.CurrentThread.CurrentUICulture = language;
            Strings.Culture = language;
            Preferences.Set(LanguageKey, language.TwoLetterISOLanguageName);

            Invalidate();
        }

        public string GetValue(string text, string ResourceId)
        {
            ResourceManager resourceManager = new ResourceManager(ResourceId, typeof(TranslateExtension).GetTypeInfo().Assembly);

            return resourceManager.GetString(text, CurrentCulture);
        }

        public CultureInfo CurrentCulture => Strings.Culture ?? Thread.CurrentThread.CurrentUICulture;

        public event PropertyChangedEventHandler PropertyChanged;

        public void Invalidate()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
        }
    }
}