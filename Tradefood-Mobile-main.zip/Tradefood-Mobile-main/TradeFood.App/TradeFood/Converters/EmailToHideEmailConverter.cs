﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    class EmailToHideEmailConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string valor= value.ToString();
            string patron= @"(?<=[\w]{1})[\w-\._\+%]*(?=[\w]{1}@)";
            string resultado= Regex.Replace(valor, patron, m => new string('*', m.Length));
            return resultado;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string valor = value.ToString();
            string patron = @"(?<=[\w]{1})[\w-\._\+%]*(?=[\w]{1}@)";
            string resultado = Regex.Replace(valor, patron, m => new string('*', m.Length));
            return resultado;
        }
    }
}
