﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market.Dtos
{
    public class DealDto
    {
        public string DealId { get; set; }
        public int DealStatus { get; set; } // enum
        public string CreatedBy { get; set; }
        public string TroopType { get; set; }  // business type
        public string TroopCategory { get; set; }
        public string BreedType { get; set; }
        public string Amount { get; set; }
        public int MaleAmount { get; set; }
        public int FemaleAmount { get; set; }
        public int Quality { get; set; }
        public string WeightAmount { get; set; }
        public string Comments { get; set; }
        public string SuggestedPrice { get; set; }
        public string PaymentMethod { get; set; }
        public string FinancingCategory { get; set; }
        public string Province { get; set; }
        public string Location { get; set; }
        public string PersonInCharge { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int Roughing { get; set; }
        public Address TroopLocation { get; set; }
        public SocietiesAndPerson SocietiesAndPerson { get; set; }



        // Chore
        public string SaleType { get; set; }
        public string Yield { get; set; }
        public string Destination { get; set; }
        public string FitChina { get;set; }
        public string CommentsPopurri { get; set; }
        public string TroopSubCategory { get; set; }
        public NutritionalTreatment NutritionalTreatment { get; set; }


        //Wintering
        public int Teeth { get; set; }
        public string TroopWeightType { get; set; }
        public int MinimumTip { get; set; }
        public int MaximumTip { get; set; }
        public int AverageWeightAmount { get; set; }
        public TroopStatus Status { get; set; }
        public bool IsDirtyArea { get; set; }
        public bool IsMioMio { get; set; }
        public bool IsTick { get; set; }

    }
}
