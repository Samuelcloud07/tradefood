﻿using Refit;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.ApiClient.ApisInterfaces
{
    public interface IGrainsApi
    {
        [Get("/cerealesfunction/grains/granos")]
        Task<TradeFoodApiResponse<GrainData>> GetGrainsQuotationAsync();
    }
}