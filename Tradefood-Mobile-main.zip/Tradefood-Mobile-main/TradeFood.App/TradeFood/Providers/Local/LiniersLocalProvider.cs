﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Exceptions;
using TradeFood.Models;
using TradeFood.Repositories;

namespace TradeFood.Providers
{
    public class LiniersLocalProvider : ILiniersLocalProvider
    {
        private readonly ILiniersRepository _liniersRepository;

        public LiniersLocalProvider(ILiniersRepository liniersRepository)
        {
            _liniersRepository = liniersRepository;
        }

        public Task<List<LiniersData>> GetCotizacionesLiniersAsync()
        {
            throw new NoInternetException();
        }

        public Task<List<LiniersData>> PersistLiniersDataAsync(IEnumerable<LiniersData> liniersData)
        {
            foreach (var data in liniersData)
                data.Date = DateTime.Today;

            if (DateTime.Now.DayOfWeek != DayOfWeek.Saturday || DateTime.Now.DayOfWeek != DayOfWeek.Sunday)
                return _liniersRepository.PersistLiniersDataAsync(liniersData);
            else
            {
                var tcs = new TaskCompletionSource<List<LiniersData>>();

                tcs.SetResult(new List<LiniersData>(liniersData));

                return tcs.Task;
            }
        }
    }
}