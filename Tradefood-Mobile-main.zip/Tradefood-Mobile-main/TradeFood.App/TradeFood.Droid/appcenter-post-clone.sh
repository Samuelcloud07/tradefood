#!/usr/bin/env bash

SLN_PATH="$APPCENTER_SOURCE_DIRECTORY/TradeFood.App/TradeFood.sln"
UWP_PATH="$APPCENTER_SOURCE_DIRECTORY/TradeFood.App/TradeFood.UWP/TradeFood.UWP.csproj"

dotnet sln $SLN_PATH remove $UWP_PATH