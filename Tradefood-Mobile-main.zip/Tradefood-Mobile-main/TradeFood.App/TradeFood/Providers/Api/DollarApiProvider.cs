﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.ApiClient.ApisInterfaces;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class DollarApiProvider : TradeFoodBaseApiProvider, IDollarApiProvider
    {
        public DollarApiProvider(IAppHttpClient httpClientSingleton,
                                 IApiExceptionManager apiExceptionManager)
            : base(httpClientSingleton, apiExceptionManager)
        {                
        }

        public async Task<List<DollarData>> GetDollarQuotesAsync()
        {
            var dollarQuotes = await this.ExecuteRequest<TradeFoodApiResponse<List<DollarData>>>(
                () => this.GetRestServiceFor<IDollarApi>().GetDollarQuotesAsync()).ConfigureAwait(false);

            return dollarQuotes.Data;
        }
    }
}