﻿using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views.Popups;
using Xamarin.Essentials;

namespace TradeFood.ViewModels
{
    public class AdministratorHomeViewModel : BaseViewModel
    {
        private readonly ILiniersService _liniersService;
        private readonly IDealsService _dealsService;
        private readonly IDollarService _dollarService;
        private readonly IGrainsService _grainsService;
        private readonly IProfileService _profileService;
        private readonly IWheaterService _wheaterService;
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        private List<LiniersData> _liniersQuotes = new List<LiniersData>();
        private List<LiniersItemViewModel> _linierItems = new List<LiniersItemViewModel>();
        private List<DollarData> _dollarQuotes = new List<DollarData>();
        private List<GrainsItemViewModel> _grains = new List<GrainsItemViewModel>();

        private WheaterData _wheaterData;

        public AdministratorHomeViewModel(ILogger logger,
                                          ILiniersService liniersService,
                                          IDealsService dealsService,
                                          IDollarService dollarService,
                                          IGrainsService grainsService,
                                          IProfileService profileService,
                                          IWheaterService wheaterService,
                                          IAppSettings appSettings,
                                          IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _liniersService = liniersService;
            _dealsService = dealsService;
            _dollarService = dollarService;
            _grainsService = grainsService;
            _profileService = profileService;
            _wheaterService = wheaterService;
            _appSettings = appSettings;
            _dialogsHelper = dialogsHelper;

            OpenLiniersQuotesCommand = new SandboxedCommand(OpenLiniersQuotes);

            OpenDollarQuotesCommand = new SandboxedCommand(OpenDollarQuotes);

            OpenGrainQuotesCommand = new SandboxedCommand(OpenGrainQuotes);

            ShowWheaterCommand = new SandboxedCommand(ShowWheater);

            ShowWHidePreDealsSectionCommand = new SandboxedCommand(ShowWHidePreDealsSection);

            ShowHideDealsSectionCommand = new SandboxedCommand(ShowHideDealsSection);

            ShowHideUsersSectionCommand = new SandboxedCommand(ShowHideUsersSection);
        }

        protected override async Task InitializeAsync()
        {
            MainThread.BeginInvokeOnMainThread(() => _dialogsHelper.ShowDialog());
            
            UserName = _appSettings.UserName;

            Welcome = $"¡Hola {UserName}!";

            this.OnPropertyChanged(nameof(Welcome));

            await base.InitializeAsync();

            var tasks = new Task[]
            {
                GetLinierQuotes(),
                GetDollarQuotes(),
                GetGrainQuotes(),
                GetWeatherForecast(),
                GetDealsStats(),
                GetProfileStats()
            };

            await Task.WhenAll(tasks);

            _dialogsHelper.HideDialog();
        }

        // Properties
        public DealsStats DealsStats { get; private set; }

        public ProfileStats ProfileStats { get; private set; }

        public string UserName { get; private set; }

        public string Welcome { get; private set; }

        public double ActivesPercentage { get; private set; }
        
        public double PausedPercentage { get; private set; }

        public double DeletedPercentage { get; private set; }

        public double ProducersPercentage { get; private set; }

        public double CommissionAgentsPercentage { get; private set; }

        public double ConsigneesPercentage { get; private set; }

        public double MeatIndustriesPercentage { get; private set; }

        public float MaxActives { get; private set; }

        public float MaxPaused { get; private set; }

        public float MaxDeleted { get; private set; }

        public bool PreDealsSectionVisibility { get; set; }

        public bool DealsSectionVisibility { get; set; }

        public bool UsersSectionVisibility { get; set; }

        // Commands
        public SandboxedCommand OpenLiniersQuotesCommand { get; private set; }

        public SandboxedCommand OpenDollarQuotesCommand { get; private set; }

        public SandboxedCommand OpenGrainQuotesCommand { get; private set; }

        public SandboxedCommand ShowWheaterCommand { get; private set; }

        public SandboxedCommand ShowWHidePreDealsSectionCommand { get; private set; }
        
        public SandboxedCommand ShowHideDealsSectionCommand { get; private set; }
        
        public SandboxedCommand ShowHideUsersSectionCommand { get; private set; }

        // Methods
        private async Task GetLinierQuotes()
        {
            _liniersQuotes = await _liniersService.GetCotizacionesLiniersAsync();

            foreach (var item in _liniersQuotes)
                _linierItems.Add(new LiniersItemViewModel(item));
        }

        private async Task GetDollarQuotes()
        {
            _dollarQuotes = await _dollarService.GetDollarQuotesAsync();
        }

        private async Task GetGrainQuotes()
        {
            var grainData = await _grainsService.GetGrainsQuotationAsync();

            foreach (var grain in grainData.Cereales)
                _grains.Add(new GrainsItemViewModel(grain));
        }

        private async Task GetWeatherForecast()
        {
            await CheckLocationPermission();

            var latLon = await GetLatitudeLongitude();

            _wheaterData = await _wheaterService.GetWheaterAsync(latLon.Item1, latLon.Item2);

            _appSettings.CurrentTemp = _wheaterData.Main.Temp.ToString();
        }

        private async Task<Tuple<string, string>> GetLatitudeLongitude()
        {
            var locationReq = new GeolocationRequest(GeolocationAccuracy.Best);

            var location = await Geolocation.GetLocationAsync(locationReq);

            var lat = location.Latitude.ToString().Replace(",", ".");
            var lon = location.Longitude.ToString().Replace(",", ".");

            return Tuple.Create(lat, lon);
        }

        private async Task<bool> CheckLocationPermission()
        {
            var locationAlwaysStatus = await Permissions.CheckStatusAsync<Permissions.LocationAlways>();
            var locationWhenInUseStatus = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

            return locationAlwaysStatus == PermissionStatus.Granted && locationWhenInUseStatus == PermissionStatus.Granted;
        }

        private async Task GetDealsStats()
        {
            DealsStats = await _dealsService.GetDealsStats();

            ActivesPercentage = GetPercentage(DealsStats.Activos, DealsStats.Todos);

            MaxActives = GetFloatDivision(DealsStats.Activos, DealsStats.Todos);

            PausedPercentage = GetPercentage(DealsStats.Pausados, DealsStats.Todos);

            MaxPaused = GetFloatDivision(DealsStats.Pausados, DealsStats.Todos);

            DeletedPercentage = GetPercentage(DealsStats.Borrados, DealsStats.Todos);

            MaxDeleted = GetFloatDivision(DealsStats.Borrados, DealsStats.Todos);
        }

        private async Task GetProfileStats()
        {
            ProfileStats = await _profileService.GetProfileStats();

            ProducersPercentage = GetPercentage(ProfileStats.Productor, ProfileStats.Todos);

            CommissionAgentsPercentage = GetPercentage(ProfileStats.Comisionista, ProfileStats.Todos);

            ConsigneesPercentage = GetPercentage(ProfileStats.Consignataria, ProfileStats.Todos);

            MeatIndustriesPercentage = GetPercentage(ProfileStats.Frigorifico, ProfileStats.Todos);
        }

        private Task ShowWHidePreDealsSection()
        {
            PreDealsSectionVisibility = !PreDealsSectionVisibility;

            return Task.CompletedTask;
        }

        private Task ShowHideDealsSection()
        {
            DealsSectionVisibility = !DealsSectionVisibility;

            return Task.CompletedTask;
        }

        private Task ShowHideUsersSection()
        {
            UsersSectionVisibility = !UsersSectionVisibility;

            return Task.CompletedTask;
        }

        private async Task OpenLiniersQuotes() => await PopupNavigation.Instance.PushAsync(new LiniersQuotePopupPage(_linierItems));
        
        private async Task OpenDollarQuotes() => await PopupNavigation.Instance.PushAsync(new DollarQuotesPopupPage(_dollarQuotes));

        private async Task OpenGrainQuotes() => await PopupNavigation.Instance.PushAsync(new GrainsQuotesPopupPage(_grains));
        
        private async Task ShowWheater() => await PopupNavigation.Instance.PushAsync(new WeatherPopup(_wheaterData));

        private double GetPercentage(double part, double total) => Math.Round((part / total) * 100, 2, MidpointRounding.AwayFromZero);

        private float GetFloatDivision(double part, double total) => (float)Math.Round(part / total, 2, MidpointRounding.AwayFromZero);
    }
}