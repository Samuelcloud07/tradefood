﻿using Xamarin.Forms;

namespace TradeFood.Components
{
    public partial class MenuItemComponent : Grid
    {
        // Bindable Properties
        public static readonly BindableProperty ImageSourceProperty = BindableProperty.Create(
            nameof(ImageSource),
            typeof(string),
            typeof(MenuItemComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (MenuItemComponent)bindable;

                view.menuItemImage.Source = (string)newVal;
            }
        );

        public static readonly BindableProperty MenuItemTextProperty = BindableProperty.Create(
            nameof(MenuItemText),
            typeof(string),
            typeof(MenuItemComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (MenuItemComponent)bindable;

                view.menuItemTitle.Text = (string)newVal;
            }
        );

        public static readonly BindableProperty MenuItemSelectedProperty = BindableProperty.Create(
            nameof(MenuItemSelected),
            typeof(bool),
            typeof(MenuItemComponent),
            default(bool),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (MenuItemComponent)bindable;

                var selected = (bool)newVal;

                var colorPrimary = (Color)Application.Current.Resources["ColorPrimary"];

                view.startBox.Color = selected ? colorPrimary : Color.White;

                view.menuImageContainer.BackgroundColor = selected ? Color.FromHex("#C2C2C4") : Color.White;

                view.menuTitleContainer.BackgroundColor = selected ? Color.FromHex("#C2C2C4") : Color.White;
            }
        );

        public MenuItemComponent()
        {
            InitializeComponent();
        }

        // Properties
        public string ImageSource
        {
            get => (string)GetValue(ImageSourceProperty);
            set => SetValue(ImageSourceProperty, value);
        }

        public string MenuItemText
        {
            get => (string)GetValue(MenuItemTextProperty);
            set => SetValue(MenuItemTextProperty, value);
        }

        public bool MenuItemSelected
        {
            get => (bool)GetValue(MenuItemSelectedProperty);
            set => SetValue(MenuItemSelectedProperty, value);
        }
    }
}