﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market
{
    public class TroopDetails
    {
        //Chore and Wintering
        public string BusinessType { get; set; }
        public List<string> Breeds { get; set; }
        public int TroopQuality { get; set; }
        public List<TroopCategory> TroopCategories {get;set;}
        public string FirstEvidencePath { get; set; }
        public string SecondEvidencePath { get; set; }
        public string ThirdEvidencePath { get; set; }
        public string FirstVideoEvidencePath { get; set; }
        public string SecondVideoEvidencePath { get; set; }
        public string ThirdVideoEvidencePath { get; set; }


        //Wintering 
        public int FemaleQuantity { get; set; }
        public int MaleQuantity { get; set; }
        public int AnimalsQuantity { get; set; }
        public int TeethQuantity { get; set; }
        public string TroopWeightType { get; set; }
        public int MinimumWeight { get; set; }
        public int AverageWeight { get; set; }
        public int MaximumWeight { get; set; }
        public int Roughing { get; set; }
        public bool LiquidBrand { get; set; }
        public bool IsGelded { get; set; }
        public bool IsWeaned { get; set; }
        public string Health { get; set; }
        public string BodyState { get; set; }
        //public bool IsDirtyZone { get; set; }
        //public bool IsTick { get; set; }
        //public bool IsMioMio { get; set; }


        //Chore 
        public string SellType { get; set; }
        public int YieldPercent { get; set; }
        public string ChinaSuitable { get; set; }
        public string GeographicDestination { get; set; }
        public string ChoreSubCategory { get; set; }
        public string NutritionalTratemet { get; set; }
        public int LockdownDays { get; set; }
        public string MedleyComments { get; set; }        
        
        
    }
}
