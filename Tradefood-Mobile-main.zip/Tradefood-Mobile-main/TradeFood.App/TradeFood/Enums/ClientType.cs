﻿namespace TradeFood.Enums
{
    public enum ClientType
    {
        Productor_Persona,
        Productor_Empresa,
        Comisionista,
        Consignataria,
        Frigorífico,
        Administrador
    }
}