﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.ApiClient.ApisInterfaces;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class AgroNewsApiProvider : TradeFoodBaseApiProvider, IAgroNewsApiProvider
    {
        public AgroNewsApiProvider(IAppHttpClient httpClientSingleton,
                                   IApiExceptionManager apiExceptionManager)
            : base(httpClientSingleton, apiExceptionManager)
        {
        }

        public async Task<List<NewsReport>> GetAgroNewsAsync()
        {
            var news = await this.ExecuteRequest<TradeFoodApiResponse<List<NewsReport>>>(
                () => this.GetRestServiceFor<IAgroNewsApi>().GetAgroNewsAsync()).ConfigureAwait(false);

            return news.Data;
        }
    }
}