﻿using Refit;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.ApiClient.ApisInterfaces;
using TradeFood.Models;
using TradeFood.Models.Market.Dtos;

namespace TradeFood.Providers
{
    public class DealsApiProvider : TradeFoodBaseApiProvider, IDealsApiProvider
    {
        private readonly IDealsLocalProvider _dealsLocalProvider;

        public DealsApiProvider(IAppHttpClient httpClientSingleton,
                                IApiExceptionManager apiExceptionManager,
                                IDealsLocalProvider dealsLocalProvider)
            : base(httpClientSingleton, apiExceptionManager)
        {
            _dealsLocalProvider = dealsLocalProvider;
        }

        public async Task<List<Deal>> GetAllDealsAsync()
        {
            var deals = await this.ExecuteRequest<TradeFoodApiResponse<List<Deal>>>(
                () => this.GetRestServiceFor<IDealsApi>().GetAllDealsAsync()).ConfigureAwait(false);

            //return await _dealsLocalProvider.PersistDealsAsync(deals.Data);
            return deals.Data;
        }

        public async Task<string> BeginFileUploadAsync(string fileName)
        {
            var tempFileName = await this.ExecuteRequest<TradeFoodApiResponse<string>>(
                () => this.GetRestServiceFor<IDealsApi>().BeginFileUploadAsync(fileName)).ConfigureAwait(false);

            return tempFileName.Data;
        }

        public async Task<bool> EndFileUploadAsync(string fileHandle, long fileSize, string dealId, bool isThumbnail)
        {
            var uploadCompleted = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IDealsApi>().EndFileUploadAsync(fileHandle, fileSize, dealId, isThumbnail)).ConfigureAwait(false);

            return uploadCompleted.Data;
        }

        public async Task<Deal> CreateDealAsync(string userId, DealRequest deal)
        {
            var newDealCreated = await this.ExecuteRequest<TradeFoodApiResponse<Deal>>(
                () => this.GetRestServiceFor<IDealsApi>().CreateDealAsync(userId, deal)).ConfigureAwait(false);

            return newDealCreated.Data;
        }       

        public async Task<bool> UploadChunkAsync(MediaChunk mediaChunk)
        {
            var chunkUploaded = await this.ExecuteRequest<TradeFoodApiResponse<bool>>(
                () => this.GetRestServiceFor<IDealsApi>().UploadChunkAsync(mediaChunk)).ConfigureAwait(false);

            return chunkUploaded.Data;
        }

        public async Task<DealDto> CreateChoreDealAsync(string userId, DealDto deal)
        {
            var newDeal = await this.ExecuteRequest<TradeFoodApiResponse<DealDto>>(
                () => this.GetRestServiceFor<IDealsApi>().CreateChoreDealAsync(userId, deal)).ConfigureAwait(false);

            return newDeal.Data;
        }

        public async Task<DealDto> CreateWinteringDealAsync(string userId, DealDto deal)
        {
            var newDeal = await this.ExecuteRequest<TradeFoodApiResponse<DealDto>>(
                () => this.GetRestServiceFor<IDealsApi>().CreateWinteringDealAsync(userId, deal)).ConfigureAwait(false);

            return newDeal.Data;
        }

        public async Task<List<DealApiDto>> GetDealsAsync()
        {
            var deals = await this.ExecuteRequest<TradeFoodApiResponse<List<DealApiDto>>>(
                () => this.GetRestServiceFor<IDealsApi>().GetDealsAsync()).ConfigureAwait(false);

            //return await _dealsLocalProvider.PersistDealsAsync(deals.Data);
            return deals.Data;
        }

        public async Task<DealsStats> GetDealsStats()
        {
            var dealStats = await this.ExecuteRequest<TradeFoodApiResponse<DealsStats>>(
                () => this.GetRestServiceFor<IDealsApi>().GetDealsStats()).ConfigureAwait(false);

            return dealStats.Data;
        }
    }
}