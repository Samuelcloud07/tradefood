﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeFood.Enums;

namespace TradeFood.Models.Profile.Dtos
{
    public class SocietiesAndPersonDto
    {
        public long id { get; set; }
        public bool IsActive { get; set; } //Pueden desactivar
        public TypeSocieties Type { get; set; }

        public string Name { get; set; }
        public string Cuit { get; set; }
        public string CommercialReference { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public IList<AddressDto> Addresses { get; set; } //Una razon social, tiene muchas direcciones.

        //public string Province { get; set; }
        //public string Location { get; set; }
        //public string Street { get; set; }
        //public bool Number { get; set; }
        //public bool WithoutNumber { get; set; }
        //public string FloorDepartment { get; set; }
        //public string PostalCode { get; set; }
        //public string Comments { get; set; }

        //Personas fisicas
        public bool? Monotributist { get; set; } //Condicion frente al IVA
    }
}
