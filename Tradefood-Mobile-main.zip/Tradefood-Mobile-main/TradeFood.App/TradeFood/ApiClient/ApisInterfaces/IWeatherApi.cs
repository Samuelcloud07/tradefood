﻿using Refit;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.ApiClient.ApisInterfaces
{
    public interface IWeatherApi
    {
        [Get("/tradefoodweatherfunction/Weather/weather?lat={lat}&lon={lon}")]
        Task<TradeFoodApiResponse<WheaterData>> GetWheaterAsync(string lat, string lon);
    }
}