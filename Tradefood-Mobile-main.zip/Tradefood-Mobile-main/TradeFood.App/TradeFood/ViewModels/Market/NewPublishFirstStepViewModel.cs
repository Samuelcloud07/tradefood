﻿using Acr.UserDialogs;
using Newtonsoft.Json;
using Plugin.Media.Abstractions;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models.Market;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels.Items;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class NewPublishFirstStepViewModel : BaseViewModel
    {
        private readonly IDealsService _dealsService;
        private readonly IStatesService _statesService;
        private readonly IMediaHelper _mediaHelper;
        private readonly IDialogsHelper _dialogsHelper;
        private readonly IAppSettings _appSettings;
        private readonly IUserDialogs _userDialogs;

        public NewPublishFirstStepViewModel(ILogger logger,
                                   IDealsService dealsService,
                                   IStatesService statesService,
                                   IMediaHelper mediaHelper,
                                   IDialogsHelper dialogsHelper,
                                   IAppSettings appSettings,
                                   IUserDialogs userDialogs)
            : base(logger)
        {
            _dealsService = dealsService;
            _statesService = statesService;
            _mediaHelper = mediaHelper;
            _dialogsHelper = dialogsHelper;
            _appSettings = appSettings;
            _userDialogs = userDialogs;

            CancelPublishCommand = new SandboxedCommand(CancelPublish);

            GoToSecondStepCommand = new SandboxedCommand(GoToSecondStep);

            SelectBreedsCommand = new SandboxedCommand(SelectBreeds);

            SelectSubCategoryCommand = new SandboxedCommand(SelectSubCategory);

            Breeds = new ObservableCollection<BreedItemViewModel>
            {
                new BreedItemViewModel("Aberdeen Angus Negro"),
                new BreedItemViewModel("Aberdeen Angus Colorado"),
                new BreedItemViewModel("Brangus Negro"),
                new BreedItemViewModel("Brangus Colorado"),
                new BreedItemViewModel("Hereford"),
                new BreedItemViewModel("Braford"),
                new BreedItemViewModel("Charolais"),
                new BreedItemViewModel("Holando Argentino"),
                new BreedItemViewModel("Shorthon"),
                new BreedItemViewModel("Limousin"),
                new BreedItemViewModel("Limagnus"),
                new BreedItemViewModel("Careta"),
                new BreedItemViewModel("Media Sangre"),
                new BreedItemViewModel("Cuartino"),
                new BreedItemViewModel("Bubalinos")
            };

            UploadFirstEvidenceCommand = new SandboxedCommand(UploadFirstEvidence);

            UploadSecondEvidenceCommand = new SandboxedCommand(UploadSecondEvidence);

            UploadThirdEvidenceCommand = new SandboxedCommand(UploadThirdEvidence);

            RecordFirstEvidenceVideoCommand = new SandboxedCommand(RecordFirstEvidenceVideo);

        }


        // Wintering and Chore Properties        
        public List<TroopCategory> TroopCategoriesSelected { get; set; } = new List<TroopCategory>();
        public List<string> BreedsSelected { get; set; } = new List<string>();

        private string _businessTypeSelected;
        public string BusinessTypeSelected
        {
            get => _businessTypeSelected;
            set {
                _businessTypeSelected = value;

                this.OnPropertyChanged(nameof(BusinessTypeSelected));

                DisplayForm();// muestro el formulario

                switch (_businessTypeSelected)
                {
                    case ("Invernada"):
                        TroopCategories = new ObservableCollection<TroopCategoryItemViewModel>
                        {
                            new TroopCategoryItemViewModel("Terneros","Male"),
                            new TroopCategoryItemViewModel("Terneras","Female"),
                            new TroopCategoryItemViewModel("Vacas","Female"),
                            new TroopCategoryItemViewModel("Novillitos","Male"),
                            new TroopCategoryItemViewModel("Vaquillonas","Female"),
                        };
                        NutritionalTratmentIsVisible = false;
                        PopurriCommentsIsVisible = false;
                        IsSubcategoriesVisible = false;

                        HealthOptions = new List<string>
                        {
                            "Completa",
                            "Incompleta"
                        };

                        BodyStateOptions = new List<string>
                        {
                            "Muy Bueno",
                            "Bueno",
                            "Regular",
                            "Flacos"
                        };

                        break;
                    case ("Cría"):
                        TroopCategories = new ObservableCollection<TroopCategoryItemViewModel>
                        {
                            new TroopCategoryItemViewModel("Vaquillonas Preñadas","Female"),
                            new TroopCategoryItemViewModel("Vacas Preñadas","Female"),
                            new TroopCategoryItemViewModel("Vaquillonas p/ entorar","Female"),
                            new TroopCategoryItemViewModel("Vacas p/ entorar","Female"),
                        };
                        NutritionalTratmentIsVisible = false;
                        PopurriCommentsIsVisible = false;
                        IsSubcategoriesVisible = false;
                        break;
                    case ("Faena"):
                        TroopCategories = new ObservableCollection<TroopCategoryItemViewModel>
                        {
                            new TroopCategoryItemViewModel("Novillos","Male"){ AverageWeight=100},
                            new TroopCategoryItemViewModel("Mej","Male"){ AverageWeight=100},
                            new TroopCategoryItemViewModel("Novillitos","Male"){ AverageWeight=100},
                            new TroopCategoryItemViewModel("Vaquillonas","Female"){ AverageWeight=100},
                            new TroopCategoryItemViewModel("Vacas","Female"){ AverageWeight=100},
                            new TroopCategoryItemViewModel("Toros","Male"){ AverageWeight=100}
                        };
                        IsTeethVisible = false;
                        GeographicDestination = new List<string>()
                        {
                            "UE Hilton",
                            "UE no Hilton",
                            "Cuota 481",
                            "Terceros países/Consumo"
                        };
                        break;
                }

                CountCategories = TroopCategories.Count * 45;

            }
        }                      
        public string FirstEvidencePath { get; set; }
        public bool FirstGridVisible { get; set; } = false;
        public bool SecondGridVisible { get; set; } = false;
        public bool ThirdGridVisible { get; set; } = false;
        public string SecondEvidencePath { get; set; }
        public string ThirdEvidencePath { get; set; }
        public string FirstVideoEvidencePath { get; set; }
        public string SecondVideoEvidencePath { get; set; }
        public string ThirdVideoEvidencePath { get; set; }


        //Wintering Properties
        public string FemaleQuantity { get; set; }
        public string MaleQuantity { get; set; }
        public string AnimalsQuantity { get; set; }
        public string Health { get; set; }
        public string BodyState { get; set; }
        public string Roughing { get; set; }

        public string _troopWeightTypeSelected;
        public string TroopWeightTypeSelected
        {
            get => _troopWeightTypeSelected;
            set
            {
                _troopWeightTypeSelected = value;

                this.OnPropertyChanged(nameof(TroopWeightTypeSelected));
            }
        }
        public int MinimumWeight { get; set; }
        public int AverageWeight { get; set; }
        public int MaximumWeight { get; set; }
        public int TeethQuantitySelected { get; set; }
        public int TroopQuality { get; set; }        
        public bool LiquidBrand { get; set; }
        public bool Gelded { get; set; }
        public bool Weaned { get; set; }
        


        //Chore Properties
        public string _sellTypeSelected;
        public string SellTypeSelected
        {
            get => _sellTypeSelected;
            set
            {
                _sellTypeSelected = value;
                this.OnPropertyChanged(nameof(SellTypeSelected));
            }
        }
        public string YieldPercent { get; set; } 

        public string _chinaSuitableSelected;
        public string ChinaSuitableSelected
        {
            get => _chinaSuitableSelected;

            set
            {
                _chinaSuitableSelected = value;
                this.OnPropertyChanged(ChinaSuitableSelected);
            }
        }              
        public string GeographicDestinationSelected { get; set; }        
        public string ChoreSubCategorySelected { get; set; }

        public string _nutritionalTratementSelected;
        public string NutritionalTratementSelected
        {
            get => _nutritionalTratementSelected;
            set
            {
                _nutritionalTratementSelected = value;

                if (_nutritionalTratementSelected == "Feedlot" || _nutritionalTratementSelected == "Ración")
                {
                    SelectDays();
                }
            }
        }
        public string LockdownDays { get; set; }
        public string PopurriComments { get; set; }


        //UI Lists
        public ObservableCollection<TroopCategoryItemViewModel> TroopCategories { get; set; }
        public ObservableCollection<BreedItemViewModel> Breeds { get; set; }
        public List<string> GeographicDestination { get; set; }
        public List<string> ChoreSubCategories { get; set; }
        public List<string> Subcategories { get; set; }        
        public List<string> HealthOptions { get; set; }
        public List<string> BodyStateOptions { get; set; }
        public List<int> TeethQuantity { get; set; }


        //UI properties
        public int CountCategories { get; set; }
        public Action DisplayForm { get; set; }
        public bool IsSubcategoriesVisible { get; set; } = false;
        public int SubcategoriesHeight { get; set; } = 0;
        public bool NutritionalTratmentIsVisible { get; set; } = false;
        public int NutritionalTratementHeight { get; set; } = 0;
        public bool PopurriCommentsIsVisible { get; set; } = false;
        public int PupurriCommentsHeight { get; set; } = 0;
        public bool MultipleGendersIsVisible { get; set; } = false;
        public int MultipleGendersHeight { get; set; } = 0;
        public bool OnlyGenderIsVisible { get; set; } = true;
        public int OnlyGenderHeight { get; set; } = 0;
        public bool IsTeethVisible { get; set; } = false;
        public int TeethHeight { get; set; } = 0;
        public bool IsGeldedVisible { get; set; } = false;
        public int GeldedHeight { get; set; } = 0;
        public bool IsWeanedVisible { get; set; } = false;
        public int WeanedHeight { get; set; } = 0;
        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();
        public bool HasErrors { get; set; }


        //Commands
        public SandboxedCommand SelectSubCategoryCommand { get; private set; }
        public SandboxedCommand CancelPublishCommand { get; private set; }
        public SandboxedCommand GoToSecondStepCommand { get; private set; }
        public SandboxedCommand SelectBreedsCommand { get; private set; }
        public SandboxedCommand UploadFirstEvidenceCommand { get; private set; }
        public SandboxedCommand UploadSecondEvidenceCommand { get; private set; }
        public SandboxedCommand UploadThirdEvidenceCommand { get; private set; }
        public SandboxedCommand RecordFirstEvidenceVideoCommand { get; private set; }

        //Methods
        private bool ValidateAll()
        {
            Errors.Clear();

            if (TroopCategories.Where(x=>x.Selected==true).Count()==0)
                Errors.Add(nameof(TroopCategories), Strings.YouMustSelectAtLeastOneCategory);

            if (Breeds.Where(x => x.Selected == true).Count() == 0)
                Errors.Add(nameof(Breeds), Strings.YouMustSelectAtLeastOneCategory);

            if (BusinessTypeSelected == "Faena")
            {
                if(SellTypeSelected==null)
                    Errors.Add(nameof(SellTypeSelected), Strings.YouMustSelectAtLeastOneOption);

                if(SellTypeSelected=="Venta en pie")
                {
                    if (YieldPercent == "0" || string.IsNullOrEmpty(YieldPercent))
                        Errors.Add(nameof(YieldPercent), "Debe ingresar un valor mayor que 0");
                }

                if(GeographicDestinationSelected==null)
                    Errors.Add(nameof(GeographicDestinationSelected), Strings.YouMustSelectAtLeastOneOption);
                else
                {
                    if (GeographicDestinationSelected.StartsWith("Terceros"))
                    {
                        if (ChinaSuitableSelected == null)
                            Errors.Add(nameof(ChinaSuitableSelected), Strings.YouMustSelectAtLeastOneOption);
                    }
                }                

                if (IsSubcategoriesVisible == true && ChoreSubCategorySelected==null)
                    Errors.Add(nameof(ChoreSubCategorySelected), "Debe seleccionar una opcion");

                if(NutritionalTratmentIsVisible==true && NutritionalTratementSelected==null)
                    Errors.Add(nameof(NutritionalTratementSelected), "Debe seleccionar una opcion");

                if (PopurriCommentsIsVisible == true && string.IsNullOrEmpty(PopurriComments))
                    Errors.Add(nameof(PopurriComments),"Debe completar este campo");
                
            }

            if (BusinessTypeSelected == "Invernada")
            {
                if (IsTeethVisible && TeethQuantitySelected==0)
                    Errors.Add(nameof(TeethQuantitySelected), "Debe seleccionar un valor");

                if (TroopWeightTypeSelected == null)
                    Errors.Add(nameof(TroopWeightTypeSelected), "Debe seleccionar un valor");

                if(TroopWeightTypeSelected=="Tropa despareja")
                {
                    if (MinimumWeight == 0)
                        Errors.Add(nameof(MinimumWeight), "Debe especificar un valor mayor que 0");

                    if (MaximumWeight == 0)
                        Errors.Add(nameof(MaximumWeight), "Debe especificar un valor mayor que 0");
                }

                if (AverageWeight == 0)
                    Errors.Add(nameof(AverageWeight), "Debe especificar un valor mayor que 0");

                if (string.IsNullOrEmpty(Health))
                    Errors.Add(nameof(Health), "Debe seleccionar una opcion");

                if (string.IsNullOrEmpty(BodyState))
                    Errors.Add(nameof(BodyState), "Debe seleccionar una opcion");
            }

            if (Roughing == "0" || string.IsNullOrEmpty(Roughing) || Int32.Parse(Roughing) > 8)
                Errors.Add(nameof(Roughing), "Debe especificar un valor entre 1 y 8");

            if(OnlyGenderIsVisible == true)
            {
                if (AnimalsQuantity == "0" || string.IsNullOrEmpty(AnimalsQuantity))
                    Errors.Add(nameof(AnimalsQuantity), "Debe ingresar un valor mayor que 0");
            }

            if(MultipleGendersIsVisible == true)
            {
                if (MaleQuantity == "0" || string.IsNullOrEmpty(MaleQuantity))
                    Errors.Add(nameof(MaleQuantity), "Debe ingresar un valor mayor que 0");

                if(FemaleQuantity=="0" || string.IsNullOrEmpty(FemaleQuantity))
                    Errors.Add(nameof(FemaleQuantity), "Debe ingresar un valor mayor que 0");
            }

            if (TroopQuality == 0)
                Errors.Add(nameof(TroopQuality), "Debe seleccionar un valor mayor que 0");            

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();            
        }

        private async Task UploadFirstEvidence()
        {
            var result = await _userDialogs.ActionSheetAsync("Elija cómo cargar la evidencia", "Cancelar", null, null, "Grabar Video", "Video desde Galería");

            switch (result)
            {
                //case "Desde Cámara":
                //    var cameraFile = await _mediaHelper.LoadImageFromSourceAsync(
                //        Enums.ImageSource.Camera,
                //        $"EvidenciaTropa1_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                //        CameraDevice.Rear);

                //    if (cameraFile == null)
                //        return;

                //    FirstEvidencePath = cameraFile.Path;
                //    FirstGridVisible = true;
                //    break;

                //case "Foto desde Galería":
                //    var galleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                //        Enums.ImageSource.Gallery,
                //        $"EvidenciaTropa1_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                //        CameraDevice.Rear);

                //    if (galleryFile == null)
                //        return;
                    
                //    FirstEvidencePath = galleryFile.Path;

                //    FirstGridVisible = true;
                //    break;

                case "Grabar Video":
                    var videoFile = await _mediaHelper.RecordVideoAsync(
                        $"EvidenciaTropa1Video_{DateTime.Now:dd/MM/yyyy-hhmmss}", TimeSpan.FromSeconds(40));

                    if (videoFile == null)
                        return;

                    FirstVideoEvidencePath = videoFile.Path;
                    FirstGridVisible = true;
                    break;
                case "Video desde Galería":
                    var videoGalleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.VideoGallery,
                        string.Empty,
                        CameraDevice.Front);
                    
                    FirstVideoEvidencePath = videoGalleryFile.Path;

                    FirstGridVisible = true;
                    break;
            }

        }

        private async Task UploadSecondEvidence()
        {
            var result = await _userDialogs.ActionSheetAsync("Elija cómo cargar la evidencia", "Cancelar", null, null, "Desde Cámara", "Foto desde Galería", "Grabar Video", "Video desde Galería");

            switch (result)
            {
                case "Desde Cámara":
                    var cameraFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Camera,
                        $"EvidenciaTropa2_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (cameraFile == null)
                        return;

                    SecondEvidencePath = cameraFile.Path;
                    SecondGridVisible = true;
                    break;

                case "Foto desde Galería":
                    var galleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Gallery,
                        $"EvidenciaTropa2_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (galleryFile == null)
                        return;

                    SecondEvidencePath = galleryFile.Path;
                    SecondGridVisible = true;
                    break;

                case "Grabar Video":
                    var videoFile = await _mediaHelper.RecordVideoAsync(
                        $"EvidenciaTropa2Video_{DateTime.Now:dd/MM/yyyy-hhmmss}", TimeSpan.FromSeconds(40));

                    if (videoFile == null)
                        return;

                    SecondVideoEvidencePath = videoFile.Path;
                    SecondGridVisible = true;
                    break;

                case "Video desde Galería":
                    var videoGalleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.VideoGallery,
                        string.Empty,
                        CameraDevice.Front);

                    SecondVideoEvidencePath = videoGalleryFile.Path;
                    SecondGridVisible = true;
                    break;
            }
        }

        private async Task UploadThirdEvidence()
        {
            var result = await _userDialogs.ActionSheetAsync("Elija cómo cargar la evidencia", "Cancelar", null, null, "Desde Cámara", "Foto desde Galería", "Grabar Video", "Video desde Galería");

            switch (result)
            {
                case "Desde Cámara":
                    var cameraFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Camera,
                        $"EvidenciaTropa3_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (cameraFile == null)
                        return;

                    ThirdEvidencePath = cameraFile.Path;
                    ThirdGridVisible = true;
                    break;

                case "Foto desde Galería":
                    var galleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Gallery,
                        $"EvidenciaTropa3_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (galleryFile == null)
                        return;

                    ThirdEvidencePath = galleryFile.Path;
                    ThirdGridVisible = true;
                    break;

                case "Grabar Video":
                    var videoFile = await _mediaHelper.RecordVideoAsync(
                        $"EvidenciaTropa3Video_{DateTime.Now:dd/MM/yyyy-hhmmss}", TimeSpan.FromSeconds(40));

                    if (videoFile == null)
                        return;

                    ThirdVideoEvidencePath = videoFile.Path;
                    ThirdGridVisible = true;
                    break;

                case "Video desde Galería":
                    var videoGalleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.VideoGallery,
                        string.Empty,
                        CameraDevice.Front);

                    ThirdVideoEvidencePath = videoGalleryFile.Path;
                    ThirdGridVisible = true;
                    break;
            }
        }

        private async Task RecordFirstEvidenceVideo()
        {
            var videoFile = await _mediaHelper.RecordVideoAsync(
                        $"EvidenciaTropa1Video_{DateTime.Now:dd/MM/yyyy-hhmmss}", TimeSpan.FromSeconds(40));

            if (videoFile == null)
                return;

            FirstVideoEvidencePath = videoFile.Path;
        }

        private async Task SelectDays()
        {
            await PopupNavigation.Instance.PushAsync(new NutritionalTratementPopupPage(NutritionalTratementSelected));
        }

        private async Task SelectSubCategory()
        {
            if (BusinessTypeSelected == "Faena")
            {
                if (ChoreSubCategorySelected == "Gorda" || ChoreSubCategorySelected == "Carnicera")
                {
                    NutritionalTratmentIsVisible = true;
                    NutritionalTratementHeight = -1;
                }
                else
                {
                    NutritionalTratmentIsVisible = false;
                    NutritionalTratementHeight = 0;
                }
                                       

                if (ChoreSubCategorySelected == "Popurrí")
                {
                    PopurriCommentsIsVisible = true;
                    PupurriCommentsHeight = -1;
                }
                else
                {
                    PopurriCommentsIsVisible = false;
                    PupurriCommentsHeight = 0;
                } 

            }
            
        }

        private async Task SelectBreeds()
        {
            await PopupNavigation.Instance.PushAsync(new BreedsPopupPage(Breeds));
        }
        private async Task CancelPublish()
        {
            if (!await _dialogsHelper.ShowConfirmAsync("¿Está seguro que quiere cancelar la creación del prenegocio?"))
                return;

            await Shell.Current.GoToAsync("..");
        }

        private async Task GoToSecondStep() {
            
            if (!ValidateAll())
                return;

            Breeds.Where(x => x.Selected == true).ToList().ForEach(y => BreedsSelected.Add(y.Name));
            TroopCategories.Where(x => x.Selected == true).ToList().ForEach(y =>
            {
                TroopCategoriesSelected.Add(new TroopCategory
                {
                    Name = y.Name,
                    AverageWeightAmount = y.AverageWeight,
                    Gender = y.Gender,
                });
            });

            var a = YieldPercent;

            TroopDetails troopDetails = new TroopDetails
            {
                BusinessType = BusinessTypeSelected,
                Breeds = BreedsSelected,
                TroopCategories = TroopCategoriesSelected,
                SellType = SellTypeSelected,
                YieldPercent = YieldPercent == null ? 0 : Int32.Parse(YieldPercent),
                ChinaSuitable=ChinaSuitableSelected,
                GeographicDestination=GeographicDestinationSelected,
                ChoreSubCategory=ChoreSubCategorySelected,
                NutritionalTratemet=NutritionalTratementSelected,
                LockdownDays= LockdownDays == null ? 0 : Int32.Parse(LockdownDays),
                MedleyComments= PopurriComments,
                FemaleQuantity=FemaleQuantity == null ? 0 : Int32.Parse(FemaleQuantity),
                MaleQuantity=MaleQuantity == null ? 0 : Int32.Parse(MaleQuantity),
                AnimalsQuantity=AnimalsQuantity == null ? 0 : Int32.Parse(AnimalsQuantity),
                TeethQuantity=TeethQuantitySelected,
                TroopWeightType=TroopWeightTypeSelected,
                MinimumWeight=MinimumWeight,
                AverageWeight=AverageWeight,
                MaximumWeight=MaximumWeight,
                Roughing=Roughing == null ? 0 : Int32.Parse(Roughing),
                LiquidBrand=LiquidBrand,
                IsGelded=Gelded,
                IsWeaned=Weaned,
                TroopQuality=TroopQuality,
                Health=Health,
                BodyState=BodyState,
                FirstEvidencePath = FirstEvidencePath,
                SecondEvidencePath = SecondEvidencePath,
                ThirdEvidencePath = ThirdEvidencePath,
                FirstVideoEvidencePath = FirstVideoEvidencePath,
                SecondVideoEvidencePath = SecondVideoEvidencePath,
                ThirdVideoEvidencePath = ThirdVideoEvidencePath
            };

            string serializedData = JsonConvert.SerializeObject(troopDetails);

            await Shell.Current.GoToAsync($"NewPublishSecondStepPage?troopDetails={serializedData}");
        } 
    }
}
