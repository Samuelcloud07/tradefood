﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeFood.Models;

namespace TradeFood.ViewModels
{
    public class ProvinceLocationItemViewModel
    {
        public string Name { get; set; }
        public bool Checked { get; set; }
        public ProvinceLocationItemViewModel(ProvinceLocation province)
        {
            this.Name = province.Name;
        }


    }
}
