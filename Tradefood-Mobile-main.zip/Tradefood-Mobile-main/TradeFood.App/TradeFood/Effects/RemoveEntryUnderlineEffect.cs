﻿using Xamarin.Forms;

namespace TradeFood.Effects
{
    public class RemoveEntryUnderlineEffect : RoutingEffect
    {
        public RemoveEntryUnderlineEffect()
            : base("TradeFood.RemoveEntryUnderlineEffect")
        {
        }
    }
}