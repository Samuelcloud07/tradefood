﻿using System;
using TradeFood.Droid.Effects;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportEffect(typeof(RemoveSearchBarUnderlineEffect), nameof(RemoveSearchBarUnderlineEffect))]
namespace TradeFood.Droid.Effects
{
    public class RemoveSearchBarUnderlineEffect : PlatformEffect
    {
        protected override void OnAttached()
        {
            if (Control is null)
                throw new NotImplementedException();

            var plateId = Android.Content.Res.Resources.System.GetIdentifier("android:id/search_plate", null, null);
            var plate = Control.FindViewById(plateId);

            plate.SetBackgroundColor(Android.Graphics.Color.Transparent);
        }

        protected override void OnDetached()
        {
        }
    }
}