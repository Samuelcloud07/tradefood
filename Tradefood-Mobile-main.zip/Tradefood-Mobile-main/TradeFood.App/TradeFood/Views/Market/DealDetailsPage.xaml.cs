﻿using Acr.UserDialogs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Helpers;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels;
using TradeFood.ViewModels.Base;
using Xamarin.CommunityToolkit.Core;
using Xamarin.CommunityToolkit.UI.Views;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.Views
{
    public partial class DealDetailsPage : BasePage
    {
        private DealDetailsViewModel _vm;

        private IInteraction _diplayVideoFromSourceInteraction;
        public IInteraction DiplayVideoFromSourceInteraction
        {
            get => _diplayVideoFromSourceInteraction;
            set
            {
                if (_diplayVideoFromSourceInteraction != null)
                    _diplayVideoFromSourceInteraction.Requested -= DiplayVideoFromSource;

                _diplayVideoFromSourceInteraction = value;

                _diplayVideoFromSourceInteraction.Requested += DiplayVideoFromSource;
            }
        }

        public DealDetailsPage()
        {
            InitializeComponent();

            _vm = new DealDetailsViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<IAppSettings>(),
                TypeLocator.Resolve<IUserDialogs>(),
                TypeLocator.Resolve<IDialogsHelper>());

            this.BindingContext = _vm;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            DiplayVideoFromSourceInteraction = _vm.DiplayVideoFromSourceInteraction;

            if (DeviceInfo.Platform == DevicePlatform.UWP)
            {
                MainThread.InvokeOnMainThreadAsync(async () =>
                {
                    Shell.SetNavBarIsVisible(this, true);

                    await Task.Delay(100);

                    Shell.SetNavBarIsVisible(this, false);
                });
            }
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
        }

        private void DiplayVideoFromSource(object sender, EventArgs e)
        {
            this.desktopVideoControl.Source = MediaSource.FromUri(new Uri(_vm.MainEvidenceFile));
        }

        //Cristian video
        List<MediaElement> mediaElements = new List<MediaElement>();
        private void evidenceCarousel_ItemSwiped(PanCardView.CardsView view, PanCardView.EventArgs.ItemSwipedEventArgs args)
        {
            mediaElements[args.Index].Stop();
        }

        private void video_BindingContextChanged(object sender, EventArgs e)
        {
            var element = sender as MediaElement;
            mediaElements.Add(element);
        }
    }
}