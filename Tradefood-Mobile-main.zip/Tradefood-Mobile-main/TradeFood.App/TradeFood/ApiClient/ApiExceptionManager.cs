﻿using TradeFood.Exceptions;
using TradeFood.Models;
using Refit;
using System;
using System.Net;
using System.Threading.Tasks;

namespace TradeFood.ApiClient
{
    public class ApiExceptionManager : IApiExceptionManager
    {
        public async Task HandleHttpStatusCodeAsync(ApiException ex)
        {
            var badResponse = await ex.GetContentAsAsync<TradeFoodApiErrorResponse>();
            TradeFoodApiErrorResponse response() => badResponse;

            switch (ex.StatusCode)
            {
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.NotFound:
                    throw new NotFoundException(response().ErrorMessage, ex);
                    //throw new NotFoundException(ex.Message, ex);
                case HttpStatusCode.Unauthorized:
                case HttpStatusCode.Forbidden:
                    throw new ServiceAuthenticationException(ex.Content);
                case HttpStatusCode.InternalServerError:
                    throw new Exception("Internal server error", ex);
                default:
                    throw new HttpRequestExceptionEx((HttpStatusCode)response().HttpCodeStatus, ex.Content);
            }
        }

        public async Task<T> HandleHttpStatusCodeAsync<T>(ApiException ex)
        {
            await HandleHttpStatusCodeAsync(ex).ConfigureAwait(false);

            return default;
        }
    }
}