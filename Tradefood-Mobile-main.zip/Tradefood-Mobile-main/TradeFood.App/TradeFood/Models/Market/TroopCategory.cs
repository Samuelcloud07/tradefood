﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace TradeFood.Models.Market
{
    public class TroopCategory
    {
        public string Name { get; set; }
        public string Gender { get; set; }
        public int AverageWeightAmount { get; set; }
               
    }
}
