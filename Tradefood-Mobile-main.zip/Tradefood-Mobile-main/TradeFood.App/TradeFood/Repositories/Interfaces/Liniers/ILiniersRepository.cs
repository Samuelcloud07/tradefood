﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Repositories
{
    public interface ILiniersRepository : ISQLiteRepository<LiniersData>
    {
        Task<List<LiniersData>> GetLiniersQuotesByCategoryAsync(string category);

        Task<List<LiniersData>> PersistLiniersDataAsync(IEnumerable<LiniersData> liniersData);
    }
}