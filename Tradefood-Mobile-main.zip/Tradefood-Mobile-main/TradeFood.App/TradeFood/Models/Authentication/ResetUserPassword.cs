﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class ResetUserPassword
    {
        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }
        [JsonProperty("newpassword")]
        public string NewPassword { get; set; }

        [JsonProperty("passwordResetToken")]
        public string PasswordResetToken { get; set; }
    }
}