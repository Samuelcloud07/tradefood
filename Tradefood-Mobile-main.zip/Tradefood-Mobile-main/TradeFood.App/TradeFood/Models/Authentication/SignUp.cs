﻿using Newtonsoft.Json;
using TradeFood.Enums;

namespace TradeFood.Models
{
    public class SignUp
    {
        [JsonProperty("profileType")]
        public ClientType ProfileType { get; set; }

        [JsonProperty("nameAndLastname")]
        public string NameAndLastname { get; set; }

        [JsonProperty("businessName")]
        public string BusinessName { get; set; }

        [JsonProperty("nationalId")]
        public long? NationalId { get; set; }

        [JsonProperty("cuit")]
        public long? Cuit { get; set; }

        [JsonProperty("userJob")]
        public string UserJob { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("location")]
        public string Location { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }
    }
}