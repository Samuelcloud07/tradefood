﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Extensions;
using TradeFood.Commands;
using Rg.Plugins.Popup.Services;
using TradeFood.Views.Popups;
using Xamarin.Essentials;
using System.Linq;
using TradeFood.Resources;
using TradeFood.Settings;
using Xamarin.Forms;
using System;
using TradeFood.Views;
using TradeFood.Repositories;

namespace TradeFood.ViewModels
{
    public class HomeViewModel : BaseViewModel
    {
        private readonly ILiniersService _liniersService;
        private readonly IDollarService _dollarService;
        private readonly IGrainsService _grainsService;
        private readonly IWheaterService _wheaterService;
        private readonly IAgroNewsService _agroNewsService;
        private readonly IAgroNewsRepository _agroNewsRepository;
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        private List<LiniersData> _liniersQuotes = new List<LiniersData>();
        private List<LiniersItemViewModel> _linierItems = new List<LiniersItemViewModel>();
        private List<DollarData> _dollarQuotes = new List<DollarData>();
        private List<GrainsItemViewModel> _grains = new List<GrainsItemViewModel>();

        private bool _newsUpdated;

        public HomeViewModel(ILogger logger,
                             ILiniersService liniersService,
                             IDollarService dollarService,
                             IGrainsService grainsService,
                             IWheaterService wheaterService,
                             IAgroNewsService agroNewsService,
                             IAgroNewsRepository agroNewsRepository,
                             IAppSettings appSettings,
                             IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _liniersService = liniersService;
            _dollarService = dollarService;
            _grainsService = grainsService;
            _wheaterService = wheaterService;
            _agroNewsService = agroNewsService;
            _agroNewsRepository = agroNewsRepository;
            _appSettings = appSettings;
            _dialogsHelper = dialogsHelper;

            GoToMarketCommand = new SandboxedCommand(GoToMarket);

            LiniersQuoteSelectedCommand = new SandboxedCommand(LiniersQuoteSelected);

            OpenDollarQuotesCommand = new SandboxedCommand(OpenDollarQuotes);

            OpenGrainQuotesCommand = new SandboxedCommand(OpenGrainQuotes);

            ShowWheaterCommand = new SandboxedCommand(ShowWheater);

            OpenChatbotCommand = new SandboxedCommand(OpenChatbot);

            OpenNewsReportsCommand = new SandboxedCommand(OpenNewsReports);

            LogoutCommand = new SandboxedCommand(Logout);
        }

        protected override async Task InitializeAsync()
        {
            MainThread.BeginInvokeOnMainThread(() => _dialogsHelper.ShowDialog());

            UserName = _appSettings.UserName;

            Title = $"¡Hola {UserName}!";

            this.OnPropertyChanged(nameof(Title));

            await base.InitializeAsync();

            var tasks = new Task[]
            {
                GetLinierQuotes(),
                GetDollarQuotes(),
                GetGrainQuotes(),
                GetWeatherForecast(),
                GetAgroNews()
            };

            await Task.WhenAll(tasks);

            _dialogsHelper.HideDialog();
        }

        // Properties
        public string Title { get; private set; }

        public string UserName { get; private set; }

        public string CurrentTemp { get; private set; }

        public string VersionNumber => $"v{VersionTracking.CurrentVersion}";

        public DateTime ReleaseDate => new DateTime(2021, 12, 20);

        public ObservableCollection<LiniersData> LiniersQuotes { get; private set; } = new ObservableCollection<LiniersData>();

        public ObservableCollection<GrainQuoteItemViewModel> GrainQuotes { get; private set; } = new ObservableCollection<GrainQuoteItemViewModel>();

        public ObservableCollection<DollarData> DollarQuotes { get; private set; } = new ObservableCollection<DollarData>();

        public ObservableCollection<AgroNewsItemViewModel> AgroNews { get; private set; } = new ObservableCollection<AgroNewsItemViewModel>();

        public LiniersData SelectedLiniersQuote { get; set; }

        public DollarData OfficialDollar { get; private set; }

        public Grain GrainQuote { get; private set; }

        public GrainQuotation GrainQuotation { get; private set; }
        
        public WheaterData Wheater { get; private set; }

        public AgroNewsItemViewModel AgroNewsItem { get; private set; }

        public string LastDollarUpdate { get; private set; }

        public string LastGrainsUpdate { get; private set; }

        public int Position { get; set; }

        // Commands
        public SandboxedCommand GoToMarketCommand { get; private set; }

        public SandboxedCommand LiniersQuoteSelectedCommand { get; private set; }

        public SandboxedCommand OpenDollarQuotesCommand { get; private set; }

        public SandboxedCommand OpenGrainQuotesCommand { get; private set; }

        public SandboxedCommand ShowWheaterCommand { get; private set; }

        public SandboxedCommand OpenChatbotCommand { get; private set; }

        public SandboxedCommand OpenNewsReportsCommand { get; private set; }

        public SandboxedCommand LogoutCommand { get; private set; }

        // Methods
        private async Task LiniersQuoteSelected()
        {
            if (SelectedLiniersQuote != null)
                await PopupNavigation.Instance.PushAsync(new LiniersQuotePopupPage(_linierItems));

            SelectedLiniersQuote = null;
        }

        private async Task GetWeatherForecast()
        {
            await CheckLocationPermission();

            var locationReq = new GeolocationRequest(GeolocationAccuracy.Best);

            var location = await Geolocation.GetLocationAsync(locationReq);

            var lat = location.Latitude.ToString().Replace(',', '.');
            var lon = location.Longitude.ToString().Replace(',', '.');

            Wheater = await _wheaterService.GetWheaterAsync(lat, lon);

            CurrentTemp = $"{Wheater.Main.Temp}º";

            _appSettings.CurrentTemp = Wheater.Main.Temp.ToString();
        }

        private async Task GetLinierQuotes()
        {
            _liniersQuotes = await _liniersService.GetCotizacionesLiniersAsync();

            foreach (var item in _liniersQuotes)
                _linierItems.Add(new LiniersItemViewModel(item));

            LiniersQuotes.AddRange(_liniersQuotes);
        }

        private async Task GetDollarQuotes()
        {
            _dollarQuotes = await _dollarService.GetDollarQuotesAsync();

            OfficialDollar = _dollarQuotes.FirstOrDefault();

            LastDollarUpdate = string.Format(Strings.OnXAtX, $"{OfficialDollar.Fecha:dd/MM/yyyy}", $"{OfficialDollar.Fecha:HH}");

            if (DeviceInfo.Platform == DevicePlatform.UWP)
            {
                DollarQuotes.AddRange(_dollarQuotes);

                DollarQuotes.RemoveAt(0);

                this.OnPropertyChanged(nameof(DollarQuotes));
            }
        }

        private async Task GetGrainQuotes()
        {
            var grainData = await _grainsService.GetGrainsQuotationAsync();

            foreach (var grain in grainData.Cereales)
                _grains.Add(new GrainsItemViewModel(grain));

            LastGrainsUpdate = $"Últ. actualización {grainData.PublicationDate}";

            GrainQuote = grainData.Cereales.FirstOrDefault();

            foreach (var grain in grainData.Cereales)
                GrainQuotes.Add(new GrainQuoteItemViewModel(grain, _grains));

            GrainQuotation = GrainQuote.Cotizacion.FirstOrDefault();
        }

        private async Task GetAgroNews()
        {
            if (!_newsUpdated)
            {
                if (DateTime.Today >= _appSettings.LastNewsUpdated)
                {
                    var news = await _agroNewsService.GetAgroNewsAsync();

                    if (news != null && news.Count > 0)
                        await _agroNewsRepository.PersistAgroNewsAsync(news);

                    if (DeviceInfo.Platform == DevicePlatform.UWP)
                    {
                        foreach (var report in news.Take(1))
                            AgroNewsItem = new AgroNewsItemViewModel(report);
                    }
                    else
                    {
                        foreach (var report in news.Take(3))
                            AgroNews.Add(new AgroNewsItemViewModel(report));
                    }

                    _appSettings.LastNewsUpdated = DateTime.Today;
                }
                else
                {
                    var news = await _agroNewsRepository.GetAgroNewsAsync();

                    if (news != null && news.Count > 0)
                    {
                        if (DeviceInfo.Platform == DevicePlatform.UWP)
                        {
                            foreach (var report in news.Take(1))
                                AgroNewsItem = new AgroNewsItemViewModel(report);
                        }
                        else
                        {
                            foreach (var report in news.Take(3))
                                AgroNews.Add(new AgroNewsItemViewModel(report));
                        }
                    }
                }

                _newsUpdated = true;
            }

            this.OnPropertyChanged(nameof(AgroNews));
        }

        private async Task Logout()
        {
            if (!await _dialogsHelper.ShowConfirmAsync("¿Esta seguro que desea salir?"))
                return;

            _dialogsHelper.ShowDialog();

            _appSettings.ClearSettings();

            await Task.Delay(500);

            _dialogsHelper.HideDialog();

            await Shell.Current.GoToAsync("main/login");
        }

        private async Task<bool> CheckLocationPermission()
        {
            var locationAlwaysStatus = await Permissions.CheckStatusAsync<Permissions.LocationAlways>();
            var locationWhenInUseStatus = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

            if (DeviceInfo.Platform == DevicePlatform.UWP)
            {
                if (locationAlwaysStatus != PermissionStatus.Granted || locationWhenInUseStatus != PermissionStatus.Granted)
                {
                    locationAlwaysStatus = await Permissions.RequestAsync<Permissions.LocationAlways>();
                    locationWhenInUseStatus = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
                }
            }

            return locationAlwaysStatus == PermissionStatus.Granted && locationWhenInUseStatus == PermissionStatus.Granted;
        }

        private async Task ShowWheater() => await PopupNavigation.Instance.PushAsync(new WeatherPopup(Wheater));

        private async Task OpenChatbot() => await Shell.Current.GoToAsync(nameof(InquiriesPage));

        private async Task GoToMarket() => await Shell.Current.GoToAsync("uwp_market", false);

        private async Task OpenNewsReports() => await Shell.Current.GoToAsync(nameof(NewsPortalPage), false);

        private async Task OpenDollarQuotes() => await PopupNavigation.Instance.PushAsync(new DollarQuotesPopupPage(_dollarQuotes));

        private async Task OpenGrainQuotes() => await PopupNavigation.Instance.PushAsync(new GrainsQuotesPopupPage(_grains));
    }
}