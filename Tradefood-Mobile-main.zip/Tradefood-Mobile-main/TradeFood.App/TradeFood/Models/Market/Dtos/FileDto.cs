﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market.Dtos
{
    public class FileDto
    {
        public string FilePath { get; set; }
    }
}
