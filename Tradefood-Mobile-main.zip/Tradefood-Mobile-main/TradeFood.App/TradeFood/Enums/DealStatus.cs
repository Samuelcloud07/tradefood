﻿namespace TradeFood.Enums
{
    public enum DealStatus
    {
        Vigente,
        Pausado,
        Pendiente
    }
}