﻿using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Providers;

namespace TradeFood.Services
{
    public class AuthenticationService : IAuthenticationService
    {
        private readonly IProviderFactory _providerFactory;

        public AuthenticationService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }

        public Task<LoginResponse> LoginAsync(SignIn signIn)
        {
            return _providerFactory.Create<IAuthenticationProvider>().LoginAsync(signIn);
        }

        public Task<RequestNewPasswordResponse> RequestPasswordResetAsync(string email)
        {
            return _providerFactory.Create<IAuthenticationProvider>().RequestPasswordResetAsync(email);
        }

        public Task ResetPasswordAsync(ResetUserPassword resetUserPassword)
        {
            return _providerFactory.Create<IAuthenticationProvider>().ResetPasswordAsync(resetUserPassword);
        }

        public Task<LoginResponse> SignUpAsync(SignUp signUp)
        {
            return _providerFactory.Create<IAuthenticationProvider>().SignUpAsync(signUp);
        }

        public Task<LoginResponse> ConfirmEmailAsync(EmailConfirmation emailConfirmation)
        {
            return _providerFactory.Create<IAuthenticationProvider>().ConfirmEmailAsync(emailConfirmation);
        }

        public Task ResendEmailConfirmationAsync(string email)
        {
            return _providerFactory.Create<IAuthenticationProvider>().ResendEmailConfirmationAsync(email);
        }
        public Task ChangePasswordAsync(ResetUserPassword resetUserPassword)
        {
            return _providerFactory.Create<IAuthenticationProvider>().ChangePasswordAsync(resetUserPassword);
        }
    }
}