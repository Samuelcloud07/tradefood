﻿using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Enums;
using TradeFood.Helpers;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views;
using TradeFood.Views.Popups;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    class ProfileDataViewModel : BaseViewModel
    {
        private readonly IProfileService _profileService;
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialoghelpers;

        public ProfileDataViewModel(ILogger logger,
                                    IAppSettings appSettings,
                                    IDialogsHelper dialogsHelper,
                                    IProfileService profileService) : base(logger)
        {
            _appSettings = appSettings;

            GoToAdressCommand = new SandboxedCommand(GoToAddres);

            GoToPersonalDataCommand = new SandboxedCommand(GoToPersonalData);

            GoToChoreUserOrSocietyAndNewPersonCommand = new SandboxedCommand(GoToChoreUserOrSocietyAndNewPerson);

            GotoMainProfileOptionsCommand = new SandboxedCommand(GotoMainProfileOptions);

            _appSettings = appSettings;
            _dialoghelpers = dialogsHelper;
            _profileService = profileService;
        }

        protected override async Task InitializeAsync()
        {
            _dialoghelpers.ShowDialog();

            await base.InitializeAsync();

            await RefreshSocietiesAndPersons();

            UserName = _appSettings.UserName;

            ClientType = _appSettings.ClientType;

            PhoneNumber = _appSettings.PhoneNumber;

            Email = _appSettings.UserEmail;

            Location = $"{_appSettings.Location}, {_appSettings.State}";

            UserId = _appSettings.UserId;

            ClientType = _appSettings.ClientType;

            _dialoghelpers.HideDialog();
        }

        public async Task RefreshSocietiesAndPersons()
        {
            //SocietiesAndPersons.Count == 0 &&
            if (!_appSettings.ClientType.Equals("Comisionista")
                && !_appSettings.ClientType.Equals("Productor_Persona"))   // && !_appSettings.ClientType.Equals("Consignataria"))
            {
                List<SocietiesAndPersonDto> societies = await _profileService.GetSocietiesAndPersonsAsync(long.Parse(_appSettings.UserId));
                SocietiesAndPersons.Clear();
                Matarife.Clear();

                foreach (var item in societies)
                {
                    if (item.Type != Enums.TypeSocieties.RazonMatarife)
                    {
                        SocietiesAndPersons.Add(new SocietyOrPersonItemViewModel
                        {
                            id = item.id,
                            ContactNumber = item.ContactNumber,
                            Addresses = addaddressSocietiItem(item.Addresses, item.Type),
                            Cuit = item.Cuit,
                            Email = item.Email,
                            CommercialReference = item.CommercialReference,
                            Name = item.Name,
                            Type = item.Type,
                            NotMatarife = true
                        });
                    }
                    else
                    {
                        Matarife.Add(new SocietyOrPersonItemViewModel
                        {
                            id = item.id,
                            Addresses = addaddressSocietiItem(item.Addresses, item.Type),
                            Cuit = item.Cuit,
                            Name = item.Name,
                            Type = item.Type
                        });
                    }

                }
                VisibleMatarife = false;

                System.Console.WriteLine(Matarife);
                System.Console.WriteLine(SocietiesAndPersons);
            }
            else
            {
                ShowInfo = true;
                List<SocietiesAndPersonDto> societies = await _profileService.GetSocietiesAndPersonsAsync(long.Parse(_appSettings.UserId));
                Matarife.Clear();

                foreach (var item in societies)
                {

                    Matarife.Add(new SocietyOrPersonItemViewModel
                    {
                        id = item.id,
                        ContactNumber = item.ContactNumber,
                        Addresses = addaddressSocietiItem(item.Addresses, item.Type),
                        Cuit = item.Cuit,
                        Email = item.Email,
                        CommercialReference = item.CommercialReference,
                        Name = item.Name,
                        Type = item.Type,
                    });
                }
                VisibleMatarife = false;
            }

            List<AddressDto> Listaddress = await _profileService.GetAllAddressesAsync((long)Convert.ToDouble(_appSettings.UserId));

            CommercialReferenceDto referenceDto = await _profileService.GetCommercialReferenceAsync((long)Convert.ToDouble(_appSettings.UserId));

            if (referenceDto != null)
            {
                CommercialItem.Clear();
                CommercialItem.Add(new CommercialReferenceItemViewModel(referenceDto.Name, referenceDto.Comments));
            }

            VisibleCommercialReference = referenceDto != null;
            VisibleAddCommercialReference = !VisibleCommercialReference;

            if (Listaddress != null) 
            {
                AddressProfile.Clear();
                foreach (var item in Listaddress)
                    AddressProfile.Add(new AddressItemViewModel(item.Id.ToString(), item.Street, item.Number.ToString(), item.Location, item.State, item.ZipCode, item.Observations));
            }

            this.OnPropertyChanged(nameof(SocietiesAndPersons));
        }

        public IList<AddressDto> addaddressSocietiItem(IList<AddressDto> list, TypeSocieties type)
        {
            IList<AddressDto> address = new List<AddressDto>();

            foreach (AddressDto item in list)
                address.Add(new AddressDto(item, type));

            return address;
        }

        //properties

        public ObservableCollection<SocietyOrPersonItemViewModel> SocietiesAndPersons { get; set; } = new ObservableCollection<SocietyOrPersonItemViewModel>();
        public ObservableCollection<AddressItemViewModel> AddressProfile { get; set; } = new ObservableCollection<AddressItemViewModel>();
        public ObservableCollection<CommercialReferenceItemViewModel> CommercialItem { get; set; } = new ObservableCollection<CommercialReferenceItemViewModel>();
        public ObservableCollection<SocietyOrPersonItemViewModel> Matarife { get; set; } = new ObservableCollection<SocietyOrPersonItemViewModel>();

        public bool VisibleMainProfileOptions { get => ClientType != "Productor_Persona" && ClientType != "Comisionista"; }
        public bool VisibleMatarife { get; set; } = true;
        public bool VisibleCommercialReference { get; set; } = true;
        public bool VisibleAddCommercialReference { get; set; } = true;
        public bool UsuarioFaena { get; set; } = false;
        public long IdsocietiesAndPerson { get; set; }

        public string PhoneNumber { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }

        public string ClientType { get; set; }

        public string UserId { get; set; }

        public string Location { get; set; }

        public bool ShowInfo { get; set; }

        public bool ShowFloatButton
        {
            get => IsSecondTabTapped
                && !_appSettings.ClientType.Equals("Frigorífico")
                && !_appSettings.ClientType.Equals("Productor_Empresa")
                && !_appSettings.ClientType.Equals("Consignataria")
                && Matarife.Count > 0;
        }

        public string Tag { get; } = "MI PERFIL";

        public bool DisplayAddAdress
        {
            get => ClientType == "Frigorífico";
        }

        public bool DisplayTabs
        {
            get
            {
                if (ClientType == "Frigorífico" || ClientType == "Comisionista" || ClientType == "Productor_Persona")
                    return true;
                else
                    return false;
            }
        }

        public string SecondTabName
        {
            get
            {
                if (ClientType == "Frigorífico")
                    return "Usuario de faena";
                else
                    return "Mis representaciones";
            }
        }

        public string IsDniOrCuit
        {
            get
            {
                if (ClientType == "Comisionista" || ClientType == "Productor_Persona")
                    return "DNI:";
                else
                    return "CUIT:";
            }
        }

        public string PersonalData
        {
            get
            {
                switch (ClientType)
                {
                    case "Frigorífico":
                        return "Datos de Frigorífico";

                    default: return "Datos personales";
                }
            }
        }

        public string AddresTypeText
        {
            get
            {
                if (ClientType == "Comisionista" || ClientType == "Productor_Persona")
                    return "Domicilio de la hacienda:";
                else
                    return "Domicilio de la razón social:";
            }
        }

        public string IsBusinessNameOrFarmAdressButton
        {
            get
            {
                if (ClientType == "Comisionista" || ClientType == "Productor_Persona")
                    return "Agregar domicilio de la hacienda +";
                else
                    return "Agregar domicilio de la razón social +";
            }
        }

        public bool DisplayFinancialData
        {
            get
            {
                if (ClientType == "Productor_Empresa" || ClientType == "Comisionista" || ClientType == "Consignataria")
                    return true;
                else
                    return false;
            }
        }

        private bool _isFirstTabTapped = true;

        public bool IsFirstTabTapped
        {
            get { return _isFirstTabTapped; }
            set
            {
                _isFirstTabTapped = value;
                this.OnPropertyChanged(nameof(IsFirstTabTapped));
            }
        }

        private bool _isSecondTabTapped = false;

        public bool IsSecondTabTapped
        {
            get { return _isSecondTabTapped; }
            set
            {
                _isSecondTabTapped = value;
                this.OnPropertyChanged(nameof(IsSecondTabTapped));
            }
        }

        //TEXTOS DEL SEGUNDO TAB

        public string FirstText
        {
            get
            {
                if (ClientType == "Productor_Persona" || ClientType == "Comisionista")
                    return "Completá los datos de las Sociedades y Pers. físicas con las que trabajás.";
                else
                    return "Completá los datos de tu usuario de faena.";
            }
        }

        public string SecondText
        {
            get
            {
                if (ClientType == "Productor_Persona" || ClientType == "Comisionista")
                    return "Agregá información sobre las Sociedades y las Pers. físicas con las que trabajás para que puedas comenzar a operar.";
                else
                    return "Agregá información sobre el Matarife con el que trabajás para que puedas comenzar a operar.";
            }
        }

        public string ButtonText
        {
            get
            {
                if (ClientType == "Productor_Persona" || ClientType == "Comisionista")
                    return "Agregar Sociedad o Pers física";
                else
                    return "Agregar usuario de faena";
            }
        }

        //Commands
        public SandboxedCommand GoToAdressCommand { get; private set; }
        public SandboxedCommand GoToPersonalDataCommand { get; private set; }
        public SandboxedCommand GoToChoreUserOrSocietyAndNewPersonCommand { get; private set; }
        public SandboxedCommand GotoMainProfileOptionsCommand { get; private set; }

        //Methods
        private async Task GoToAddres()
        {
            if (DeviceInfo.Platform != DevicePlatform.UWP)
                await Shell.Current.GoToAsync($"AddAdressPage?idsocietiespersons={IdsocietiesAndPerson}");
            else
                await PopupNavigation.Instance.PushAsync(new AddAdressPopupPage());
        }

        private async Task GoToPersonalData()
        {
            if (DeviceInfo.Platform != DevicePlatform.UWP)
                await Shell.Current.GoToAsync(nameof(PersonalDataPage));
            else
                await PopupNavigation.Instance.PushAsync(new AddReferencePopupPage());
        }

        private async Task GoToChoreUserOrSocietyAndNewPerson()
        {
            if (ClientType == "Frigorífico")
                await Shell.Current.GoToAsync(nameof(UserFaenaDataPage));
            else
                await Shell.Current.GoToAsync(nameof(AddNewPersonOrSocietyPage));
        }

        private async Task GotoMainProfileOptions()
        {
            await PopupNavigation.Instance.PushAsync(new SocietyOrPersonOptionsPopupPage(0, true));
        }

        public void deleteItem(long _id)
        {

            var item = SocietiesAndPersons.FirstOrDefault(a => a.id == _id);
            if (item != null)
            {
                SocietiesAndPersons.Remove(item);
                this.OnPropertyChanged(nameof(SocietiesAndPersons));
            }

            var itemMatarife = Matarife.FirstOrDefault(a => a.id == _id);
            if (itemMatarife != null)
            {
                Matarife.Remove(itemMatarife);
                this.OnPropertyChanged(nameof(Matarife));
            }
        }
    }
}