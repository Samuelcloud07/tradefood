﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Providers;

namespace TradeFood.Services
{
    public class LiniersService : ILiniersService
    {
        private readonly IProviderFactory _providerFactory;

        public LiniersService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }

        public Task<List<LiniersData>> GetCotizacionesLiniersAsync()
        {
            return _providerFactory.Create<ILiniersProvider>().GetCotizacionesLiniersAsync();
        }
    }
}