﻿using Android.Widget;
using System;
using TradeFood.Droid.Effects;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using Color = Android.Graphics.Color;

[assembly: ResolutionGroupName("TradeFood")]
[assembly: ExportEffect(typeof(RemoveEntryUnderlineEffect), nameof(RemoveEntryUnderlineEffect))]
namespace TradeFood.Droid.Effects
{
    public class RemoveEntryUnderlineEffect : PlatformEffect
    {
        protected override void OnAttached()
        {
            var editText = Control as EditText;

            if (editText is null)
                throw new NotImplementedException();

            editText.SetBackgroundColor(Color.Transparent);
        }

        protected override void OnDetached()
        {
        }
    }
}