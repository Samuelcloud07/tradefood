﻿using System;

namespace TradeFood.Models
{
    public class DealRequest
    {
        public string DealId { get; set; }

        public string DealStatus { get; set; }

        public string TroopCategory { get; set; }

        public string TroopType { get; set; }

        public string Amount { get; set; }

        public string Destination { get; set; }

        public string GeographicDestination { get; set; }

        public string WeightAmount { get; set; }

        public string Comments { get; set; }

        public string SuggestedPrice { get; set; }

        public string PaymentMethod { get; set; }

        public string FinancingCategory { get; set; }

        public string Province { get; set; }

        public string Location { get; set; }

        //public DateTime FromDate { get; set; }

        //public DateTime ToDate { get; set; }

        public string PersonInCharge { get; set; }
    }
}