﻿using Authentication.Models;
using Authentication.Models.Dtos;

namespace Authentication.Mappings
{
    public static class PlanetMappings
    {
        public static PlanetDto ToPlanetDto(this Planet planet)
        {
            return new PlanetDto
            {
                Name = planet.Name,
                RotationPeriod = planet.RotationPeriod,
                OrbitalPeriod = planet.OrbitalPeriod,
                Diameter = planet.Diameter,
                Climate = planet.Climate,
                Terrain = planet.Terrain,
                SurfaceWater = planet.SurfaceWater,
                Population = planet.Population
            };
        }
    }
}