﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Exceptions;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;

namespace TradeFood.Providers
{
    class ProfileLocalProvider : IProfileLocalProvider
    {
        public Task<string> TestAsync()
        {
            throw new NoInternetException();
        }

        public Task<CommercialReferenceDto> GetCommercialReferenceAsync(long userId)
        {
            throw new NoInternetException();
        }

        public Task<bool> AddCommercialReferenceAsync(string userId, CommercialReferenceDto commercialReference)
        {
            throw new NoInternetException();
        }

        public Task<bool> AddSocietiesAndPersonsAsync(long userId, SocietiesAndPersonDto societiesAndPerson)
        {
            throw new NoInternetException();
        }

        public Task<List<SocietiesAndPersonDto>> GetSocietiesAndPersonsAsync(long userId)
        {
            throw new NoInternetException();
        }

        public Task<bool> AddAddressSocietiesAsync(long userId, long societiesId, AddressDto address)
        {
            throw new NoInternetException();
        }

        public Task<bool> DeleteSocietiesAsync(long userId, long societiesId)
        {
            throw new NoInternetException();
        }

        public Task<bool> UpdateSocietiesAsync(long userId, SocietiesAndPersonDto societiesAndPersons)
        {
            throw new NoInternetException();
        }

        public Task<bool> UpdateAddressAsync(long userId, AddressDto address)
        {
            throw new NoInternetException();
        }

        public Task<List<AddressDto>> GetAddressesAsync(long userId)
        {
            throw new NoInternetException();
        }

        public Task<List<AddressDto>> GetAllAddressesAsync(long userId)
        {
            throw new NoInternetException();
        }

        public Task<bool> AddAddressAsync(AddressDto addressDto, long userId)
        {
            throw new NoInternetException();
        }

        public Task<ProfileStats> GetProfileStats()
        {
            throw new NoInternetException();
        }

        public Task<PreferencesDto> GetProfilePreferences(long userId)
        {
            throw new NoInternetException();
        }

        public Task<bool> AddProfilePreferences(long userId, PreferencesDto preferences)
        {
            throw new NoInternetException();
        }
    }
}