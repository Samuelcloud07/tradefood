﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market
{
    public class PreDealDetail
    {
        public SocietiesAndPerson SocietyOrPerson { get; set; }
        public Address TroopLocation { get; set; }
        public string Province { get; set; }
        public string Location { get; set; }
        public string SuggestedPrice { get; set; }
        public string PaymentTerms { get; set; }
        public string PaymentMethod { get; set; }
        public bool IsDirty { get; set; }
        public bool IsMioMio { get; set; }
        public bool IsTick { get; set; }
        public string Comments { get; set; }
        public string HeadOfPreBusiness { get; set; }

    }
}
