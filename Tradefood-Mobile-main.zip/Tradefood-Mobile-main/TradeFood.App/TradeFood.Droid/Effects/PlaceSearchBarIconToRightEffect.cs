﻿using Android.Views;
using Android.Widget;
using System;
using TradeFood.Droid.Effects;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportEffect(typeof(PlaceSearchBarIconToRightEffect), nameof(PlaceSearchBarIconToRightEffect))]
namespace TradeFood.Droid.Effects
{
    public class PlaceSearchBarIconToRightEffect : PlatformEffect
    {
        protected override void OnAttached()
        {
            var searchView = Control as SearchView;

            if (searchView is null)
                throw new NotImplementedException();

            // Obtener el Id del search icon
            int searchIconId = Android.Content.Res.Resources.System.GetIdentifier("android:id/search_mag_icon", null, null);
            ImageView searchViewIcon = (ImageView)searchView.FindViewById<ImageView>(searchIconId);
            ViewGroup linearLayoutSearchView = (ViewGroup)searchViewIcon.Parent;

            searchViewIcon.SetAdjustViewBounds(true);

            // Remover el search icon del view group
            linearLayoutSearchView.RemoveView(searchViewIcon);
            //linearLayoutSearchView.AddView(searchViewIcon);
        }

        protected override void OnDetached()
        {
        }
    }
}