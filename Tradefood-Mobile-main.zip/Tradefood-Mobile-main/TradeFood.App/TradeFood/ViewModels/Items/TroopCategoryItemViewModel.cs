﻿using System.ComponentModel;

namespace TradeFood.ViewModels.Items
{
    public class TroopCategoryItemViewModel : INotifyPropertyChanged
    {
        public TroopCategoryItemViewModel(string name, string gender)
        {
            Name = name;

            Gender = gender;
        }

        public string Name { get; private set; }

        public string Gender { get; private set; }

        public bool Selected { get; set; }

        public int AverageWeight { get; set; }


        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}