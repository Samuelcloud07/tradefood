﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeFood.Enums;

namespace TradeFood.Models.Market.Dtos
{
    public class DealApiDto
    {
        public string DealId { get; set; }
        public DealStatus DealStatus { get; set; }
        public string CreatedBy { get; set; }

        //tipo de prenegocio Invernada, Faena
        public string BusinessType { get; set; } 

        //Vaquillona, Ternero, etc, con peso por categoria
        public List<TroopCategory> TroopCategory { get; set; } 
        //Raza
        public List<Breed> BreedType { get; set; } 
        public int? Amount { get; set; } //Cantidad

        //Cantidad de machos
        public int? MaleAmount { get; set; } 

        //Cantidad de hembras
        public int? FemaleAmount { get; set; } 

        //Calidad va del 1 al 10
        public int? Quality { get; set; } 

        //Precio por kilo
        public int? SuggestedPrice { get; set; } 

        // Metodo de pago
        public string PaymentMethod { get; set; } 

        //Plazos de pago
        public string FinancingCategory { get; set; } 

        //Provincia
        public string Province { get; set; } 

        //Ciudad
        public string Location { get; set; } 
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }

        //Responsable 
        public string PersonInCharge { get; set; }   
        
        //Evidencias
        public List<FileDto> EvidenceFiles { get; set; } 

        //Relacionado con Evidencias
        public string DealThumbnails { get; set; } 

        //Comentarios
        public string Comments { get; set; } 

        //Desbaste
        public int? Roughing { get; set; } 

        //Ubicacion de la tropa
        public Address TroopLocation { get; set; } 
        public SocietiesAndPerson SocietiesAndPersons { get; set; }

        //Rango de peso
        public string WeightAmount { get; set; } 

        //tropa pareja o despareja
        public string TroopWeightType { get; set; }
        public int MinimumTip { get; set; }
        public double AverageWeightAmount { get; set; }
        public int MaximumTip { get; set; }
        public int Teeth { get; set; }

        //gorda, carnicera,etc (toros y vacas de faena)
        public string TroopSubCategory { get; set; }
        public NutritionalTreatment NutritionalTreatment { get; set; }

        //faena
        public string Destination { get;set; }

        ///faena
        public string SaleType { get; set; }
        public string Yield { get; set; }
        public string FitChina { get; set; }

        //estado de invernada
        public TroopStatus Status { get; set; }
        public bool IsdirtyArea { get; set; }
        public bool IsMioMio { get; set; }
        public bool IsTick { get; set; }

    }
}
