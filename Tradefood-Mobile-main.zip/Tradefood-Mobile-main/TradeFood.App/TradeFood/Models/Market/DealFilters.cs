﻿using TradeFood.Enums;

namespace TradeFood.Models
{
    public class DealFilters
    {
        public string TroopCategorySelected { get; set; }

        public string TroopTypeSelected { get; set; }

        public DealStatus DealStatusSelected { get; set; }

        public string MinPriceSelected { get; set; }

        public string MaxPriceSelected { get; set; }
    }
}