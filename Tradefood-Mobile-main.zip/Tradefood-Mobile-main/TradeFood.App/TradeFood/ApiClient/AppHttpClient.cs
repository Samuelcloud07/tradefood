﻿using TradeFood.SecureRepository;
using System;
using System.Net.Http;

namespace TradeFood.ApiClient
{
    public class AppHttpClient : IAppHttpClient
    {
        private const string BaseUrl = "https://api-tradefood-v1.azure-api.net";

        public AppHttpClient()
        {
            var secureStorageRepository = TypeLocator.Resolve<ISecureStorageRepository>();

            this.HttpClient = new HttpClient(new HttpLoggingHandler(new AuthenticatedHttpClientHandler(secureStorageRepository)))
            {
                BaseAddress = new Uri(BaseUrl),
                MaxResponseContentBufferSize = int.MaxValue
            };
        }

        public HttpClient HttpClient { get; }
    }
}