﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Models.Market.Dtos;

namespace TradeFood.Providers
{
    public interface IDealsProvider
    {
        Task<List<Deal>> GetAllDealsAsync();

        Task<string> BeginFileUploadAsync(string fileName);

        Task<bool> EndFileUploadAsync(string fileHandle, long fileSize, string dealId, bool isThumbnail);

        Task<Deal> CreateDealAsync(string userId, DealRequest deal);

        Task<bool> UploadChunkAsync(MediaChunk mediaChunk);

        Task<DealDto> CreateChoreDealAsync(string userId, DealDto deal);

        Task<DealDto> CreateWinteringDealAsync(string userId, DealDto deal);

        Task<List<DealApiDto>> GetDealsAsync();

        Task<DealsStats> GetDealsStats();
    }
}