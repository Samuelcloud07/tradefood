﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Profile.Dtos
{
    public class PaymentTermDto
    {
        public string BusinessType { get; set; }
        public string Name { get; set; }
        public bool Selected { get; set; }
        public int? MinPrice { get; set; }
        public int? MaxPrice { get; set; }
    }
}
