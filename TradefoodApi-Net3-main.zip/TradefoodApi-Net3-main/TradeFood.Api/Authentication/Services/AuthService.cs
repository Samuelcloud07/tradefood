﻿using Authentication.Models;
using Authentication.Models.Dtos;
using Authentication.Mappings;
using Common.Exceptions;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Authentication.Services
{
    public class AuthenticationService : IAuthenticationService
    {
        private readonly IConfiguration _config;

        public AuthenticationService(IConfiguration config)
        {
            _config = config;
        }

        private static HttpClient _client = new HttpClient
        {
            BaseAddress = new Uri("https://swapi.dev/api/"),
            MaxResponseContentBufferSize = int.MaxValue
        };

        public async Task<List<PlanetDto>> GetPlanetsAsync()
        {
            var planets = await GetPlanets();

            if (planets == null || planets.Count <= 0)
                throw new ServiceException("Lo sentimos, no pudimos contactar al api de Star Wars. Intente de nuevo en unos instantes.");

            return planets;
        }

        private async Task<List<PlanetDto>> GetPlanets()
        {
            PlanetsResponse planetsResponse = null;
            List<PlanetDto> planetsResult = new List<PlanetDto>();

            HttpResponseMessage response = await _client.GetAsync("planets");

            if (response.IsSuccessStatusCode)
                planetsResponse = await response.Content.ReadAsAsync<PlanetsResponse>();

            var results = planetsResponse.Results;

            foreach (var result in results)
                planetsResult.Add(result.ToPlanetDto());

            return planetsResult;
        }
    }
}