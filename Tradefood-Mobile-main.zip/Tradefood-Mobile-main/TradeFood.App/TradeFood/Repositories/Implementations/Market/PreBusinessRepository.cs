﻿using SQLite;
using SQLiteNetExtensions.Extensions;
using SQLiteNetExtensionsAsync.Extensions;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Repositories
{
    public class PreBusinessRepository : BaseSQLiteRepository<PreBusiness>, IPreBusinessRepository
    {
        private readonly ISQLiteAdapter _adapter;

        public PreBusinessRepository(ISQLiteAdapter adapter)
            : base(adapter)
        {
            _adapter = adapter;
        }

        public async Task<List<PreBusiness>> GetAllPreBusinessAsync()
        {
            var prebusiness = await _adapter.Connection.Table<PreBusiness>()
                                                .ToListAsync()
                                                .ConfigureAwait(false);

            foreach (var prebusines in prebusiness)
                await _adapter.Connection.GetChildrenAsync<PreBusiness>(prebusines, true).ConfigureAwait(false);

            return prebusiness;
        }

        public async Task<PreBusiness> PersistPreBusinesseAsync(PreBusiness preBusiness)
        {
            await _adapter.Connection.RunInTransactionAsync(
                (SQLiteConnection conn) =>
                {
                    conn.InsertWithChildren(preBusiness, true);
                }).ConfigureAwait(false);

            return preBusiness;
        }

        public async Task<List<PreBusiness>> PersistPreBusinessesAsync(IEnumerable<PreBusiness> preBusinesses)
        {
            await _adapter.Connection.RunInTransactionAsync(
                (SQLiteConnection conn) =>
                {
                    var preBusinessesAlreadySaved = conn.Query<PreBusiness>("SELECT * FROM PreBusiness");
                    var preBusinessToSave = preBusinesses.Where(pb => !preBusinessesAlreadySaved.Any(pbs => pbs.DealId == pb.DealId));

                    if (preBusinessToSave != null)
                        conn.InsertWithChildren(preBusinessToSave, true);
                }).ConfigureAwait(false);

            return new List<PreBusiness>(preBusinesses);
        }

        public async Task DeletePreBusinessAsync(PreBusiness preBusiness)
        {
            await _adapter.Connection.RunInTransactionAsync(
                (SQLiteConnection conn) =>
                {
                    conn.Delete(preBusiness);
                }).ConfigureAwait(false);
        }
    }
}