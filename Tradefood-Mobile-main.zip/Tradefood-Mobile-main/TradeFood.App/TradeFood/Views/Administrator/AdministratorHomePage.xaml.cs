﻿using Microcharts;
using SkiaSharp;
using System.Collections.Generic;
using System.ComponentModel;
using TradeFood.Helpers;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels;
using Xamarin.Forms;

namespace TradeFood.Views
{
    public partial class AdministratorHomePage : BasePage
    {
        private AdministratorHomeViewModel _vm;

        private List<ChartEntry> _entries = new List<ChartEntry>();

        public AdministratorHomePage()
        {
            InitializeComponent();

            _vm = new AdministratorHomeViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<ILiniersService>(),
                TypeLocator.Resolve<IDealsService>(),
                TypeLocator.Resolve<IDollarService>(),
                TypeLocator.Resolve<IGrainsService>(),
                TypeLocator.Resolve<IProfileService>(),
                TypeLocator.Resolve<IWheaterService>(),
                TypeLocator.Resolve<IAppSettings>(),
                TypeLocator.Resolve<IDialogsHelper>());

            this.BindingContext = _vm;

            var weather = new ToolbarItem
            {
                IconImageSource = "ic_weather",
                Priority = 1,
                Order = ToolbarItemOrder.Primary,
                Command = _vm.ShowWheaterCommand
            };

            this.ToolbarItems.Add(weather);

            this.donutChart.Chart = new DonutChart
            {
                LabelMode = LabelMode.RightOnly,
                LabelTextSize = 32,
                LabelColor = SKColor.Parse("#000000"),
                GraphPosition = GraphPosition.AutoFill,
                IsAnimated = false
            };
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            _vm.PropertyChanged += OnViewModel_PropertyChanged;
        }

        private void OnViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(_vm.ProfileStats))
            {
                if (_vm.ProfileStats != null)
                {
                    _entries = new List<ChartEntry>()
                    {
                        new ChartEntry(float.Parse(_vm.ProfileStats.Productor.ToString()))
                        {
                            ValueLabel = $"{_vm.ProfileStats.Productor} Usuarios Productores",
                            ValueLabelColor = SKColor.Parse("#AA6361"),
                            Color = SKColor.Parse("#AA6361")
                        },
                        new ChartEntry(float.Parse(_vm.ProfileStats.Comisionista.ToString()))
                        {
                            ValueLabel = $"{_vm.ProfileStats.Comisionista} Usuarios Comisionistas",
                            ValueLabelColor = SKColor.Parse("#CEACAA"),
                            Color = SKColor.Parse("#CEACAA")
                        },
                        new ChartEntry(float.Parse(_vm.ProfileStats.Consignataria.ToString()))
                        {
                            ValueLabel = $"{_vm.ProfileStats.Consignataria} Usuarios Consignatarias",
                            ValueLabelColor = SKColor.Parse("#C2C2C4"),
                            Color = SKColor.Parse("#C2C2C4")
                        },
                        new ChartEntry(float.Parse(_vm.ProfileStats.Frigorifico.ToString()))
                        {
                            ValueLabel = $"{_vm.ProfileStats.Frigorifico} Usuarios Frigoríficos",
                            ValueLabelColor = SKColor.Parse("#570301"),
                            Color = SKColor.Parse("#570301")
                        }
                    };
                }
            }

            if (e.PropertyName == nameof(_vm.ProducersPercentage))
            {
                if (_vm.ProducersPercentage != 0)
                    _entries[0].Label = $"{_vm.ProducersPercentage}% PRODUCTORES";
            }

            if (e.PropertyName == nameof(_vm.CommissionAgentsPercentage))
            {
                if (_vm.CommissionAgentsPercentage != 0)
                    _entries[1].Label = $"{_vm.CommissionAgentsPercentage}% COMISIONISTAS";
            }

            if (e.PropertyName == nameof(_vm.ConsigneesPercentage))
            {
                if (_vm.ConsigneesPercentage != 0)
                    _entries[2].Label = $"{_vm.ConsigneesPercentage}% CONSIGNATARIAS";
            }

            if (e.PropertyName == nameof(_vm.MeatIndustriesPercentage))
            {
                if (_vm.MeatIndustriesPercentage != 0)
                    _entries[3].Label = $"{_vm.MeatIndustriesPercentage}% FRIGORÍFICOS";

                this.donutChart.Chart.Entries = _entries;
            }
        }
    }
}