﻿using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using Xamarin.Forms;
using TradeFood.Models;
using TradeFood.Resources;
using System.Collections.Generic;
using System;
using TradeFood.Extensions;
using System.Linq;
using Newtonsoft.Json;

namespace TradeFood.ViewModels.Profile
{
    class ChangePasswordViewModel : BaseViewModel
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;
        public ChangePasswordViewModel(
                                ILogger logger,
                                IAuthenticationService authenticationService,
                                IAppSettings appSettings,
                                IDialogsHelper dialogsHelper) 
        : base(logger)
        {
            _authenticationService = authenticationService;
            _appSettings = appSettings;
            _dialogsHelper = dialogsHelper;

            RecoverPasswordCommand = new SandboxedCommand(RecoverPassword);
            CancelCommand = new SandboxedCommand(CancelPassword);
            ChangePasswordCommand = new SandboxedCommand(ChangePassword);
        }

        //Properties
        public string OldPassword { get; set; }
        public string NewOnePassword { get; set; }
        public string NewTwoPassword { get; set; }
        public bool AcceptRequest { get; set; }
        public bool HasErrors { get; set; }
        //Commands
        public SandboxedCommand RecoverPasswordCommand { get; private set; }
        public SandboxedCommand CancelCommand { get; private set; }
        public SandboxedCommand ChangePasswordCommand { get; private set; }
        //Diccionary
        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();
        //Methods
        private async Task RecoverPassword() => await Shell.Current.GoToAsync("ForgetPassword");
        private async Task ChangePassword()
        {
            if (!ValidateAll())
                return;

            if (!AcceptRequest)
            {
                _dialogsHelper.ShowAlert(Strings.YouMustAcceptTheTermsAndConditionsInOrderToContinue);

                return;
            }

            _dialogsHelper.ShowDialog();

            //Validacion de campos comletos y completos
            var ResetUserPassword = new ResetUserPassword
            {
                Email = _appSettings.UserEmail,
                Password = OldPassword,
                NewPassword = NewOnePassword
            };

            var response = _authenticationService.ChangePasswordAsync(ResetUserPassword);
            await response;
            
            _dialogsHelper.HideDialog();
            await Shell.Current.GoToAsync("..");
        }

        private bool ValidateAll()
        {
            Errors.Clear();

            // Colocar validaciones
            if (string.IsNullOrEmpty(OldPassword) || !OldPassword.IsValidPassword())
                Errors.Add(nameof(OldPassword), Strings.MustBeAtLeastEightAlphanumericCharactersAndSymbols);

            if (string.IsNullOrEmpty(NewOnePassword) || !NewOnePassword.IsValidPassword())
                Errors.Add(nameof(NewOnePassword), Strings.MustBeAtLeastEightAlphanumericCharactersAndSymbols);

            if (string.IsNullOrEmpty(NewTwoPassword) || !NewTwoPassword.IsValidPassword())
                Errors.Add(nameof(NewTwoPassword), Strings.MustBeAtLeastEightAlphanumericCharactersAndSymbols);

            if(NewOnePassword != NewTwoPassword)
            {
                Errors.Add(nameof(NewOnePassword), Strings.PasswordsDoesNotMatch);
                Errors.Add(nameof(NewTwoPassword), Strings.PasswordsDoesNotMatch);
            }

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }

        private async Task CancelPassword() => await Shell.Current.GoToAsync("..");
    }
}
