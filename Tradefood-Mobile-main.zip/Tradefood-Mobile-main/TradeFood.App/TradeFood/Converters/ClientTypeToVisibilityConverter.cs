﻿using System;
using System.Globalization;
using TradeFood.Enums;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class ClientTypeToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var clientType = (ClientType)value;

            switch (clientType)
            {
                case ClientType.Productor_Empresa:
                case ClientType.Comisionista:
                    return true;

                case ClientType.Consignataria:
                case ClientType.Frigorífico:
                case ClientType.Productor_Persona:
                    return false;

                default:
                    return false;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}