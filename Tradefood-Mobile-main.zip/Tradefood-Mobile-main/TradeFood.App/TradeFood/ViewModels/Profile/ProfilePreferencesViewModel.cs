﻿using Rg.Plugins.Popup.Services;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Enums;
using TradeFood.Extensions;
using TradeFood.Models;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Views.Popups;
using Xamarin.Essentials;

namespace TradeFood.ViewModels
{
    public class ProfilePreferencesViewModel : BaseViewModel
    {
        private readonly IStatesService _statesServices;

        public ProfilePreferencesViewModel(ILogger logger,
                                           IStatesService statesService)
            : base(logger)
        {
            _statesServices = statesService;

            SelectTroopTypeCommand = new SandboxedCommand(SelectTroopType);

            ContinueToStepTwoCommand = new SandboxedCommand(ContinueToStepTwo);

            ContinueToStepThreeCommand = new SandboxedCommand(ContinueToStepThree);

            DisplayProvincesCommand = new SandboxedCommand(DisplayProvinces);

            SavePreferencesCommand = new SandboxedCommand(SavePreferences);
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            var provinces = await _statesServices.GetProvincesAsync();

            var listProvinces = new List<ProvinceLocationItemViewModel>();

            foreach(ProvinceLocation province in provinces)
            {
                ProvinceLocationItemViewModel provinceLocationItem = new ProvinceLocationItemViewModel(new ProvinceLocation { Name = province.Name });

                listProvinces.Add(provinceLocationItem);
            }

            this.ProvincesSelected.AddRange(listProvinces);
        }

        // Properties
        public ObservableCollection<ProvinceLocationItemViewModel> ProvincesSelected { get; set; } = new ObservableCollection<ProvinceLocationItemViewModel>();

        public List<TroopType> TroopTypes { get; private set; } = new List<TroopType>();

        public List<TroopType> TroopTypes1 { get; private set; } = new List<TroopType>();

        public TroopType TroopTypeSelected { get; set; }

        public List<string> WeightAmount { get; private set; } = new List<string>();

        public string WeightAmountSelected { get; set; }

        public string TroopCategorySelected { get; set; }

        public string Amount { get; set; }

        public string FinancingCategorySelected { get; set; }

        public string PaymentMethodSelected { get; set; }

        public string SuggestedPrice { get; set; }

        public bool FirstSectionExpanded { get; set; }

        public bool FirstSectionCompleted { get; set; }

        public bool SecondSectionEnabled { get; set; }

        public bool SecondSectionExpanded { get; set; }

        public bool SecondSectionCompleted { get; set; }

        public bool ThirdSectionEnabled { get; set; }

        public bool ThirdSectionExpanded { get; set; }

        public bool ThirdSectionCompleted { get; set; }

        public bool InvernadaSelected { get; set; } = false;

        public bool FaenaSelected { get; set; } = false;

        public bool CashSelected { get; set; }

        public bool SevenDaysSelected { get; set; }
        
        public bool TenDaysSelected { get; set; }
        
        public bool FifteenDaysSelected { get; set; }
        
        public bool ThirtyDaysSelected { get; set; }
        
        public bool ThirtyAndSixtyDaysSelected { get; set; }
        
        public bool OtherSelected { get; set; }

        public List<string> PaymentTerms { get; set; } = new List<string>();

        public string Target { get; set; }

        //Commands
        public SandboxedCommand SelectTroopTypeCommand { get; private set; }

        public SandboxedCommand ContinueToStepTwoCommand { get; private set; }

        public SandboxedCommand ContinueToStepThreeCommand { get; private set; }

        public SandboxedCommand PublishBusinessCommand { get; private set; }

        public SandboxedCommand CancelPublishCommand { get; private set; }

        public SandboxedCommand TestCommand { get; private set; }

        public SandboxedCommand SelectProvinceCommand { get; private set; }

        public SandboxedCommand DisplayProvincesCommand { get; private set; }

        public SandboxedCommand SavePreferencesCommand { get; private set; }

        //Methods 
        public void SelectCategory(int number)
        {
            List<TroopType> troopType = null;

            switch (TroopCategorySelected)
            {
                case "Invernada":
                    troopType = new List<TroopType>
                    {
                        TroopType.Terneros,
                        TroopType.Terneras,
                        TroopType.Terneros_as,
                        TroopType.Vacas,
                        TroopType.Novillitos,
                        TroopType.Vaquillonas
                    };

                    break;
                case "Cria":
                    troopType = new List<TroopType>
                    {
                        TroopType.Vaquillonas_Preñadas,
                        TroopType.Vacas_Preñadas,
                        TroopType.Vaquillonas_para_entorar,
                        TroopType.Vacas_para_entorar,
                    };

                    break;
                case "Faena":
                    troopType = new List<TroopType>
                    {
                        TroopType.Novillo,
                        TroopType.Novillito,
                        TroopType.Vaquillona,
                        TroopType.Vacas,
                        TroopType.Toro
                    };

                    break;
            }

            if (number == 0)
                this.TroopTypes = troopType;
            else
                this.TroopTypes1 = troopType;

        }

        private async Task SelectTroopType()
        {
            await MainThread.InvokeOnMainThreadAsync(() =>
            {
                switch (TroopTypeSelected)
                {
                    case TroopType.Terneros:
                        WeightAmount = new List<string>
                        {
                            "100kg -120kg",
                            "120kg-140kg",
                            "140kg-160kg",
                            "160kg-180kg",
                            "180kg-200kg",
                            "200kg-220kg",
                            "220kg-240kg",
                            "240kg-260kg"
                        };

                        break;
                    case TroopType.Terneras:
                        WeightAmount = new List<string>
                        {
                            "100kg -120kg",
                            "120kg-140kg",
                            "140kg-160kg",
                            "160kg-180kg",
                            "180kg-200kg",
                            "200kg-220kg",
                            "220kg-240kg",
                            "240kg-260kg"
                        };

                        break;
                    case TroopType.Terneros_as:
                        WeightAmount = new List<string>
                        {
                            "100kg -120kg",
                            "120kg-140kg",
                            "140kg-160kg",
                            "160kg-180kg",
                            "180kg-200kg",
                            "200kg-220kg",
                            "220kg-240kg",
                            "240kg-260kg"
                        };

                        break;
                    case TroopType.Vacas:
                        WeightAmount = new List<string>
                        {
                            ">300kg",
                            "300kg-340kg",
                            "340kg-360kg",
                            "360kg-380kg",
                            "380kg-400kg",
                            "<400kg"
                        };

                        break;

                    case TroopType.Novillitos:
                        WeightAmount = new List<string>
                        {
                            ">280kg",
                            "280kg-300kg",
                            "300kg-320kg",
                            "320kg-340kg",
                            ">340kg"
                        };

                        break;
                    case TroopType.Vaquillonas:
                        WeightAmount = new List<string>
                        {
                            ">280kg",
                            "280kg-300kg",
                            "300kg-320kg",
                            "320kg-340kg",
                            ">340kg"
                        };

                        break;
                }

                this.OnPropertyChanged(nameof(WeightAmount));
            });
        }

        private Task ContinueToStepTwo()
        {
            FirstSectionCompleted = true;
            FirstSectionExpanded = false;

            SecondSectionEnabled = true;
            SecondSectionExpanded = true;

            return Task.CompletedTask;
        }

        private Task ContinueToStepThree()
        {
            SecondSectionCompleted = true;
            SecondSectionExpanded = false;

            ThirdSectionEnabled = true;
            ThirdSectionExpanded = true;

            return Task.CompletedTask;
        }

        private Task SavePreferences()
        {
            ThirdSectionCompleted = true;
            ThirdSectionExpanded = false;

            return Task.CompletedTask;
        }

        public async Task DisplayProvinces() => await PopupNavigation.Instance.PushAsync(new LookForProvincesPopupPage(ProvincesSelected,this));
    }
}