﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    class BodyStateToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string bodyState = (string)value;
            string color = "";

            switch(bodyState){

                case "Bueno":
                case "Muy Bueno":
                    color = "#00724d";
                    break;
                case "Regular":
                    color = "#97691e";
                    break;
                case "Flacos":
                    color = "#a10b07";
                    break;
            }

            return color;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
