﻿using System;
using TradeFood.UWP.Effects;
using Xamarin.Forms;
using Xamarin.Forms.Platform.UWP;

[assembly: ExportEffect(typeof(PickerHighlightEffect), nameof(PickerHighlightEffect))]
namespace TradeFood.UWP.Effects
{
    public class PickerHighlightEffect : PlatformEffect
    {
        protected override void OnAttached()
        {
            var comboBox = this.Control as FormsComboBox;

            if (comboBox is null)
                throw new NotImplementedException();

            comboBox.Style = (Windows.UI.Xaml.Style)App.Current.Resources["comboBoxStyle"];
        }

        protected override void OnDetached()
        {
        }
    }
}