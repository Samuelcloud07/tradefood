﻿using Acr.UserDialogs;
using Plugin.Media.Abstractions;
using Refit;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Enums;
using TradeFood.Extensions;
using TradeFood.Handlers;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Repositories;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels.Base;
using TradeFood.Views.Popups;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class NewPublishViewModel : BaseViewModel
    {
        private readonly IDealsService _dealsService;
        private readonly IStatesService _statesService;
        private readonly IMediaHelper _mediaHelper;
        private readonly IDialogsHelper _dialogsHelper;
        private readonly IAppSettings _appSettings;
        private readonly IUserDialogs _userDialogs;

        private string _dealId = string.Empty;

        private List<ProvinceLocation> _locations = new List<ProvinceLocation>();

        private Interaction _forceExpanderUpdateInteraction = new Interaction();

        public NewPublishViewModel(ILogger logger,
                                   IDealsService dealsService,
                                   IStatesService statesService,
                                   IMediaHelper mediaHelper,
                                   IDialogsHelper dialogsHelper,
                                   IAppSettings appSettings,
                                   IUserDialogs userDialogs)
            : base(logger)
        {
            _dealsService = dealsService;
            _statesService = statesService;
            _mediaHelper = mediaHelper;
            _dialogsHelper = dialogsHelper;
            _appSettings = appSettings;
            _userDialogs = userDialogs;

            SelectTroopTypeCommand = new SandboxedCommand(SelectTroopType);

            UploadFirstEvidenceCommand = new SandboxedCommand(UploadFirstEvidence);

            UploadSecondEvidenceCommand = new SandboxedCommand(UploadSecondEvidence);

            UploadThirdEvidenceCommand = new SandboxedCommand(UploadThirdEvidence);

            RecordFirstEvidenceVideoCommand = new SandboxedCommand(RecordFirstEvidenceVideo);

            ContinueToStepTwoCommand = new SandboxedCommand(ContinueToStepTwo);

            ContinueToStepThreeCommand = new SandboxedCommand(ContinueToStepThree);

            PublishBusinessCommand = new SandboxedCommand(PublishBusiness);

            CancelPublishCommand = new SandboxedCommand(CancelPublish);

            //ShowInstructionsCommand = new SandboxedCommand(ShowInstructions);

            SelectProvinceCommand = new SandboxedCommand(SelectProvince);

            PickLocationCommand = new SandboxedCommand(PickLocation);

            DisplayName = _appSettings.UserName;
        }

        protected override async Task InitializeAsync()
        {
            await base.InitializeAsync();

            var provinces = await _statesService.GetProvincesAsync();

            Provinces.AddRange(provinces);

            DefaultProvinceSelected = 0;
        }

        // Properties
        public ObservableCollection<ProvinceLocation> Provinces { get; private set; } = new ObservableCollection<ProvinceLocation>();

        public ProvinceLocation ProvinceSelected { get; set; }

        public ProvinceLocation LocationSelected { get; set; }

        public int DefaultProvinceSelected { get; set; } = 0;

        public List<string> TroopTypes { get; private set; } = new List<string>();

        public string TroopTypeSelected { get; set; }

        public List<string> WeightAmount { get; private set; } = new List<string>();

        public string WeightAmountSelected { get; set; }

        public List<string> GeographicDestinations { get; private set; } = new List<string>();

        public string GeographicDestinationSelected { get; set; }

        public List<string> FinancingCategories { get; private set; } = new List<string>();

        private string _financingCategorySelected;
        public string FinancingCategorySelected
        {
            get => _financingCategorySelected;
            set
            {
                _financingCategorySelected = value;

                this.OnPropertyChanged(nameof(FinancingCategorySelected));


                if (_financingCategorySelected == "Otros")
                {
                    OtherFinancingCategorySelected = true;
                }
                else
                {
                    OtherFinancingCategorySelected = false;
                    FirstAnotherTerm = string.Empty;
                    SecondAnotherTerm = string.Empty;
                }


                _forceExpanderUpdateInteraction.Raise();

                this.OnPropertyChanged(nameof(OtherFinancingCategorySelected));
            }
        }

        private string _troopCategorySelected;
        public string TroopCategorySelected
        {
            get => _troopCategorySelected;
            set
            {
                _troopCategorySelected = value;

                this.OnPropertyChanged(nameof(TroopCategorySelected));

                switch (TroopCategorySelected)
                {
                    case ("Cria"):
                        CleanFields();
                        TroopTypes = new List<string>
                        {
                            "Vaquillonas Preñadas",
                            "Vacas Preñadas",
                            "Vaquillonas para entorar",
                            "Vacas para entorar",
                        };
                        ChoreSelected = false;
                        break;

                    case ("Invernada"):
                        CleanFields();
                        TroopTypes = new List<string>
                        {
                            "Terneros",
                            "Terneras",
                            "Terneros/as",
                            "Vacas",
                            "Novillitos",
                            "Vaquillonas"
                        };

                        FinancingCategories = new List<string>
                        {
                            "Contado",
                            "30 - 60 días",
                            "0 - 30 - 60 días",
                            "30 días",
                            "45 días",
                            "30 - 60 - 90 días",
                            "Otros"
                        };
                        ChoreSelected = false;
                        break;

                    case ("Faena"):
                        CleanFields();
                        TroopTypes = new List<string>
                        {
                            "Novillo",
                            "Novillito",
                            "Vaquillona",
                            "Vacas",
                            "Toro"
                        };

                        FinancingCategories = new List<string>
                        {
                            "Contado",
                            "7 días",
                            "15 días",
                            "21 días",
                            "30 días"
                        };

                        ChoreSelected = true;
                        break;
                }

                CategorySelected = true;
                this.OnPropertyChanged(nameof(CategorySelected));
                this.OnPropertyChanged(nameof(TroopTypes));
                this.OnPropertyChanged(nameof(ChoreSelected));
                this.OnPropertyChanged(nameof(FinancingCategories));
                _forceExpanderUpdateInteraction.Raise();
            }
        }

        private string _destinationSelected;
        public string DestinationSelected
        {
            get => _destinationSelected;
            set
            {
                _destinationSelected = value;

                this.OnPropertyChanged(nameof(DestinationSelected));

                switch (DestinationSelected)
                {
                    case ("Exportación"):
                        ExportationVisible = true;

                        this.OnPropertyChanged(nameof(ExportationVisible));
                        break;

                    case ("Consumo"):
                        break;
                }

                _forceExpanderUpdateInteraction.Raise();
            }
        }

        public void CleanFields()
        {
            Amount = string.Empty;
            WeightAmountSelected = string.Empty;
        }

        public string Amount { get; set; }

        public string FirstEvidencePath { get; set; }

        public string SecondEvidencePath { get; set; }

        public string ThirdEvidencePath { get; set; }

        public string FirstVideoEvidencePath { get; set; }

        public string SecondVideoEvidencePath { get; set; }

        public string ThirdVideoEvidencePath { get; set; }

        public string PaymentMethodSelected { get; set; }

        public string SuggestedPrice { get; set; }

        public string Comments { get; set; }

        public string FirstAnotherTerm { get; set; }

        public string SecondAnotherTerm { get; set; }

        public string DisplayName { get; private set; }

        public string LocationTitle { get; set; }

        public bool ChoreSelected { get; private set; }

        public bool ExportationVisible { get; private set; }

        public bool FirstSectionExpanded { get; set; }

        public bool FirstSectionCompleted { get; set; }

        public bool SecondSectionEnabled { get; private set; }

        public bool SecondSectionExpanded { get; private set; }

        public bool SecondSectionCompleted { get; set; }

        public bool ThirdSectionEnabled { get; private set; }

        public bool ThirdSectionExpanded { get; private set; }

        public bool CategorySelected { get; set; }

        public bool OtherFinancingCategorySelected { get; private set; }

        public bool LocationVisible { get; private set; }

        public bool SectionOneHasErrors { get; private set; }

        public bool SectionTwoHasErrors { get; private set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public IInteraction ForceExpanderUpdateInteraction => _forceExpanderUpdateInteraction;

        public Dictionary<string, string> SectionOneErrors { get; private set; } = new Dictionary<string, string>();

        public Dictionary<string, string> SectionTwoErrors { get; private set; } = new Dictionary<string, string>();

        // Commands
        public SandboxedCommand SelectTroopTypeCommand { get; private set; }

        public SandboxedCommand UploadFirstEvidenceCommand { get; private set; }

        public SandboxedCommand UploadSecondEvidenceCommand { get; private set; }

        public SandboxedCommand UploadThirdEvidenceCommand { get; private set; }

        public SandboxedCommand RecordFirstEvidenceVideoCommand { get; private set; }

        public SandboxedCommand ContinueToStepTwoCommand { get; private set; }

        public SandboxedCommand ContinueToStepThreeCommand { get; private set; }

        public SandboxedCommand PublishBusinessCommand { get; private set; }

        public SandboxedCommand CancelPublishCommand { get; private set; }

        public SandboxedCommand ShowInstructionsCommand { get; private set; }

        public SandboxedCommand SelectProvinceCommand { get; private set; }

        public SandboxedCommand PickLocationCommand { get; private set; }

        // Methods
        private async Task SelectTroopType()
        {
            await MainThread.InvokeOnMainThreadAsync(() =>
            {
                switch (TroopTypeSelected)
                {
                    case ("Terneros"):
                        WeightAmount = new List<string>
                        {
                            "100kg -120kg",
                            "120kg-140kg",
                            "140kg-160kg",
                            "160kg-180kg",
                            "180kg-200kg",
                            "200kg-220kg",
                            "220kg-240kg",
                            "240kg-260kg"
                        };
                        break;

                    case ("Terneras"):
                        WeightAmount = new List<string>
                        {
                            "100kg -120kg",
                            "120kg-140kg",
                            "140kg-160kg",
                            "160kg-180kg",
                            "180kg-200kg",
                            "200kg-220kg",
                            "220kg-240kg",
                            "240kg-260kg"
                        };
                        break;

                    case ("Terneros/as"):
                        WeightAmount = new List<string>
                        {
                            "100kg -120kg",
                            "120kg-140kg",
                            "140kg-160kg",
                            "160kg-180kg",
                            "180kg-200kg",
                            "200kg-220kg",
                            "220kg-240kg",
                            "240kg-260kg"
                        };
                        break;

                    case ("Vacas"):
                        WeightAmount = new List<string>
                        {
                            ">300kg",
                            "300kg-340kg",
                            "340kg-360kg",
                            "360kg-380kg",
                            "380kg-400kg",
                            "<400kg"
                        };

                        GeographicDestinations = new List<string>
                        {
                            "Gorda",
                            "Carnicera",
                            " Manufactura",
                            "Conserva"
                        };
                        break;

                    case ("Novillitos"):
                        WeightAmount = new List<string>
                        {
                            ">280kg",
                            "280kg-300kg",
                            "300kg-320kg",
                            "320kg-340kg",
                            ">340kg"
                        };
                        break;

                    case ("Vaquillonas"):
                        WeightAmount = new List<string>
                        {
                            ">280kg",
                            "280kg-300kg",
                            "300kg-320kg",
                            "320kg-340kg",
                            ">340kg"
                        };
                        break;

                    case ("Novillo"):
                        WeightAmount = new List<string>
                        {
                            "460kg-480kg",
                            "480kg-500kg",
                            "500kg-520kg",
                            "520kg-540kg",
                            "540kg-560kg",
                            ">560kg"
                        };

                        GeographicDestinations = new List<string>
                        {
                            "Hilton UE",
                            "UE no Hilton",
                            "Terceros paises",
                            "Cuota 481"
                        };
                        break;

                    case ("Novillito"):
                        WeightAmount = new List<string>
                        {
                            "<350kg",
                            "350kg-370kg",
                            "370kg-390kg",
                            "390kg-410kg",
                            "410kg-430kg",
                            "430kg-450kg",
                            "450kg-460kg",
                            ">460kg"
                        };

                        GeographicDestinations = new List<string>
                        {
                            "China",
                            "Terceros paises"
                        };
                        break;

                    case ("Vaquillona"):
                        WeightAmount = new List<string>
                        {
                            "460kg-480kg",
                            "480kg-500kg",
                            ">560kg"
                        };

                        GeographicDestinations = new List<string>
                        {
                            "Hilton UE",
                            "UE no Hilton",
                            "Terceros paises",
                            "Cuota 481"
                        };
                        break;

                    case ("Toro"):
                        WeightAmount = new List<string>
                        {
                            "Gorda",
                            "Carnicera",
                            " Manufactura",
                            "Conserva"
                        };

                        GeographicDestinations = new List<string>
                        {
                            "Gorda",
                            "Carnicera",
                            " Manufactura",
                            "Conserva"
                        };
                        break;

                }

                this.OnPropertyChanged(nameof(WeightAmount));
                this.OnPropertyChanged(nameof(GeographicDestinations));
            });
        }

        private async Task UploadFirstEvidence()
        {
            var result = await _userDialogs.ActionSheetAsync("Elija cómo cargar la evidencia", "Cancelar", null, null, "Desde Cámara", "Foto desde Galería", "Grabar Video", "Video desde Galería");

            switch (result)
            {
                case "Desde Cámara":
                    var cameraFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Camera,
                        $"EvidenciaTropa1_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (cameraFile == null)
                        return;

                    FirstEvidencePath = cameraFile.Path;
                    break;

                case "Foto desde Galería":
                    var galleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Gallery,
                        $"EvidenciaTropa1_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (galleryFile == null)
                        return;

                    FirstEvidencePath = galleryFile.Path;
                    break;

                case "Grabar Video":
                    //await PopupNavigation.Instance.PushAsync(new EvidenceInstructionsPopupPage(this, true));
                    break;

                case "Video desde Galería":
                    var videoGalleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.VideoGallery,
                        string.Empty,
                        CameraDevice.Front);

                    FirstVideoEvidencePath = videoGalleryFile.Path;
                    break;
            }
        }

        private async Task UploadSecondEvidence()
        {
            var result = await _userDialogs.ActionSheetAsync("Elija cómo cargar la evidencia", "Cancelar", null, null, "Desde Cámara", "Foto desde Galería", "Grabar Video", "Video desde Galería");

            switch (result)
            {
                case "Desde Cámara":
                    var cameraFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Camera,
                        $"EvidenciaTropa2_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (cameraFile == null)
                        return;

                    SecondEvidencePath = cameraFile.Path;
                    break;

                case "Foto desde Galería":
                    var galleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Gallery,
                        $"EvidenciaTropa2_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (galleryFile == null)
                        return;

                    SecondEvidencePath = galleryFile.Path;
                    break;

                case "Grabar Video":
                    var videoFile = await _mediaHelper.RecordVideoAsync(
                        $"EvidenciaTropa2Video_{DateTime.Now:dd/MM/yyyy-hhmmss}", TimeSpan.FromSeconds(40));

                    if (videoFile == null)
                        return;

                    SecondVideoEvidencePath = videoFile.Path;
                    break;

                case "Video desde Galería":
                    var videoGalleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.VideoGallery,
                        string.Empty,
                        CameraDevice.Front);

                    SecondVideoEvidencePath = videoGalleryFile.Path;
                    break;
            }
        }

        private async Task UploadThirdEvidence()
        {
            var result = await _userDialogs.ActionSheetAsync("Elija cómo cargar la evidencia", "Cancelar", null, null, "Desde Cámara", "Foto desde Galería", "Grabar Video", "Video desde Galería");

            switch (result)
            {
                case "Desde Cámara":
                    var cameraFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Camera,
                        $"EvidenciaTropa3_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (cameraFile == null)
                        return;

                    ThirdEvidencePath = cameraFile.Path;
                    break;

                case "Foto desde Galería":
                    var galleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.Gallery,
                        $"EvidenciaTropa3_{DateTime.Now:dd/MM/yyyy-hhmmss}",
                        CameraDevice.Rear);

                    if (galleryFile == null)
                        return;

                    ThirdEvidencePath = galleryFile.Path;
                    break;

                case "Grabar Video":
                    var videoFile = await _mediaHelper.RecordVideoAsync(
                        $"EvidenciaTropa3Video_{DateTime.Now:dd/MM/yyyy-hhmmss}", TimeSpan.FromSeconds(40));

                    if (videoFile == null)
                        return;

                    ThirdVideoEvidencePath = videoFile.Path;
                    break;

                case "Video desde Galería":
                    var videoGalleryFile = await _mediaHelper.LoadImageFromSourceAsync(
                        Enums.ImageSource.VideoGallery,
                        string.Empty,
                        CameraDevice.Front);

                    ThirdVideoEvidencePath = videoGalleryFile.Path;
                    break;
            }
        }

        private async Task RecordFirstEvidenceVideo()
        {
            var videoFile = await _mediaHelper.RecordVideoAsync(
                        $"EvidenciaTropa1Video_{DateTime.Now:dd/MM/yyyy-hhmmss}", TimeSpan.FromSeconds(40));

            if (videoFile == null)
                return;

            FirstVideoEvidencePath = videoFile.Path;
        }

        private async Task PublishBusiness()
        {
            _dialogsHelper.ShowDialog("Aguarde un instante por favor, estamos creando su prenegocio...");

            _dealId = Guid.NewGuid().ToString().Split('-').Last();

            var newDeal = new DealRequest
            {
                DealId = _dealId,
                DealStatus = DealStatus.Vigente.ToString(),
                TroopCategory = TroopCategorySelected,
                TroopType = TroopTypeSelected,
                Amount = Amount,
                Destination = !string.IsNullOrEmpty(DestinationSelected) ? DestinationSelected : string.Empty,
                GeographicDestination = !string.IsNullOrEmpty(GeographicDestinationSelected) ? GeographicDestinationSelected : string.Empty,
                WeightAmount = WeightAmountSelected,
                Comments = Comments,
                SuggestedPrice = SuggestedPrice,
                PaymentMethod = PaymentMethodSelected,
                FinancingCategory = !OtherFinancingCategorySelected ? FinancingCategorySelected : $"{FirstAnotherTerm} - {SecondAnotherTerm}",
                Province = ProvinceSelected.Name,
                Location = LocationSelected.Name,
                PersonInCharge = _appSettings.UserName
            };

            await _dealsService.CreateDealAsync(_appSettings.UserId, newDeal);

            var videoTranscoderHandler = DependencyService.Get<IVideoTranscoderHandler>();

            string firstVideoEvidencePath = string.Empty;
            string secondVideoEvidencePath = string.Empty;
            string thirdVideoEvidencePath = string.Empty;

            string videoThumbnailPath = string.Empty;

            if (!string.IsNullOrEmpty(FirstVideoEvidencePath))
            {
                firstVideoEvidencePath = await videoTranscoderHandler.TranscodeVideoAsync(FirstVideoEvidencePath);

                videoThumbnailPath = await videoTranscoderHandler.GenerateThumbnail(firstVideoEvidencePath);
            }

            if (!string.IsNullOrEmpty(SecondVideoEvidencePath))
            {
                secondVideoEvidencePath = await videoTranscoderHandler.TranscodeVideoAsync(SecondVideoEvidencePath);

                if (string.IsNullOrEmpty(videoThumbnailPath))
                    videoThumbnailPath = await videoTranscoderHandler.GenerateThumbnail(secondVideoEvidencePath);
            }

            if (!string.IsNullOrEmpty(ThirdVideoEvidencePath))
            {
                thirdVideoEvidencePath = await videoTranscoderHandler.TranscodeVideoAsync(ThirdVideoEvidencePath);

                if (string.IsNullOrEmpty(videoThumbnailPath))
                    videoThumbnailPath = await videoTranscoderHandler.GenerateThumbnail(thirdVideoEvidencePath);
            }

            await UploadFiles(!string.IsNullOrEmpty(FirstEvidencePath) ? FirstEvidencePath : firstVideoEvidencePath);

            await UploadFiles(!string.IsNullOrEmpty(SecondEvidencePath) ? SecondEvidencePath : secondVideoEvidencePath);

            await UploadFiles(!string.IsNullOrEmpty(ThirdEvidencePath) ? ThirdEvidencePath : thirdVideoEvidencePath);

            await UploadFiles(videoThumbnailPath, true);

            if (System.IO.File.Exists(firstVideoEvidencePath))
                System.IO.File.Delete(firstVideoEvidencePath);

            if (System.IO.File.Exists(secondVideoEvidencePath))
                System.IO.File.Delete(secondVideoEvidencePath);

            if (System.IO.File.Exists(thirdVideoEvidencePath))
                System.IO.File.Delete(thirdVideoEvidencePath);

            if (System.IO.File.Exists(videoThumbnailPath))
                System.IO.File.Delete(videoThumbnailPath);

            _dialogsHelper.HideDialog();

            await Shell.Current.GoToAsync("..");
        }

        private async Task UploadFiles(string filePath, bool isThumbnail = false)
        {
            if (string.IsNullOrEmpty(filePath))
                return;

            var fileName = filePath.Split('/').Last();

            var fileHandle = await _dealsService.BeginFileUploadAsync(fileName);

            var fileStream = System.IO.File.OpenRead(filePath);

            try
            {
                // Enviar archivo en pedazos de 512 KB a la vez
                int maxChunkSize = (512 * 1024);
                var buffer = new byte[maxChunkSize];
                long fileSize = 0;
                long totalBytesRead = 0;

                var bytesRead = 0;
                fileSize = fileStream.Length;

                do
                {
                    var position = fileStream.Position;
                    bytesRead = await fileStream.ReadAsync(buffer, 0, buffer.Length);

                    // Si los bytes leídos son más pequeños que el búfer, se enviará el último trozo.
                    // Reduce el buffer para que quepan los últimos bytes para optimizar el uso de la memoria.
                    if (bytesRead < buffer.Length)
                        Array.Resize(ref buffer, bytesRead);

                    var base64Data = Convert.ToBase64String(buffer);

                    var chunk = new MediaChunk
                    {
                        FileHandle = fileHandle,
                        Data = base64Data,
                        StartAt = position.ToString()
                    };

                    await _dealsService.UploadChunkAsync(chunk);

                    totalBytesRead += bytesRead;
                } while (bytesRead > 0);

                var uploadComplete = await _dealsService.EndFileUploadAsync(fileHandle, fileSize, _dealId, isThumbnail);
            }
            finally
            {
                fileStream.Close();
            }
        }

        private async Task CancelPublish()
        {
            if (!await _dialogsHelper.ShowConfirmAsync("¿Está seguro que quiere cancelar la creación del prenegocio?"))
                return;

            await Shell.Current.GoToAsync("..");
        }

        //private async Task ShowInstructions() => await PopupNavigation.Instance.PushAsync(new EvidenceInstructionsPopupPage(this));

        private Task ContinueToStepTwo()
        {
            if (!ValidateSectionOne())
            {
                _forceExpanderUpdateInteraction.Raise();

                return Task.CompletedTask;
            }

            _dialogsHelper.ShowDialog();

            FirstSectionCompleted = true;
            FirstSectionExpanded = false;

            SecondSectionEnabled = true;
            SecondSectionExpanded = true;

            var temporalFirstPath = !string.IsNullOrEmpty(FirstEvidencePath) ? FirstEvidencePath : string.Empty;
            var temporalSecondPath = !string.IsNullOrEmpty(SecondEvidencePath) ? SecondEvidencePath : string.Empty;
            var teporalThirdPath = !string.IsNullOrEmpty(ThirdEvidencePath) ? ThirdEvidencePath : string.Empty;

            if (string.IsNullOrEmpty(FirstVideoEvidencePath))
            {
                if (!string.IsNullOrEmpty(SecondVideoEvidencePath))
                {
                    FirstEvidencePath = string.Empty;
                    FirstVideoEvidencePath = SecondVideoEvidencePath;

                    SecondEvidencePath = temporalFirstPath;
                }
                else if (!string.IsNullOrEmpty(ThirdVideoEvidencePath))
                {
                    FirstEvidencePath = string.Empty;
                    FirstVideoEvidencePath = ThirdVideoEvidencePath;

                    SecondEvidencePath = temporalFirstPath;

                    ThirdEvidencePath = temporalSecondPath;
                }
            }
            else
            {
                if (string.IsNullOrEmpty(SecondVideoEvidencePath) && !string.IsNullOrEmpty(ThirdVideoEvidencePath))
                {
                    SecondEvidencePath = string.Empty;
                    SecondVideoEvidencePath = ThirdVideoEvidencePath;

                    ThirdEvidencePath = temporalSecondPath;
                }
            }

            _dialogsHelper.HideDialog();

            return Task.CompletedTask;
        }

        private async Task SelectProvince()
        {
            _dialogsHelper.ShowDialog();

            _locations.Clear();

            var locations = await _statesService.GetLocationsForProvinceAsync(ProvinceSelected.Name);

            _locations.AddRange(locations);

            LocationVisible = true;

            LocationTitle = Strings.SearchLocation;

            _forceExpanderUpdateInteraction.Raise();

            _dialogsHelper.HideDialog();
        }

        private async Task PickLocation() => await PopupNavigation.Instance.PushAsync(new LocationPopupPage(_locations));

        private Task ContinueToStepThree()
        {
            if (!ValidateSectionTwo())
            {
                _forceExpanderUpdateInteraction.Raise();

                return Task.CompletedTask;
            }

            SecondSectionCompleted = true;
            SecondSectionExpanded = false;

            ThirdSectionEnabled = true;
            ThirdSectionExpanded = true;

            return Task.CompletedTask;
        }

        private bool ValidateSectionOne()
        {
            SectionOneErrors.Clear();

            if (string.IsNullOrEmpty(TroopTypeSelected))
                SectionOneErrors.Add(nameof(TroopTypeSelected), "Debe seleccionar un tipo");

            if (string.IsNullOrEmpty(Amount))
                SectionOneErrors.Add(nameof(Amount), "Debe ingresar una cantidad de animales");

            if (TroopCategorySelected == "Faena")
            {
                if (string.IsNullOrEmpty(DestinationSelected))
                {
                    SectionOneErrors.Add(nameof(DestinationSelected), "Debe seleccionar un Destino.");

                    _dialogsHelper.ShowAlert("Debe seleccionar un Destino.");
                }

                if (DestinationSelected == "Exportación")
                {
                    if (string.IsNullOrEmpty(GeographicDestinationSelected))
                        SectionOneErrors.Add(nameof(GeographicDestinationSelected), "Debe ingresar un Destino Geográfico");
                }
            }

            if (string.IsNullOrEmpty(WeightAmountSelected))
                SectionOneErrors.Add(nameof(WeightAmountSelected), "Debe ingresar un Rango de Peso");

            if (string.IsNullOrEmpty(FirstEvidencePath) && string.IsNullOrEmpty(FirstVideoEvidencePath))
            {
                SectionOneErrors.Add(nameof(FirstEvidencePath), "Debe cargar al menos una evidencia");

                _dialogsHelper.ShowAlert("Debe cargar al menos una evidencia");
            }

            if (string.IsNullOrEmpty(FirstVideoEvidencePath) && string.IsNullOrEmpty(SecondVideoEvidencePath) && string.IsNullOrEmpty(ThirdVideoEvidencePath))
            {
                SectionOneErrors.Add(nameof(FirstVideoEvidencePath), "Debe cargar al menos un video");

                _dialogsHelper.ShowAlert("Debe cargar al menos un video");
            }

            this.OnPropertyChanged(nameof(SectionOneErrors));

            SectionOneHasErrors = SectionOneErrors.Any();

            return !SectionOneErrors.Any();
        }

        private bool ValidateSectionTwo()
        {
            SectionTwoErrors.Clear();

            if (string.IsNullOrEmpty(SuggestedPrice))
                SectionTwoErrors.Add(nameof(SuggestedPrice), "Debe ingresar un precio.");

            if (string.IsNullOrEmpty(PaymentMethodSelected))
                SectionTwoErrors.Add(nameof(PaymentMethodSelected), "Debe ingresar un método de pago.");

            if (string.IsNullOrEmpty(FinancingCategorySelected))
                SectionTwoErrors.Add(nameof(FinancingCategorySelected), "Debe ingresar un plazo de pago.");

            if (ProvinceSelected == null)
                SectionTwoErrors.Add(nameof(ProvinceSelected), "Debe ingresar una provincia.");

            if (LocationSelected == null)
            {
                SectionTwoErrors.Add(nameof(LocationSelected), "Debe ingresar una localidad.");

                _dialogsHelper.ShowAlert("Debe ingresar una localidad.");
            }

            //if (ToDate == FromDate)
            //{
            //    SectionTwoErrors.Add(nameof(ToDate), "El plazo debe ser mayor al día de hoy.");

            //    _dialogsHelper.ShowAlert("El plazo debe ser mayor al día de hoy.");
            //}

            this.OnPropertyChanged(nameof(SectionTwoErrors));

            SectionTwoHasErrors = SectionTwoErrors.Any();

            return !SectionTwoErrors.Any();
        }
    }
}