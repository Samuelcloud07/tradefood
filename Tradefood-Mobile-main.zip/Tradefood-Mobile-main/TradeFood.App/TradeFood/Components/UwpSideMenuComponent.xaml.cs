﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Settings;
using TradeFood.Views;
using Xamarin.Forms;

namespace TradeFood.Components
{
    public partial class UwpSideMenuComponent : StackLayout
    {
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        private ObservableCollection<SideMenuItem> _sideMenuItems = new ObservableCollection<SideMenuItem>();

        // Bindable Properties
        public static readonly BindableProperty SelectedItemProperty = BindableProperty.Create(
            nameof(SelectedItem),
            typeof(string),
            typeof(UwpSideMenuComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (UwpSideMenuComponent)bindable;

                var selected = (string)newVal;

                if (view._sideMenuItems != null && view._sideMenuItems.Count > 0)
                    view._sideMenuItems.First(i => i.MenuTitle == selected).IsSelected = true;
            }
        );

        public UwpSideMenuComponent()
        {
            InitializeComponent();

            _appSettings = TypeLocator.Resolve<IAppSettings>();
            _dialogsHelper = TypeLocator.Resolve<IDialogsHelper>();

            BindingContext = this;

            this.MenuItemSelectedCommand = new SandboxedCommand<SideMenuItem>(i => MenuItemSelected(i));            

            switch (_appSettings.ClientType)
            {
                case ("Productor"):
                case ("Comisionista"):
                case ("Consignataria"):
                    _sideMenuItems = new ObservableCollection<SideMenuItem>
                    {
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_home.png",
                            MenuTitle = "Inicio",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_market.png",
                            MenuTitle = "Mercado",
                            Target = "uwp_market"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_business.png",
                            MenuTitle = "Negocios",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_finances.png",
                            MenuTitle = "Finanzas",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_schedule.png",
                            MenuTitle = "Agenda",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_profile.png",
                            MenuTitle = "Perfil",
                            Target="ProfileDataPage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_novelties.png",
                            MenuTitle = "Portal de novedades",
                            Target = nameof(NewsPortalPage)
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_tac.png",
                            MenuTitle = "Términos y condiciones",
                            Target = "HomePage"
                        },
                        //new SideMenuItem
                        //{
                        //    MenuImage = "ic_tab_clients.png",
                        //    MenuTitle = "Clientes"
                        //},
                        //new SideMenuItem
                        //{
                        //    MenuImage = "ic_tab_metrics.png",
                        //    MenuTitle = "Métricas e informes"
                        //},
                        //new SideMenuItem
                        //{
                        //    MenuImage = "ic_tab_config.png",
                        //    MenuTitle = "Configuración"
                        //},
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_logout.png",
                            MenuTitle = "Cerrar sesión"
                        }
                    };

                    break;

                case ("Frigorífico"):
                    _sideMenuItems = new ObservableCollection<SideMenuItem>
                    {
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_home.png",
                            MenuTitle = "Inicio",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_market.png",
                            MenuTitle = "Mercado",
                            Target = "uwp_market"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_business.png",
                            MenuTitle = "Negocios",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_finances.png",
                            MenuTitle = "Finanzas",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_schedule.png",
                            MenuTitle = "Agenda",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_profile.png",
                            MenuTitle = "Perfil",
                            Target="ProfileDataPage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_novelties.png",
                            MenuTitle = "Portal de novedades",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_tac.png",
                            MenuTitle = "Términos y condiciones",
                            Target = "HomePage"
                        },
                        new SideMenuItem
                        {
                            MenuImage = "ic_tab_logout.png",
                            MenuTitle = "Cerrar sesión"
                        }
                    };

                    break;
            }            
            
            menuList.ItemsSource = _sideMenuItems;
        }

        // Properties
        public string SelectedItem
        {
            get => (string)GetValue(SelectedItemProperty);
            set => SetValue(SelectedItemProperty, value);
        }

        // Commands
        public SandboxedCommand<SideMenuItem> MenuItemSelectedCommand { get; private set; }

        // Methods
        private async Task MenuItemSelected(SideMenuItem item)
        {
            if (item.MenuTitle != "Cerrar sesión")
            {
                _appSettings.ItemMenuSelected = item.MenuTitle;
                await Shell.Current.GoToAsync(item.Target, false);
            }

                
            else
            {
                if (!await _dialogsHelper.ShowConfirmAsync("¿Esta seguro que desea salir?"))
                    return;

                _dialogsHelper.ShowDialog();

                _appSettings.ClearSettings();

                await Task.Delay(500);

                _dialogsHelper.HideDialog();

                await Shell.Current.GoToAsync("main/login");
            }
        }
    }
}