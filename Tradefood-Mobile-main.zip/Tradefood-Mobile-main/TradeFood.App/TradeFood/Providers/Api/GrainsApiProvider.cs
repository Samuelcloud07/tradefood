﻿using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.ApiClient.ApisInterfaces;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class GrainsApiProvider : TradeFoodBaseApiProvider, IGrainsApiProvider
    {
        public GrainsApiProvider(IAppHttpClient httpClientSingleton,
                                 IApiExceptionManager apiExceptionManager)
            : base(httpClientSingleton, apiExceptionManager)
        {
        }

        public async Task<GrainData> GetGrainsQuotationAsync()
        {
            var grainsQuotation = await this.ExecuteRequest<TradeFoodApiResponse<GrainData>>(
                () => this.GetRestServiceFor<IGrainsApi>().GetGrainsQuotationAsync()).ConfigureAwait(false);

            return grainsQuotation.Data;
        }
    }
}