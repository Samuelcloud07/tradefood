﻿using System;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Settings;
using TradeFood.ViewModels;
using TradeFood.Views;
using TradeFood.Views.Market;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace TradeFood
{
    public partial class AppShell : Shell
    {
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        public AppShell()
        {
            InitializeComponent();

            On<iOS>().SetUseSafeArea(true);

            RegisterRoutes();

            BindingContext = this;

            _appSettings = TypeLocator.Resolve<IAppSettings>();
            _dialogsHelper = TypeLocator.Resolve<IDialogsHelper>();

            DisplayName = _appSettings.UserName;

            OpenNewsReportsCommand = new SandboxedCommand(OpenNewsReports);

            LogoutCommand = new SandboxedCommand(Logout);

            GoToProfileCommand = new SandboxedCommand(GoToProfile);

            MessagingCenter.Subscribe<BaseViewModel>(this, "LoginCompleted", (sender) =>
            {
                MainThread.BeginInvokeOnMainThread(() =>
                {
                    DisplayName = _appSettings.UserName;
                });
            });
        }

        private void RegisterRoutes()
        {
            Routing.RegisterRoute("main/login", typeof(LoginPage));

            Routing.RegisterRoute("uwp_market", typeof(MarketPage));

            Routing.RegisterRoute(nameof(HomePage), typeof(HomePage));

            // Register
            Routing.RegisterRoute(nameof(RegisterPage), typeof(RegisterPage));
            Routing.RegisterRoute(nameof(RegisterValidationPage), typeof(RegisterValidationPage));
            Routing.RegisterRoute(nameof(RegisterSuccessPage), typeof(RegisterSuccessPage));
            Routing.RegisterRoute(nameof(PreferencesPage), typeof(PreferencesPage));

            // Password Recovery
            Routing.RegisterRoute("PasswordRecovery", typeof(PasswordRecoveryPage));
            Routing.RegisterRoute("ForgetPassword", typeof(ForgetPasswordPage));
            Routing.RegisterRoute("RestorePassword", typeof(RestorePasswordPage));

            // Market
            Routing.RegisterRoute(nameof(NewPublishPage), typeof(NewPublishPage));
            Routing.RegisterRoute(nameof(DealDetailsPage), typeof(DealDetailsPage));
            Routing.RegisterRoute(nameof(NewPublishFirstStepPage), typeof(NewPublishFirstStepPage));
            Routing.RegisterRoute(nameof(NewPublishSecondStepPage), typeof(NewPublishSecondStepPage));
            Routing.RegisterRoute(nameof(NewPublishThirdStepPage), typeof(NewPublishThirdStepPage));
            Routing.RegisterRoute(nameof(AddNewPersonOrSocietyPage), typeof(AddNewPersonOrSocietyPage));
            Routing.RegisterRoute(nameof(DealsFiltersPage), typeof(DealsFiltersPage));
            Routing.RegisterRoute(nameof(NewMarketPage), typeof(NewMarketPage));
            Routing.RegisterRoute(nameof(NewDealDetailsPage), typeof(NewDealDetailsPage));


            //Profile
            Routing.RegisterRoute(nameof(ProfilePage), typeof(ProfilePage));
            Routing.RegisterRoute(nameof(ProfileDataPage), typeof(ProfileDataPage));
            Routing.RegisterRoute(nameof(AddSocietiesPage), typeof(AddSocietiesPage));
            Routing.RegisterRoute(nameof(AddAdressPage), typeof(AddAdressPage));
            Routing.RegisterRoute(nameof(ProfilePreferencesPage), typeof(ProfilePreferencesPage));
            Routing.RegisterRoute(nameof(PersonalDataPage), typeof(PersonalDataPage));
            Routing.RegisterRoute(nameof(SettingsPage), typeof(SettingsPage));
            Routing.RegisterRoute(nameof(ChangePasswordPage), typeof(ChangePasswordPage));
            Routing.RegisterRoute(nameof(UserFaenaDataPage), typeof(UserFaenaDataPage));
            Routing.RegisterRoute(nameof(EditMyDataPage), typeof(EditMyDataPage));
            Routing.RegisterRoute(nameof(ProfilePreferencesFirstSectionPage), typeof(ProfilePreferencesFirstSectionPage));
            Routing.RegisterRoute(nameof(ProfilePreferencesSecondSectionPage), typeof(ProfilePreferencesSecondSectionPage));
            Routing.RegisterRoute(nameof(ProfilePreferencesEmptyPage), typeof(ProfilePreferencesEmptyPage));
            Routing.RegisterRoute(nameof(ProfilePreferencesCompletePage), typeof(ProfilePreferencesCompletePage));
            Routing.RegisterRoute(nameof(UpdateSocialReasonPage), typeof(UpdateSocialReasonPage));
            Routing.RegisterRoute(nameof(EditPreferencesFirstSectionPage), typeof(EditPreferencesFirstSectionPage));
            Routing.RegisterRoute(nameof(EditPreferencesSecondSectionPage), typeof(EditPreferencesSecondSectionPage));


            // Chatbot
            Routing.RegisterRoute(nameof(InquiriesPage), typeof(InquiriesPage));

            // Agro News
            Routing.RegisterRoute(nameof(NewsPortalPage), typeof(NewsPortalPage));
        }

        // Properties
        public string DisplayName { get; private set; }

        public string VersionNumber => $"v{VersionTracking.CurrentVersion}";

        public DateTime ReleaseDate => new DateTime(2022, 07, 19);

        // Commands
        public SandboxedCommand OpenNewsReportsCommand { get; private set; }

        public SandboxedCommand LogoutCommand { get; private set; }

        public SandboxedCommand GoToProfileCommand { get; private set; }

        // Methods
        private async Task OpenNewsReports()
        {
            await Current.GoToAsync(nameof(NewsPortalPage));

            Current.FlyoutIsPresented = false;
        }

        private async Task Logout()
        {
            if (!await _dialogsHelper.ShowConfirmAsync("¿Esta seguro que desea salir?"))
                return;

            _dialogsHelper.ShowDialog();

            await Task.Delay(800);

            _appSettings.ClearSettings();

            _dialogsHelper.HideDialog();

            await Current.GoToAsync("main/login");
        }

        private async Task GoToProfile()
        {
            await Shell.Current.GoToAsync(nameof(ProfilePage));
            
            Current.FlyoutIsPresented = false;
        }
        
    }
}