﻿using Authentication;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Reflection;
using System.Threading.Tasks;
using ExecutionContext = Microsoft.Azure.WebJobs.ExecutionContext;

namespace TFAuthenticationFunction
{
    public static class WebAppProxy
    {
        private static readonly Lazy<(RequestDelegate requestDelegate, IServiceProvider serviceProvider)> Init =
            new Lazy<(RequestDelegate requestDelegate, IServiceProvider serviceProvider)>(() =>
            {
                // Crear una instancia de la clase de inicio de ASP.NET Core estándar

                var webHostBuilder = WebHost
                    .CreateDefaultBuilder(Array.Empty<string>())
                    .UseStartup<Startup>();

                var webHost = webHostBuilder.Build();

                // ver https://github.com/dotnet/aspnetcore/blob/master/src/Hosting/Hosting/src/Internal/WebHost.cs
                var serviceCollection = (ServiceCollection)webHost?.GetType()
                    .GetField("_applicationServiceCollection", BindingFlags.Instance | BindingFlags.NonPublic)
                        ?.GetValue(webHost);

                // Inicializar el contenedor de DI
                var serviceProvider = serviceCollection.BuildServiceProvider();

                var startup = new Startup(serviceProvider.GetRequiredService<IConfiguration>());

                // Agregar el servicio web app en el contenedor de DI
                startup.ConfigureServices(serviceCollection);

                // Inicializar el Application builder
                var appBuilder = new ApplicationBuilder(serviceProvider, new FeatureCollection());

                // Configurar el pipeline de HTTP request
                startup.Configure(appBuilder, serviceProvider.GetRequiredService<IWebHostEnvironment>());

                // Construir la función de gestión de solicitudes
                var requestHandler = appBuilder.Build();

                return (requestHandler, serviceProvider);
            });

        [FunctionName(nameof(WebAppProxy))]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", "put", "patch", Route = "{*any}")]
            HttpRequest req,
            ExecutionContext context,
            ILogger logger)
        {
            logger.LogInformation("C# HTTP trigger function processed a request.");

            var prerequisites = Init.Value;

            // Setear el contenedor de DI para HTTP Context
            req.HttpContext.RequestServices = prerequisites.serviceProvider;

            // Handle HTTP request
            await prerequisites.requestDelegate(req.HttpContext);

            // Este resultado ficticio no hace nada, la respuesta HTTP ya está establecida por requestHandler
            return new EmptyResult();
        }
    }
}