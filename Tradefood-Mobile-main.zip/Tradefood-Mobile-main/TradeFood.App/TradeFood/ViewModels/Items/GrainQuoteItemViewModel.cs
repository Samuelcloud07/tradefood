﻿using Rg.Plugins.Popup.Services;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Models;
using TradeFood.Views.Popups;

namespace TradeFood.ViewModels
{
    public class GrainQuoteItemViewModel : INotifyPropertyChanged
    {
        private List<GrainsItemViewModel> _grains = new List<GrainsItemViewModel>();

        public GrainQuoteItemViewModel(Grain grain,
                                       List<GrainsItemViewModel> grains)
        {
            GrainData = grain;

            Quotation = grain.Cotizacion.FirstOrDefault();

            _grains = grains;

            ShowGrainDetailsCommand = new SandboxedCommand(ShowGrainDetails);
        }

        // Properties
        public Grain GrainData { get; private set; }

        public GrainQuotation Quotation { get; private set; }

        // Commands
        public SandboxedCommand ShowGrainDetailsCommand { get; private set; }

        // Methods
        private async Task ShowGrainDetails()
        {
            await PopupNavigation.Instance.PushAsync(new GrainsQuotesPopupPage(_grains, GrainData.Tipo));
        }

        // INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}