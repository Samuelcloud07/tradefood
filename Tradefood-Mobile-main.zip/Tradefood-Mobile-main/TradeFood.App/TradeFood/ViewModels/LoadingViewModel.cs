﻿using System.Threading.Tasks;
using TradeFood.Helpers;
using TradeFood.Sandbox;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class LoadingViewModel : BaseViewModel
    {
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        public LoadingViewModel(ILogger logger,
                                IAppSettings appSettings,
                                IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _appSettings = appSettings;
            _dialogsHelper = dialogsHelper;
        }

        public override void OnAppearing()
        {
            this.LoadTask = SandboxedNotifyTask.Create(() => SetInitialNavigation());
        }

        // Methods
        private async Task SetInitialNavigation()
        {
            _dialogsHelper.ShowDialog();

            if (!_appSettings.IsLoggedIn)
            {
                _dialogsHelper.HideDialog();

                await MainThread.InvokeOnMainThreadAsync(async () => await Shell.Current.GoToAsync("///LoginPage"));
            }
            else if (_appSettings.IsLoggedIn && _appSettings.IsAdmin) 
            {
                _dialogsHelper.HideDialog();

                Application.Current.MainPage = new NavigationPage(new Views.AdministratorMainPage());
            }
            else
            {
                _dialogsHelper.HideDialog();

                await MainThread.InvokeOnMainThreadAsync(async () => await Shell.Current.GoToAsync("///main"));
            }
        }
    }
}