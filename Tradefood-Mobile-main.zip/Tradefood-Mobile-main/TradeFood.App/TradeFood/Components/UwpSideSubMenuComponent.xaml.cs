﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Settings;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TradeFood.Components
{
    public partial class UwpSideSubMenuComponent : StackLayout
    {
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        private ObservableCollection<SideMenuItem> _sideSubMenuItems = new ObservableCollection<SideMenuItem>();

        // Bindable Properties
        public static readonly BindableProperty SelectedItemProperty = BindableProperty.Create(
            nameof(SelectedItem),
            typeof(string),
            typeof(UwpSideSubMenuComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (UwpSideSubMenuComponent)bindable;

                var selected = (string)newVal;

                if (view._sideSubMenuItems != null && view._sideSubMenuItems.Count > 0)
                    view._sideSubMenuItems.First(i => i.MenuTitle == selected).IsSelected = true;
            }
        );

        public UwpSideSubMenuComponent()
        {
            InitializeComponent();

            _appSettings = TypeLocator.Resolve<IAppSettings>();
            _dialogsHelper = TypeLocator.Resolve<IDialogsHelper>();

            BindingContext = this;

            this.MenuItemSelectedCommand = new SandboxedCommand<SideMenuItem>(i => MenuItemSelected(i));

            switch (_appSettings.ItemMenuSelected)
            {
                case ("Perfil"):
                    _sideSubMenuItems = new ObservableCollection<SideMenuItem>
                    {
                        new SideMenuItem
                        {
                            MenuImage = "icon_material_account_box.png",
                            MenuTitle = "Mis Datos",
                            Target = "ProfileDataPage",
                            MenuIcon="icon_metro_expand_more.png"
                        },
                        /*
                        new SideMenuItem
                        {
                            MenuImage = "icon_awesome_shopping_basket.png",
                            MenuTitle = "Mis Preferencias",
                            Target = "PrfilePreferencesPage"
                        },

                        new SideMenuItem
                            {
                                MenuImage = "icon_feather_gift.png",
                                MenuTitle = "Beneficios"
                            },
                        */
                        new SideMenuItem
                            {
                                MenuImage = "icon_material_settings.png",
                                MenuTitle = "Configuración",
                                Target= "SettingsPage",
                                MenuIcon="icon_metro_expand_more.png"
                            }
                    };
                    break;               

            };

            menuList.ItemsSource = _sideSubMenuItems;
        }
        // Properties
        public string SelectedItem
        {
            get => (string)GetValue(SelectedItemProperty);
            set => SetValue(SelectedItemProperty, value);
        }

        // Commands
        public SandboxedCommand<SideMenuItem> MenuItemSelectedCommand { get; private set; }

        // Methods
        private async Task MenuItemSelected(SideMenuItem item)
        {
            await Shell.Current.GoToAsync(item.Target, false);            
        }

    }
}
