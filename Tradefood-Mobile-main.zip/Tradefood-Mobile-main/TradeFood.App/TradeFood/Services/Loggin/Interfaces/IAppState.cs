﻿using TradeFood.Enums;
using System;
using System.Threading.Tasks;

namespace TradeFood.Services.Loggin
{
    public interface IAppState
    {
        Task Init();
        Guid GetInstallId();
        AppLogLevel GetAppLogLevel();
        void SetAppLogLevel(AppLogLevel level);
    }
}