﻿using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public interface IWheaterProvider
    {
        Task<WheaterData> GetWheaterAsync(string lat, string lon);
    }
}