﻿using TradeFood.Extensions;
using System;

namespace TradeFood.ViewModels.Base
{
    public class Interaction : IInteraction
    {
        public void Raise()
        {
            Requested?.Invoke(this, EventArgs.Empty);
        }

        public event EventHandler Requested;
    }

    public class Interaction<T> : IInteraction<T>
    {
        public void Raise(T request)
        {
            Requested?.Invoke(this, new ValueEventArgs<T>(request));
        }

        public event EventHandler<ValueEventArgs<T>> Requested;
    }
}