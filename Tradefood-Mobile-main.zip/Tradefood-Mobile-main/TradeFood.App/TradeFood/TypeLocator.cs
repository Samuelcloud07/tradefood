﻿using System;
using Acr.UserDialogs;
using Autofac;
using Autofac.Core;
using TradeFood.ApiClient;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Providers;
using TradeFood.Repositories;
using TradeFood.Sandbox;
using TradeFood.SecureRepository;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;

namespace TradeFood
{
    public static class TypeLocator
    {
        private static ILifetimeScope _rootScope;

        // Methods
        public static T Resolve<T>()
        {
            if (_rootScope == null)
                throw new Exception("Bootstrapper hasn't been started!");

            return _rootScope.Resolve<T>();
        }

        public static T Resolve<T>(Parameter[] parameters)
        {
            if (_rootScope == null)
                throw new Exception("Bootstrapper hasn't been started!");

            return _rootScope.Resolve<T>(parameters);
        }

        public static object Resolve(Type type)
        {
            if (_rootScope == null)
                throw new Exception("Bootstrapper hasn't been started!");

            return _rootScope.Resolve(type);
        }

        public static object Resolve(Type type, Parameter[] parameters)
        {
            if (_rootScope == null)
                throw new Exception("Bootstrapper hasn't been started!");

            return _rootScope.Resolve(type, parameters);
        }

        public static void Start()
        {
            if (_rootScope != null) return;

            var containerBuilder = new ContainerBuilder();

            // App basics
            containerBuilder.RegisterType<AppState>().As<IAppState>().SingleInstance();
            containerBuilder.RegisterType<Logger>().As<ILogger>().SingleInstance();

            // Settings and encrypt settings
            containerBuilder.RegisterType<AppSettings>().As<IAppSettings>().SingleInstance();
            containerBuilder.RegisterType<SecureStorageRepository>().As<ISecureStorageRepository>().SingleInstance();

            // Command
            containerBuilder.RegisterType<DelegateCommand>().As<IDelegateCommand>().SingleInstance();

            // Sandbox
            containerBuilder.RegisterType<ServiceSandbox>().As<IServiceSandbox>().SingleInstance();

            // Helpers
            containerBuilder.RegisterType<DialogsHelper>().As<IDialogsHelper>().SingleInstance();
            containerBuilder.RegisterType<MediaHelper>().As<IMediaHelper>().SingleInstance();

            // Api
            containerBuilder.RegisterType<ApiExceptionManager>().As<IApiExceptionManager>().SingleInstance();
            containerBuilder.RegisterType<AppHttpClient>().As<IAppHttpClient>().SingleInstance();

            // Factories
            containerBuilder.RegisterType<ProviderFactory>().As<IProviderFactory>().SingleInstance();

            // Providers
            containerBuilder.RegisterType<StatesApiProvider>().As<IStatesApiProvider>().SingleInstance();
            containerBuilder.RegisterType<StatesLocalProvider>().As<StatesLocalProvider>().SingleInstance();
            containerBuilder.RegisterType<LiniersApiProvider>().As<ILiniersApiProvider>().SingleInstance();
            containerBuilder.RegisterType<LiniersLocalProvider>().As<ILiniersLocalProvider>().SingleInstance();
            containerBuilder.RegisterType<DollarApiProvider>().As<IDollarApiProvider>().SingleInstance();
            containerBuilder.RegisterType<DollarLocalProvider>().As<IDollarLocalProvider>().SingleInstance();
            containerBuilder.RegisterType<GrainsApiProvider>().As<IGrainsApiProvider>().SingleInstance();
            containerBuilder.RegisterType<GrainsLocalProvider>().As<IGrainsLocalProvider>().SingleInstance();
            containerBuilder.RegisterType<AuthenticationApiProvider>().As<IAuthenticationApiProvider>().SingleInstance();
            containerBuilder.RegisterType<AuthenticationLocalProvider>().As<IAuthenticationLocalProvider>().SingleInstance();
            containerBuilder.RegisterType<WheaterApiProvider>().As<IWheaterApiProvider>().SingleInstance();
            containerBuilder.RegisterType<WheaterLocalProvider>().As<IWheaterLocalProvider>().SingleInstance();
            containerBuilder.RegisterType<AgroNewsApiProvider>().As<IAgroNewsApiProvider>().SingleInstance();
            containerBuilder.RegisterType<AgroNewsLocalProvider>().As<IAgroNewsLocalProvider>().SingleInstance();
            containerBuilder.RegisterType<DealsApiProvider>().As<IDealsApiProvider>().SingleInstance();
            containerBuilder.RegisterType<DealsLocalProvider>().As<IDealsLocalProvider>().SingleInstance();
            containerBuilder.RegisterType<ProfileApiProvider>().As<IProfileApiProvider>().SingleInstance();
            containerBuilder.RegisterType<ProfileLocalProvider>().As<IProfileLocalProvider>().SingleInstance();

            // SQLite
            containerBuilder.RegisterInstance(new SQLiteAdapter()).As<ISQLiteAdapter>();

            // SQLite Repositories
            containerBuilder.RegisterType<BaseSQLiteRepository<LiniersData>>().As<ISQLiteRepository<LiniersData>>();
            containerBuilder.RegisterType<LiniersRepository>().As<ILiniersRepository>().SingleInstance();

            containerBuilder.RegisterType<BaseSQLiteRepository<NewsReport>>().As<ISQLiteRepository<NewsReport>>();
            containerBuilder.RegisterType<AgroNewsRepository>().As<IAgroNewsRepository>().SingleInstance();

            containerBuilder.RegisterType<BaseSQLiteRepository<PreBusiness>>().As<ISQLiteRepository<PreBusiness>>();
            containerBuilder.RegisterType<PreBusinessRepository>().As<IPreBusinessRepository>().SingleInstance();

            // UserDialogs
            var userDialogsInstance = UserDialogs.Instance;
            containerBuilder.Register(c => userDialogsInstance).As<IUserDialogs>().SingleInstance();

            // Services
            containerBuilder.RegisterType<StatesService>().As<IStatesService>().SingleInstance();
            containerBuilder.RegisterType<LiniersService>().As<ILiniersService>().SingleInstance();
            containerBuilder.RegisterType<DollarService>().As<IDollarService>().SingleInstance();
            containerBuilder.RegisterType<GrainsService>().As<IGrainsService>().SingleInstance();
            containerBuilder.RegisterType<AuthenticationService>().As<IAuthenticationService>().SingleInstance();
            containerBuilder.RegisterType<WheaterService>().As<IWheaterService>().SingleInstance();
            containerBuilder.RegisterType<AgroNewsService>().As<IAgroNewsService>().SingleInstance();
            containerBuilder.RegisterType<DealsService>().As<IDealsService>().SingleInstance();
            containerBuilder.RegisterType<ProfileService>().As<IProfileService>().SingleInstance();

            _rootScope = containerBuilder.Build();
        }

        public static void Stop()
        {
            _rootScope.Dispose();
        }
    }
}