﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class GrainQuotation
    {
        [JsonProperty("mercado")]
        public string Mercado { get; set; }

        [JsonProperty("precio")]
        public string Precio { get; set; }

        [JsonProperty("relacionAnterior")]
        public string RelacionAnterior { get; set; }

        [JsonProperty("fecha")]
        public string Fecha { get; set; }
    }
}