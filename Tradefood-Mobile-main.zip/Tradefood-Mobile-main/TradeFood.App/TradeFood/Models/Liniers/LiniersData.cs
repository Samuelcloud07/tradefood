﻿using Newtonsoft.Json;
using SQLiteNetExtensions.Attributes;
using System;
using System.Collections.Generic;

namespace TradeFood.Models
{
    public class LiniersData : BaseEntityModel
    {
        [JsonProperty("Categoria")]
        public string Category { get; set; }

        [JsonProperty("Minimo")]
        public string Min { get; set; }

        [JsonProperty("Maximo")]
        public string Max { get; set; }

        [JsonProperty("Promedio")]
        public string Average { get; set; }

        [JsonProperty("Mediano")]
        public string Median { get; set; }

        [JsonProperty("Cabezas")]
        public string Heads { get; set; }

        [JsonProperty("Importe")]
        public string Amount { get; set; }

        [JsonProperty("Kgs")]
        [TextBlob(nameof(KgsBlobed))]
        public List<string> Kgs { get; set; }

        public DateTime Date { get; set; }

        [JsonIgnore]
        public string KgsBlobed { get; set; }
    }
}