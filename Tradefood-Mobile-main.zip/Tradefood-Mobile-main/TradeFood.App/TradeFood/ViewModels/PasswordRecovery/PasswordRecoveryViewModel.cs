﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class PasswordRecoveryViewModel : BaseViewModel, IQueryAttributable
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IDialogsHelper _dialogsHelper;

        public PasswordRecoveryViewModel(ILogger logging,
                                         IAuthenticationService authenticationService,
                                         IDialogsHelper dialogsHelper)
            :base (logging)
        {
            _authenticationService = authenticationService;
            _dialogsHelper = dialogsHelper;

            ResendPasswordTokenCommand = new SandboxedCommand(ResendPasswordToken);

            RestorePasswordCommand = new SandboxedCommand(RestorePassword);
            
            GoBackCommand = new SandboxedCommand(GoBack);
        }

        public void ApplyQueryAttributes(IDictionary<string, string> query)
        {
            RequestNewPassword = JsonConvert.DeserializeObject<RequestNewPasswordResponse>(HttpUtility.UrlDecode(query["requestNewPassword"]));
        }

        // Properties
        public RequestNewPasswordResponse RequestNewPassword { get; private set; }

        public string PasswordResetToken { get; set; }

        // Commands
        public SandboxedCommand ResendPasswordTokenCommand { get; private set; }

        public SandboxedCommand RestorePasswordCommand { get; private set; }

        public SandboxedCommand GoBackCommand { get; private set; }

        // Methods
        private async Task ResendPasswordToken()
        {
            _dialogsHelper.ShowDialog();

            await _authenticationService.RequestPasswordResetAsync(RequestNewPassword.Email);

            _dialogsHelper.HideDialog();

            _dialogsHelper.ShowAlert($"Un nuevo código ha sido enviado a tu casilla de mail: {RequestNewPassword.Email}");
        }

        private async Task RestorePassword()
        {
            var resetUserPassword = new ResetUserPassword
            {
                Email = RequestNewPassword.Email,
                PasswordResetToken = this.PasswordResetToken
            };

            resetUserPassword.Password = "Abcd1234$";
            var resetUserPasswordSerialized = JsonConvert.SerializeObject(resetUserPassword);
            

            await Shell.Current.GoToAsync($"RestorePassword?resetUserPassword={resetUserPasswordSerialized}");
        }

        private async Task GoBack() => await Shell.Current.Navigation.PopToRootAsync();
    }
}