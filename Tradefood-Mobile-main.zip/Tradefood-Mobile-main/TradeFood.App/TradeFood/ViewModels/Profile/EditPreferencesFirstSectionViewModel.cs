﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels.Items;
using TradeFood.Views;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    class EditPreferencesFirstSectionViewModel : BaseViewModel
    {
        private readonly IProfileService _profileService;
        private readonly IAppSettings _appSettings;
        public EditPreferencesFirstSectionViewModel(ILogger logger,
                                    IAppSettings appSettings, IProfileService profileService)
            : base(logger)
        {
            GoToSecondStepCommand = new SandboxedCommand(GoToSecondStep);

            CancelPublishCommand = new SandboxedCommand(CancelPublish);

            _appSettings = appSettings;
            _profileService = profileService;
        }

        protected override Task InitializeAsync()
        {

            IsBreedingChecked = PreferencesObject.IsBusinessTypeBrood;
            IsWinteringChecked = PreferencesObject.IsBusinessTypeWintering;
            IsChoreChecked = PreferencesObject.IsBusinessTypeChore;
            IsEqualChecked = PreferencesObject.TroopWeightType;
            IsNotEqualChecked = PreferencesObject.UnevenTroopWeightType;
            MinWeightWinteringSelected = PreferencesObject.MinWeightWintering.ToString();
            MaxWeightWinteringSelected = PreferencesObject.MaxWeightWintering.ToString();
            MinWeightChoreSelected = PreferencesObject.MinWeightChore.ToString();
            MaxWeightChoreSelected = PreferencesObject.MaxWeightChore.ToString();

            WinteringCategories = new ObservableCollection<TroopCategoryItemViewModel>
                        {
                            new TroopCategoryItemViewModel("Terneros","Male"),
                            new TroopCategoryItemViewModel("Terneras","Female"),
                            new TroopCategoryItemViewModel("Vacas","Female"),
                            new TroopCategoryItemViewModel("Novillitos","Male"),
                            new TroopCategoryItemViewModel("Vaquillonas","Female"),
                        };

            foreach (TroopCategoryItemViewModel troopCategory in WinteringCategories)
            {
                if (PreferencesObject.WinteringCategory.Contains(troopCategory.Name))
                {
                    troopCategory.Selected = true;
                    WinteringCategoriesSelected.Add(troopCategory);
                }

            }

            ChoreCategories = new ObservableCollection<TroopCategoryItemViewModel>
                        {
                            new TroopCategoryItemViewModel("Novillos","Male"),
                            new TroopCategoryItemViewModel("Mej","Male"),
                            new TroopCategoryItemViewModel("Novillitos","Male"),
                            new TroopCategoryItemViewModel("Vaquillonas","Female"),
                            new TroopCategoryItemViewModel("Vacas","Female"),
                            new TroopCategoryItemViewModel("Toros","Male")
                        };

            foreach (TroopCategoryItemViewModel troopCategory in ChoreCategories)
            {
                if (PreferencesObject.ChoreCategory.Contains(troopCategory.Name))
                {
                    troopCategory.Selected = true;
                    ChoreCategoriesSelected.Add(troopCategory);
                }

            }

            GeographicDestination = new ObservableCollection<GeographicDestinationItemViewModel>()
                        {
                            new GeographicDestinationItemViewModel("UE Hilton"),
                            new GeographicDestinationItemViewModel("UE no Hilton"),
                            new GeographicDestinationItemViewModel("Cuota 481"),
                            new GeographicDestinationItemViewModel("Terceros países/Consumo")
                        };

            foreach (GeographicDestinationItemViewModel destination in GeographicDestination)
            {
                if (PreferencesObject.DestinationChore.Contains(destination.Name))
                {
                    destination.Selected = true;
                    GeographicDestinationSelected.Add(destination);
                }

                if (PreferencesObject.DestinationChore.Contains("Terceros países/Consumo"))
                {
                    IsThirdCountry = true;
                    IsChina = PreferencesObject.DestinationChore.Contains("(Apto China)");
                    IsNotChina = PreferencesObject.DestinationChore.Contains("(No apto China)");
                }
            }

            SubCategories = new ObservableCollection<SubCategoriesItemViewModel>()
                        {
                            new SubCategoriesItemViewModel("Gorda"),
                            new SubCategoriesItemViewModel("Carnicera"),
                            new SubCategoriesItemViewModel("Manufactura"),
                            new SubCategoriesItemViewModel("Conserva"),
                            new SubCategoriesItemViewModel("Popurrí")
                        };

            foreach (SubCategoriesItemViewModel subcategory in SubCategories)
            {
                if (PreferencesObject.ChoreSubCategory.Contains(subcategory.Name))
                {
                    subcategory.Selected = true;
                    SubCategoriesSelected.Add(subcategory);
                }
            }

            return base.InitializeAsync();
        }

        public PreferencesDto PreferencesObject { get; set; }

        public List<string> MinWeight { get; } = new List<string>
                        {
                            "100", "200", "300", "400",
                            "500", "600", "700"
                        };

        public List<string> MaxWeight { get; } = new List<string>
                        {
                            "100", "200", "300", "400",
                            "500", "600", "700"
                        };

        public string MinWeightWinteringSelected { get; set; } = string.Empty;

        public string MaxWeightWinteringSelected { get; set; } = string.Empty;

        public string MinWeightChoreSelected { get; set; } = string.Empty;

        public string MaxWeightChoreSelected { get; set; } = string.Empty;
        public ObservableCollection<TroopCategoryItemViewModel> WinteringCategories { get; set; }

        public ObservableCollection<TroopCategoryItemViewModel> ChoreCategories { get; set; }

        public ObservableCollection<GeographicDestinationItemViewModel> GeographicDestination { get; set; }

        public ObservableCollection<SubCategoriesItemViewModel> SubCategories { get; set; }

        public List<TroopCategoryItemViewModel> WinteringCategoriesSelected { get; set; } = new List<TroopCategoryItemViewModel>();

        public List<TroopCategoryItemViewModel> ChoreCategoriesSelected { get; set; } = new List<TroopCategoryItemViewModel>();

        public List<GeographicDestinationItemViewModel> GeographicDestinationSelected { get; set; } = new List<GeographicDestinationItemViewModel>();

        public List<SubCategoriesItemViewModel> SubCategoriesSelected { get; set; } = new List<SubCategoriesItemViewModel>();

        public bool IsBreedingChecked { get; set; }

        private bool _isWinteringChecked;
        public bool IsWinteringChecked
        {
            get => _isWinteringChecked;
            set
            {
                _isWinteringChecked = value;

                if (!_isWinteringChecked)
                    Clear();
            }
        }

        private bool _isChoreChecked;
        public bool IsChoreChecked
        {
            get => _isChoreChecked;
            set
            {
                _isChoreChecked = value;
                if (!_isChoreChecked)
                    Clear();
            }
        }

        public bool IsEqualChecked { get; set; }

        public bool IsNotEqualChecked { get; set; }

        public bool IsThirdCountry { get; set; }

        public bool IsChina { get; set; }

        public bool IsNotChina { get; set; }

        public bool ShowSubCategories { get; set; }

        public bool ShowContinueButton => IsChoreChecked || IsWinteringChecked;

        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();

        public bool HasErrors { get; set; }

        private bool ValidateAll()
        {
            Errors.Clear();

            if (IsWinteringChecked)
            {
                if (WinteringCategoriesSelected.Count == 0)
                    Errors.Add(nameof(WinteringCategoriesSelected), Strings.YouMustSelectAtLeastOneCategory);

                if (string.IsNullOrEmpty(MinWeightWinteringSelected))
                    Errors.Add(nameof(MinWeightWinteringSelected), Strings.YouMustSelectAMinimumWeight);

                if (string.IsNullOrEmpty(MaxWeightWinteringSelected))
                {
                    Errors.Add(nameof(MaxWeightWinteringSelected), Strings.YouMustSelectAMaximumWeight);
                }

                if (!string.IsNullOrEmpty(MinWeightWinteringSelected) && !string.IsNullOrEmpty(MaxWeightWinteringSelected))
                {
                    if (MaxWeightWinteringSelected.Equals(MinWeightWinteringSelected) || Int32.Parse(MaxWeightWinteringSelected) < Int32.Parse(MinWeightWinteringSelected))
                    {
                        Errors.Add(nameof(MaxWeightWinteringSelected), Strings.MaximumCannotBeEqualToOrLessThanTheMinimum);
                    }
                }

                if (!IsEqualChecked && !IsNotEqualChecked)
                    Errors.Add(nameof(IsEqualChecked), Strings.YouMustSelectAtLeastOneOption);
            }
            if (IsChoreChecked)
            {
                if (GeographicDestinationSelected.Count == 0)
                    Errors.Add(nameof(GeographicDestinationSelected), Strings.YouMustSelectAtLeastOneDestination);

                if (IsThirdCountry && !(IsChina || IsNotChina))
                    Errors.Add(nameof(IsThirdCountry), Strings.YouMustSelectAtLeastOneOption);

                if (ChoreCategoriesSelected.Count == 0)
                    Errors.Add(nameof(ChoreCategoriesSelected), Strings.YouMustSelectAtLeastOneCategory);

                if (ChoreCategoriesSelected.Any(x => x.Name.Equals("Toros") || x.Name.Equals("Vacas")) && SubCategoriesSelected.Count == 0)
                    Errors.Add(nameof(SubCategoriesSelected), Strings.YouMustSelectAtLeastOneSubcategory);

                if (string.IsNullOrEmpty(MinWeightChoreSelected))
                    Errors.Add(nameof(MinWeightChoreSelected), Strings.YouMustSelectAMinimumWeight);

                if (string.IsNullOrEmpty(MaxWeightChoreSelected))
                {
                    Errors.Add(nameof(MaxWeightChoreSelected), Strings.YouMustSelectAMaximumWeight);
                }

                if (!string.IsNullOrEmpty(MinWeightChoreSelected) && !string.IsNullOrEmpty(MaxWeightChoreSelected))
                {
                    if (MaxWeightChoreSelected.Equals(MinWeightChoreSelected) || Int32.Parse(MaxWeightChoreSelected) < Int32.Parse(MinWeightChoreSelected))
                    {
                        Errors.Add(nameof(MaxWeightChoreSelected), Strings.MaximumCannotBeEqualToOrLessThanTheMinimum);
                    }
                }
            }


            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }

        // Commands

        public SandboxedCommand GoToSecondStepCommand { get; private set; }
        public SandboxedCommand CancelPublishCommand { get; private set; }

        // Methods

        private async Task GoToSecondStep()
        {
            if (!ValidateAll())
                return;

            StringBuilder sbWinteringCategories = new StringBuilder("");
            StringBuilder sbGeographicDestination = new StringBuilder("");
            StringBuilder sbChoreCategories = new StringBuilder("");
            StringBuilder sbChoreSubCategories = new StringBuilder("");
            if (IsWinteringChecked)
            {
                for (int i = 0; i < WinteringCategoriesSelected.Count; i++)
                {
                    if (WinteringCategoriesSelected.Count == 1)
                    {
                        sbWinteringCategories.Append(WinteringCategoriesSelected[i].Name);
                    }
                    else if (i == (WinteringCategoriesSelected.Count - 1))
                    {
                        sbWinteringCategories.Append(" y ");
                        sbWinteringCategories.Append(WinteringCategoriesSelected[i].Name);
                    }
                    else if (i == (WinteringCategoriesSelected.Count - 2))
                    {
                        sbWinteringCategories.Append(WinteringCategoriesSelected[i].Name);
                    }
                    else
                    {
                        sbWinteringCategories.Append(WinteringCategoriesSelected[i].Name);
                        sbWinteringCategories.Append(", ");
                    }
                }
            }

            if (IsChoreChecked)
            {
                for (int i = 0; i < GeographicDestinationSelected.Count; i++)
                {
                    if (GeographicDestinationSelected.Count == 1)
                    {
                        sbGeographicDestination.Append(GeographicDestinationSelected[i].Name);
                        if (IsThirdCountry)
                        {
                            if (IsChina && IsNotChina)
                            {
                                sbGeographicDestination.Append("(Apto China, No apto China)");
                            }
                            else
                            {
                                if (IsChina)
                                    sbGeographicDestination.Append("(Apto China)");
                                else
                                    sbGeographicDestination.Append("(No apto China)");
                            }
                        }
                    }
                    else if (i == (GeographicDestinationSelected.Count - 1))
                    {
                        sbGeographicDestination.Append(" y ");
                        sbGeographicDestination.Append(GeographicDestinationSelected[i].Name);
                        if (IsThirdCountry)
                        {
                            if (IsChina && IsNotChina)
                            {
                                sbGeographicDestination.Append("(Apto China, No apto China)");
                            }
                            else
                            {
                                if (IsChina)
                                    sbGeographicDestination.Append("(Apto China)");
                                else
                                    sbGeographicDestination.Append("(No apto China)");
                            }
                        }
                    }
                    else if (i == (GeographicDestinationSelected.Count - 2))
                    {
                        sbGeographicDestination.Append(GeographicDestinationSelected[i].Name);
                    }
                    else
                    {
                        sbGeographicDestination.Append(GeographicDestinationSelected[i].Name);
                        sbGeographicDestination.Append(", ");
                    }
                }

                for (int i = 0; i < ChoreCategoriesSelected.Count; i++)
                {
                    if (ChoreCategoriesSelected.Count == 1)
                    {
                        sbChoreCategories.Append(ChoreCategoriesSelected[i].Name);
                    }
                    else if (i == (ChoreCategoriesSelected.Count - 1))
                    {
                        sbChoreCategories.Append(" y ");
                        sbChoreCategories.Append(ChoreCategoriesSelected[i].Name);
                    }
                    else if (i == (ChoreCategoriesSelected.Count - 2))
                    {
                        sbChoreCategories.Append(ChoreCategoriesSelected[i].Name);
                    }
                    else
                    {
                        sbChoreCategories.Append(ChoreCategoriesSelected[i].Name);
                        sbChoreCategories.Append(", ");
                    }
                }

                for (int i = 0; i < SubCategoriesSelected.Count; i++)
                {
                    if (SubCategoriesSelected.Count == 1)
                    {
                        sbChoreSubCategories.Append(SubCategoriesSelected[i].Name);
                    }
                    else if (i == (SubCategoriesSelected.Count - 1))
                    {
                        sbChoreSubCategories.Append(" y ");
                        sbChoreSubCategories.Append(SubCategoriesSelected[i].Name);
                    }
                    else if (i == (SubCategoriesSelected.Count - 2))
                    {
                        sbChoreSubCategories.Append(SubCategoriesSelected[i].Name);
                    }
                    else
                    {
                        sbChoreSubCategories.Append(SubCategoriesSelected[i].Name);
                        sbChoreSubCategories.Append(", ");
                    }
                }
            }

            PreferencesObject.IsBusinessTypeBrood = IsBreedingChecked;
            PreferencesObject.IsBusinessTypeWintering = IsWinteringChecked;
            PreferencesObject.IsBusinessTypeChore = IsChoreChecked;
            PreferencesObject.TroopWeightType = IsEqualChecked;
            PreferencesObject.UnevenTroopWeightType = IsNotEqualChecked;
            PreferencesObject.WinteringCategory = sbWinteringCategories.ToString();
            PreferencesObject.ChoreCategory = sbChoreCategories.ToString();
            PreferencesObject.ChoreSubCategory = sbChoreSubCategories.ToString();
            PreferencesObject.DestinationChore = sbGeographicDestination.ToString();


            if (string.IsNullOrEmpty(MinWeightWinteringSelected) && string.IsNullOrEmpty(MaxWeightWinteringSelected))
            {
                PreferencesObject.MinWeightWintering = null;
                PreferencesObject.MaxWeightWintering = null;
            }
            else
            {
                PreferencesObject.MinWeightWintering = int.Parse(MinWeightWinteringSelected);
                PreferencesObject.MaxWeightWintering = int.Parse(MaxWeightWinteringSelected);
            }

            if (string.IsNullOrEmpty(MinWeightChoreSelected) && string.IsNullOrEmpty(MaxWeightChoreSelected))
            {
                PreferencesObject.MinWeightChore = null;
                PreferencesObject.MaxWeightChore = null;
            }
            else
            {
                PreferencesObject.MaxWeightChore = int.Parse(MaxWeightChoreSelected);
                PreferencesObject.MinWeightChore = int.Parse(MinWeightChoreSelected);
            }

            //await _profileService.AddProfilePreferences(long.Parse(_appSettings.UserId), PreferencesObject);

            string serializedData = JsonConvert.SerializeObject(PreferencesObject);

            await Shell.Current.GoToAsync($"{nameof(EditPreferencesSecondSectionPage)}?preferencesObject={serializedData}");
        }

        public void Clear()
        {
            if (!IsWinteringChecked)
            {
                IsEqualChecked = false;
                IsNotEqualChecked = false;
                WinteringCategoriesSelected.Clear();
                MinWeightWinteringSelected = string.Empty;
                MaxWeightWinteringSelected = string.Empty;

                foreach (var item in WinteringCategories)
                {
                    item.Selected = false;
                }
            }
            if (!IsChoreChecked)
            {
                ChoreCategoriesSelected.Clear();
                SubCategoriesSelected.Clear();
                GeographicDestinationSelected.Clear();
                MinWeightChoreSelected = string.Empty;
                MaxWeightChoreSelected = string.Empty;
                IsThirdCountry = false;
                IsChina = false;
                IsNotChina = false;

                foreach (var item in ChoreCategories)
                {
                    item.Selected = false;
                }

                foreach (var item in SubCategories)
                {
                    item.Selected = false;
                }

                foreach (var item in GeographicDestination)
                {
                    item.Selected = false;
                }
            }
        }

        private async Task CancelPublish()
        {
            await Shell.Current.GoToAsync("..");
        }
    }
}
