﻿using System;
using System.Threading.Tasks;

namespace TradeFood.Sandbox
{
    public interface IServiceSandbox
    {
        Task Run(Func<Task> task, bool isRunningInForeground = true);
    }
}