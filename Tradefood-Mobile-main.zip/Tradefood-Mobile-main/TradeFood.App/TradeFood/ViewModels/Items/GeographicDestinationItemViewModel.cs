﻿using System.ComponentModel;

namespace TradeFood.ViewModels.Items
{
    public class GeographicDestinationItemViewModel : INotifyPropertyChanged
    {
        public GeographicDestinationItemViewModel(string name)
        {
            Name = name;
        }
        public string Name { get; set; }

        private bool _selected;

        public bool Selected
        {
            get => _selected; 
            set
            {
                _selected = value;
                OnPropertyChanged(nameof(Selected));
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
