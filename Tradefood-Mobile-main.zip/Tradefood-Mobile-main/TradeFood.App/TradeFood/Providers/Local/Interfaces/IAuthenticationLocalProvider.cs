﻿namespace TradeFood.Providers
{
    public interface IAuthenticationLocalProvider : IAuthenticationProvider
    {
    }
}