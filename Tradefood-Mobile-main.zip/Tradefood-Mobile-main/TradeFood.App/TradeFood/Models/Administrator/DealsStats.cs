﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class DealsStats
    {
        [JsonProperty("Todos")]
        public long Todos { get; set; } = 0;

        [JsonProperty("Activos")]
        public long Activos { get; set; }

        [JsonProperty("Pausados")]
        public long Pausados { get; set; }

        [JsonProperty("Borrados")]
        public long Borrados { get; set; }
    }
}