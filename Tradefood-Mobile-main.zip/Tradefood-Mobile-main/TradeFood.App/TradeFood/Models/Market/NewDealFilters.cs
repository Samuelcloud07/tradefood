﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeFood.Models.Market
{
    public class NewDealFilters
    {
        public List<TroopCategory> CategoriesSelected { get; set; }
        public int ChoreMinWeight { get; set; }
        public int ChoreMaxWeight { get; set; }
        public int WinteringMinWeight { get; set; }
        public int WinteringMaxWeight { get; set; }
        public int MinPrice { get; set; }
        public int MaxPrice{ get; set; }
        
    }
}
