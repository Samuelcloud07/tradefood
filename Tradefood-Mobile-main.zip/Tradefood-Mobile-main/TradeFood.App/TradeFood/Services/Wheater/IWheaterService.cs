﻿using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Services
{
    public interface IWheaterService
    {
        Task<WheaterData> GetWheaterAsync(string lat, string lon);
    }
}