﻿using PropertyChanged;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.Components
{
    [SuppressPropertyChangedWarnings]
    public partial class CustomEntryComponent : Grid
    {
        private Color _colorPrimary = (Color)Application.Current.Resources["ColorPrimary"];
        private Color _colorError = (Color)Application.Current.Resources["ErrorColor"];
        private Color _colorGray = (Color)Application.Current.Resources["DarkCharcoalColor"];

        // Bindable Properties
        public static readonly BindableProperty TextProperty = BindableProperty.Create(
            nameof(Text),
            typeof(string),
            typeof(CustomEntryComponent),
            default(string),
            BindingMode.TwoWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomEntryComponent)bindable;

                view.customEntry.Text = (string)newVal;
            }
        );

        public static readonly BindableProperty PlaceholderTextProperty = BindableProperty.Create(
            nameof(PlaceholderText),
            typeof(string),
            typeof(CustomEntryComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomEntryComponent)bindable;

                view.placeholderText.Text = (string)newVal;

                if (string.IsNullOrEmpty(view.placeholderText.Text))
                {
                    view.placeholderText.IsVisible = false;
                    view.placeholderText.HeightRequest = 0;
                }
            }
        );

        public static readonly BindableProperty HelperTextProperty = BindableProperty.Create(
            nameof(HelperText),
            typeof(string),
            typeof(CustomEntryComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomEntryComponent)bindable;

                view.helperText.Text = (string)newVal;

                if (view.errorText.IsVisible)
                    view.helperText.IsVisible = false;
                else
                    view.helperText.IsVisible = !string.IsNullOrEmpty(view.helperText.Text);
            }
        );

        public static readonly BindableProperty ErrorTextProperty = BindableProperty.Create(
            nameof(ErrorText),
            typeof(string),
            typeof(CustomEntryComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomEntryComponent)bindable;

                view.errorText.Text = (string)newVal;
            }
        );

        public static readonly BindableProperty HasErrorProperty = BindableProperty.Create(
            nameof(HasError),
            typeof(bool),
            typeof(CustomEntryComponent),
            default(bool),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomEntryComponent)bindable;

                view.errorText.IsVisible = (bool)newVal;

                view.helperText.IsVisible = !view.errorText.IsVisible;

                view.placeholderText.TextColor = view.errorText.IsVisible
                    ? view._colorError : view.customEntry.IsFocused
                        ? view._colorPrimary : view._colorGray;

                view.charCounterText.TextColor = view.errorText.IsVisible
                    ? view._colorError : view._colorGray;

                view.errorIcon.IsVisible = view.errorText.IsVisible;
            }
        );

        public static readonly BindableProperty IsPasswordProperty = BindableProperty.Create(
            nameof(IsPassword),
            typeof(bool),
            typeof(CustomEntryComponent),
            default(bool),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomEntryComponent)bindable;

                view.customEntry.IsPassword = (bool)newVal;

                view.passwordIcon.IsVisible = (bool)newVal;
            }
        );

        public static readonly BindableProperty MaxLenghtProperty = BindableProperty.Create(
            nameof(MaxLenght),
            typeof(int),
            typeof(CustomEntryComponent),
            default(int),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomEntryComponent)bindable;

                view.customEntry.MaxLength = (int)newVal;

                view.charCounterText.IsVisible = view.customEntry.MaxLength > 0;

                view.charCounterText.Text = $"0 / {view.MaxLenght}";
            }
        );

        public static readonly BindableProperty ReturnCommandProperty = BindableProperty.Create(
            nameof(ReturnCommand),
            typeof(ICommand),
            typeof(CustomEntryComponent),
            default(ICommand),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (CustomEntryComponent)bindable;

                view.customEntry.ReturnCommand = (ICommand)newVal;
            }
        );

        public CustomEntryComponent()
        {
            InitializeComponent();

            this.customEntry.Text = this.Text;

            this.customEntry.TextChanged += this.OnCustomEntryTextChanged;

            this.customEntry.Completed += this.OnCustomEntryCompleted;
        }

        // Event Handlers
        public event EventHandler<EventArgs> EntryCompleted;

        public event EventHandler<TextChangedEventArgs> TextChanged;

        // Properties
        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        public string PlaceholderText
        {
            get => (string)GetValue(PlaceholderTextProperty);
            set => SetValue(PlaceholderTextProperty, value);
        }

        public string HelperText
        {
            get => (string)GetValue(HelperTextProperty);
            set => SetValue(HelperTextProperty, value);
        }

        public string ErrorText
        {
            get => (string)GetValue(ErrorTextProperty);
            set => SetValue(ErrorTextProperty, value);
        }

        public bool HasError
        {
            get => (bool)GetValue(HasErrorProperty);
            set => SetValue(HasErrorProperty, value);
        }

        public bool IsPassword
        {
            get => (bool)GetValue(IsPasswordProperty);
            set => SetValue(IsPasswordProperty, value);
        }

        public int MaxLenght
        {
            get => (int)GetValue(MaxLenghtProperty);
            set => SetValue(MaxLenghtProperty, value);
        }

        public Keyboard Keyboard
        {
            set => this.customEntry.Keyboard = value;
        }

        public ReturnType ReturnType
        {
            set => this.customEntry.ReturnType = value;
        }

        public ICommand ReturnCommand
        {
            get => (ICommand)GetValue(ReturnCommandProperty);
            set => SetValue(ReturnCommandProperty, value);
        }

        // Methods
        private async Task ControlFocused()
        {
            if (string.IsNullOrEmpty(this.customEntry.Text) || this.customEntry.Text.Length > 0)
            {
                this.customEntry.Focus();

                this.underline.Color = _colorPrimary;
                this.helperText.TextColor = _colorPrimary;
                this.charCounterText.TextColor = _colorPrimary;

                this.placeholderText.TextColor = _colorPrimary;
                this.placeholderText.FontSize = 14;
                this.placeholderText.FontFamily = "Poppins_Light";

                int y = DeviceInfo.Platform == DevicePlatform.UWP ? -25 : -20;

                await this.placeholderText.TranslateTo(0, y, 100, Easing.Linear);

                this.placeholderText.HorizontalOptions = LayoutOptions.Start;
            }
            else
                await this.ControlUnfocused();
        }

        private async Task ControlUnfocused()
        {
            this.underline.Color = _colorGray;

            this.placeholderText.TextColor = this.HasError ? _colorError : _colorGray;
            this.charCounterText.TextColor = this.HasError ? _colorError : _colorGray;
            
            this.helperText.TextColor = _colorGray;

            this.customEntry.Unfocus();

            if (string.IsNullOrEmpty(this.customEntry.Text) || this.customEntry.MaxLength <= 0)
            {
                await this.placeholderText.TranslateTo(0, 0, 100, Easing.Linear);

                this.placeholderText.HorizontalOptions = LayoutOptions.FillAndExpand;

                this.placeholderText.FontSize = 16;
                this.placeholderText.FontFamily = "Poppins_Regular";
                this.placeholderText.TextColor = _colorGray;
            }
        }

        private void CustomEntryFocused(object sender, FocusEventArgs e)
        {
            if (e.IsFocused)
                MainThread.BeginInvokeOnMainThread(async () => await this.ControlFocused());
        }

        private void CustomEntryUnfocused(object sender, FocusEventArgs e)
        {
            if (!e.IsFocused)
                MainThread.BeginInvokeOnMainThread(async () => await this.ControlUnfocused());
        }

        private void CustomEntry_Tapped(object sender, EventArgs e)
        {
            MainThread.BeginInvokeOnMainThread(async () => await this.ControlFocused());
        }

        private void PasswordEyeTapped(object sender, EventArgs e)
        {
            this.customEntry.IsPassword = !this.customEntry.IsPassword;
        }

        private void OnCustomEntryTextChanged(object sender, TextChangedEventArgs e)
        {
            this.Text = e.NewTextValue;

            if (this.charCounterText.IsVisible)
                this.charCounterText.Text = $"{this.customEntry.Text.Length} / {this.MaxLenght}";

            this.TextChanged?.Invoke(this, e);
        }

        private void OnCustomEntryCompleted(object sender, EventArgs e)
        {
            this.EntryCompleted?.Invoke(this, EventArgs.Empty);
        }
    }
}