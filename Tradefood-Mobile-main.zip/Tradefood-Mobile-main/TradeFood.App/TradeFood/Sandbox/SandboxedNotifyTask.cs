﻿using TradeFood.ViewModels;
using System;
using System.Threading.Tasks;

namespace TradeFood.Sandbox
{
    public static class SandboxedNotifyTask
    {
        private static readonly Lazy<IServiceSandbox> serviceSandbox = new Lazy<IServiceSandbox>(() => TypeLocator.Resolve<IServiceSandbox>());

        public static NotifyTask Create(Func<Task> task, Action<Exception> onException = null) => NotifyTask.Create(() => serviceSandbox.Value.Run(task), onException);
    }
}