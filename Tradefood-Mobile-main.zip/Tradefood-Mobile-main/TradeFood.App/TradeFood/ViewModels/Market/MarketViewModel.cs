﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Enums;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Sandbox;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views;
using TradeFood.Views.Market;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class MarketViewModel : BaseViewModel
    {
        private readonly IDealsService _dealsService;
        private readonly IAppSettings _appSettings;
        private readonly IDialogsHelper _dialogsHelper;

        private List<Deal> _deals = new List<Deal>();

        public MarketViewModel(ILogger logger,
                               IDealsService dealsService,
                               IAppSettings appSettings,
                               IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _dealsService = dealsService;
            _appSettings = appSettings;
            _dialogsHelper = dialogsHelper;

            CreateNewBusinessCommand = new SandboxedCommand(CreateNewBusiness);

            ShowAllDealsCommand = new SandboxedCommand(ShowAllDeals);

            ShowMyDealsCommand = new SandboxedCommand(ShowMyDeals);

            OpenDealFiltersCommand = new SandboxedCommand(OpenDealFilters);
        }

        protected override Task InitializeAsync()
        {
            UserName = _appSettings.UserName;

            return base.InitializeAsync();
        }

        public override void OnAppearing()
        {
            Title = "Prenegocios disponibles";

            this.LoadTask = SandboxedNotifyTask.Create(() => GetDeals());

            ShowAllDealsSelected = !ShowMyDealsSelected;
        }

        // Properties
        public string Title { get; private set; }

        public ObservableCollection<DealItemViewModel> Deals { get; private set; } = new ObservableCollection<DealItemViewModel>();

        public string UserName { get; private set; }

        public ClientType ClientType { get; private set; }

        public bool ShowAllDealsSelected { get; private set; }

        public bool ShowMyDealsSelected { get; private set; }

        // Commands
        public SandboxedCommand CreateNewBusinessCommand { get; private set; }

        public SandboxedCommand ShowAllDealsCommand { get; private set; }

        public SandboxedCommand ShowMyDealsCommand { get; private set; }

        public SandboxedCommand OpenDealFiltersCommand { get; private set; }

        // Methods
        private async Task GetDeals()
        {
            Deals.Clear();

            _dialogsHelper.ShowDialog();

            _deals = await _dealsService.GetAllDealsAsync();

            var deals = _deals.Where(d => d.CreatedBy != _appSettings.UserId).ToList();

            foreach (var deal in deals)
                Deals.Add(new DealItemViewModel(deal, ClientType));

            _dialogsHelper.HideDialog();
        }

        private Task<bool> ShowAllDeals()
        {
            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();

            Title = "Prenegocios disponibles";

            Deals.Clear();

            _dialogsHelper.ShowDialog();

            ShowAllDealsSelected = true;

            ShowMyDealsSelected = false;

            var deals = _deals.Where(d => d.CreatedBy != _appSettings.UserId).ToList();

            foreach (var deal in deals)
                Deals.Add(new DealItemViewModel(deal, ClientType));

            _dialogsHelper.HideDialog();

            tcs.SetResult(true);

            return tcs.Task;
        }

        private Task<bool> ShowMyDeals()
        {
            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();

            Title = "Tus prenegocios";

            Deals.Clear();

            _dialogsHelper.ShowDialog();

            ShowAllDealsSelected = false;

            ShowMyDealsSelected = true;

            var deals = _deals.Where(d => d.CreatedBy == _appSettings.UserId).ToList();

            foreach (var deal in deals)
                Deals.Add(new DealItemViewModel(deal, ClientType));

            _dialogsHelper.HideDialog();

            tcs.SetResult(true);

            return tcs.Task;
        }

        private async Task OpenDealFilters() => await Shell.Current.GoToAsync(nameof(DealsFiltersPage));

        private async Task CreateNewBusiness() => await Shell.Current.GoToAsync(nameof(NewPublishFirstStepPage));
    }
}