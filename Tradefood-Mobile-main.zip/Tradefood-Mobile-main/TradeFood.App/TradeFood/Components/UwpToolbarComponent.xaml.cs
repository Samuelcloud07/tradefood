﻿using Rg.Plugins.Popup.Services;
using System.Globalization;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Converters;
using TradeFood.Models;
using TradeFood.Services;
using TradeFood.Settings;
using TradeFood.ViewModels;
using TradeFood.Views;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.Components
{
    public partial class UwpToolbarComponent : Grid
    {
        private readonly IAppSettings _appSettings;

        // Bindable Properties
        public static readonly BindableProperty ToolbarTitleProperty = BindableProperty.Create(
            nameof(ToolbarTitle),
            typeof(string),
            typeof(UwpToolbarComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (UwpToolbarComponent)bindable;

                view.titleLabel.Text = (string)newVal;

                view.titleLabel.IsVisible = !string.IsNullOrEmpty(view.titleLabel.Text);
            }
        );

        public UwpToolbarComponent()
        {
            InitializeComponent();

            this.BindingContext = this;

            _appSettings = TypeLocator.Resolve<IAppSettings>();

            this.currentTemp.Text = $"{_appSettings.CurrentTemp}º";

            this.usernameLabel.Text = _appSettings.UserName;

            var conv = new DisplayNameToInitialsConverter();

            this.initialsLabel.Text = (string)conv.Convert(_appSettings.UserName, typeof(string), null, CultureInfo.CurrentCulture);

            this.initialsLabel.BindingContext = _appSettings.UserName;

            OpenChatbotCommand = new SandboxedCommand(OpenChatbot);

        }

        // Properties
        public string ToolbarTitle
        {
            get => (string)GetValue(ToolbarTitleProperty);
            set => SetValue(ToolbarTitleProperty, value);
        }

        public WheaterData WeatherData { get; private set; }

        // Commands
        public SandboxedCommand OpenChatbotCommand { get; private set; }

        
        // Methods       

        private async Task OpenChatbot() => await Shell.Current.GoToAsync(nameof(InquiriesPage));
        
    }
}