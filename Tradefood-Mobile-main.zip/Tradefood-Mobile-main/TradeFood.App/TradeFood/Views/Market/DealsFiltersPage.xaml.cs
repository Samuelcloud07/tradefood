﻿using Acr.UserDialogs;
using TradeFood.Helpers;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels.Market;
using Xamarin.Forms;

namespace TradeFood.Views.Market
{
    public partial class DealsFiltersPage : BasePage
    {
        private DealsFiltersViewModel _vm;
        public DealsFiltersPage()
        {
            InitializeComponent();
            _vm = new DealsFiltersViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<IDealsService>(),
                TypeLocator.Resolve<IStatesService>(),
                TypeLocator.Resolve<IMediaHelper>(),
                TypeLocator.Resolve<IDialogsHelper>(),
                TypeLocator.Resolve<IAppSettings>(),
                TypeLocator.Resolve<IUserDialogs>());
            this.BindingContext = _vm;

            DestinationCollectionView.ItemsSource = new string[]
            {
                "UE Hilton",
                "UE no Hilton",
                "Cuota 481",
                "Terceros países/Consumo",
                "Apto China",
                "No apto China"
            };

            TypeCollectionView.ItemsSource = new string[]
            {
                "Gorda",
                "Carnicera",
                "Manufactura",
                "Conserva",
                "Popurrí"
            };
        }

        private void Tap_Handler(object sender, System.EventArgs e)
        {
            _vm.BusinessTypeSelected = (sender as Label).Text;

            if (!_vm.ShowForm)
                _vm.ShowForm = true;
        }
    }
}