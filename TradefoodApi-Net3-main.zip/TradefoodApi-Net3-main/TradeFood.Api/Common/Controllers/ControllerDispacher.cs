﻿using Common.Exceptions;
using Common.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace Common.Controllers
{
    public class ControllerDispacher
    {
        private const string UnexpectedErrorMessage = "Lo sentimos. Se ha producido un error inesperado, estamos trabajando para solucionarlo a la brevedad.";
        private const string FatalErrorHttpResult = "fatal-error";
        private const string ErrorHttpResult = "error";

        public static async Task<Response<T>> DispatchResponse<T>(Func<Task<T>> method, ILogger<BaseController> logger)
        {
            Response<T> response;

            try
            {
                var result = await method.Invoke();

                response = new Response<T>
                {
                    Data = result,
                    Result = "Success",
                    HttpCode = HttpStatusCode.OK
                };
            }
            catch (ForbiddenException forbiddenException)
            {
                response = new Response<T>
                {
                    Result = ErrorHttpResult,
                    HttpCode = HttpStatusCode.Forbidden,
                    ErrorMessage = "No tiene permiso para realizar esta acción",
                };

                logger.LogInformation(forbiddenException, $"{forbiddenException.Message} - {forbiddenException.InnerException.Message}");
            }
            catch (NotFoundException notFoundException)
            {
                response = new Response<T>
                {
                    Result = FatalErrorHttpResult,
                    HttpCode = HttpStatusCode.NotFound
                };

                logger.LogWarning(notFoundException, notFoundException.Message);
            }
            catch (BadRequestException)
            {
                response = new Response<T>
                {
                    Result = FatalErrorHttpResult,
                    HttpCode = HttpStatusCode.BadRequest,
                    ErrorMessage = UnexpectedErrorMessage
                };
            }
            catch (ServiceException serviceException)
            {
                response = new Response<T>
                {
                    ErrorMessage = serviceException.Message,
                    Result = ErrorHttpResult,
                    HttpCode = HttpStatusCode.BadRequest
                };

                logger.LogError(serviceException, serviceException.Message);
            }
            catch (JsonReaderException jsonReaderException)
            {
                response = new Response<T>
                {
                    Result = FatalErrorHttpResult,
                    ErrorMessage = UnexpectedErrorMessage,
                    HttpCode = HttpStatusCode.InternalServerError
                };

                logger.LogCritical(jsonReaderException, jsonReaderException.Message);
            }
            catch (Exception exception)
            {
                response = new Response<T>
                {
                    Result = FatalErrorHttpResult,
                    ErrorMessage = UnexpectedErrorMessage,
                    HttpCode = HttpStatusCode.InternalServerError
                };

                logger.LogError(exception, exception.Message);
            }

            return response;
        }

        public static async Task<HttpResponseMessage> DispatchResponse(Func<Task<HttpResponseMessage>> method, ILogger<BaseController> logger)
        {
            try
            {
                var result = await method.Invoke();

                return result;
            }
            catch (Exception exception)
            {
                logger.LogError(exception, exception.Message);

                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }
    }
}