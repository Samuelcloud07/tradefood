﻿using Xamarin.Forms;

namespace TradeFood.Views
{
    public partial class AdministratorMainPage : FlyoutPage
    {
        public AdministratorMainPage()
        {
            InitializeComponent();
        }
    }
}