﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeFood.Providers;

namespace TradeFood.Providers
{ 
    interface IProfileApiProvider : IProfileProvider
    {
    }
}
