﻿namespace TradeFood.Models
{
    public interface IComparableByUniqueProperty
    {
        /// <summary>
        /// Igualado que compara por una propiedad única que representa la clase T.
        /// </summary>
        /// <returns>
        /// <c>true</c> si la propiedad única es igual en ambos, en caso contrario retorna <c>false</c>.
        /// </returns>
        /// <param name="compareTo">El objeto a comparar.</param>
        bool EqualsByUniqueProperty(IComparableByUniqueProperty compareTo);
    }
}