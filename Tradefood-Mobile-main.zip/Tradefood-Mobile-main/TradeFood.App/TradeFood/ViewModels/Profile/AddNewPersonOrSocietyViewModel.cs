﻿using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Extensions;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views.Popups;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class AddNewPersonOrSocietyViewModel : BaseViewModel
    {
        private readonly IAppSettings _appSettings;
        private readonly IProfileService _profileService;
        private readonly IStatesService _statesServices;
        private readonly IDialogsHelper _dialogsHelper;


        long UserId = 0;
        public AddNewPersonOrSocietyViewModel(ILogger logger,
                                             IAppSettings appSettings,
                                             IProfileService profileService,
                                             IStatesService statesService,
                                             IDialogsHelper dialogsHelper) : base(logger)
        {
            _appSettings = appSettings;
            _profileService = profileService;
            _statesServices = statesService;
            _dialogsHelper = dialogsHelper;

            SelectProvinceCommand = new SandboxedCommand(SelectProvince);

            SaveNewSocietyOrPersonCommand = new SandboxedCommand(SaveNewSocietyOrPerson);
        }
        protected override async Task InitializeAsync()
        {
            _dialogsHelper.ShowDialog();

            Provinces = await _statesServices.GetProvincesAsync();

            await base.InitializeAsync();

            UserId = (long)Convert.ToDouble(_appSettings.UserId);

            _dialogsHelper.HideDialog();
        }

        //Properties
        public List<ProvinceLocation> Provinces { get; private set; } = new List<ProvinceLocation>();
        public List<ProvinceLocation> Locations { get; private set; } = new List<ProvinceLocation>();
        public ProvinceLocation ProvinceSelected { get; set; }
        public ProvinceLocation LocationSelected { get; set; }

        public bool IsPerson { get; set; } = false;
        public bool IsSocieties { get; set; } = false;

        public string _societyOrFullName;
        public string SocietyOrFullName
        {
            get => _societyOrFullName;
            set
            {
                _societyOrFullName = value;

                this.OnPropertyChanged(nameof(SocietyOrFullName));

                switch (_societyOrFullName)
                {
                    case ("Sociedad"):
                        ShowNameOrSociety = "Razón social de la Sociedad*";
                        IsPerson = false;
                        IsSocieties = true;
                        Console.WriteLine(IvaConditionSelected);
                        break;

                    case ("Persona"):
                        ShowNameOrSociety = "Nombre y apellido*";
                        IsPerson = true;
                        IsSocieties = false;
                        break;
                }
                ShowForm = true;
            }
        }
        public bool ShowForm { get; set; } = false;
        public string ShowNameOrSociety { get; set; }
        
        //Razon social
        public string Type { get; set; }
        public string Name { get; set; }
        public string Cuit { get; set; }
        public string ReferencesComercial { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public IList<AddressDto> Addresses { get; set; }
        //Direccion de razon social
        public string State { get; set; }
        public string Location { get; set; }
        public string Street { get; set; }
        public int? Number { get; set; }
        public bool WithoutNumber { get; set; }
        public string ZipCode { get; set; }
        public string FloorDepartment { get; set; }
        public string Observations { get; set; }

        //Personas fisicas
        public bool? Monotributist { get; set; } //Condicion frente al IVA
        public bool? resInsc { get; set; }
        //Persona fisica
        public string IvaConditionSelected { get; set; }

        public bool HasErrors { get; set; }
        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();

        //Commands
        public SandboxedCommand SaveNewSocietyOrPersonCommand { get; private set; }
        public SandboxedCommand SelectProvinceCommand { get; private set; }
        public SandboxedCommand AddAddressCommand { get; private set; }


        //Methods

        private bool ValidateAll()
        {
            Errors.Clear();

            // Colocar validaciones
            if (String.IsNullOrEmpty(Name))
            {
                if (SocietyOrFullName == "Sociedad")
                {
                    Errors.Add(nameof(Name), Strings.YouMustEnterABusinessName);
                }

                if (SocietyOrFullName =="Persona")
                {
                    Errors.Add(nameof(Name),Strings.YouMustEnterAName);
                }
            }

            if (String.IsNullOrEmpty(Cuit))
            {
                Errors.Add(nameof(Cuit), Strings.YouMustEnterACuit);
            }

            if (IsSocieties)
            {
                if (String.IsNullOrEmpty(ReferencesComercial))
                {
                    Errors.Add(nameof(ReferencesComercial), Strings.YouMustEnterAReferencesComercial);
                }
                
                if (String.IsNullOrEmpty(Email))
                {
                    Errors.Add(nameof(Email), Strings.YouMustEnterAEmail);
                }
                else if (!Email.IsValidEmail())
                {
                    Errors.Add(nameof(Email), Strings.TheEmailAddressIsInvalid);
                }

                if (String.IsNullOrEmpty(ContactNumber))
                {
                    Errors.Add(nameof(ContactNumber), Strings.YouMustEnterAContactNumber);
                }
            }

            if (ProvinceSelected == null)
            {
                Errors.Add(nameof(ProvinceSelected), Strings.YouMustEnterAProvince);
            }

            if (LocationSelected == null)
            {
                Errors.Add(nameof(LocationSelected), Strings.YouMustEnterALocation);
            }

            if (String.IsNullOrEmpty(Street))
            {
                Errors.Add(nameof(Street), Strings.YouMustEnterAStreet);
            }

            if (Number == null)
            {
                Errors.Add(nameof(Number), Strings.YouMustEnterANumber);
            }

            if (String.IsNullOrEmpty(ZipCode))
            {
                Errors.Add(nameof(ZipCode), Strings.YouMustEnterAZipCode);
            }
            //---------------------------------------

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }
        public async Task SelectProvince()
        {
            _dialogsHelper.ShowDialog();
            Locations = await _statesServices.GetLocationsForProvinceAsync(ProvinceSelected.Name);
            _dialogsHelper.HideDialog();
        }

        private async Task SaveNewSocietyOrPerson()
        {
            if (!ValidateAll())
                return;

            //await AddNewSocietyOrPerson();
            if (SocietyOrFullName == "Sociedad")
            {
                var addressdto = new AddressDto
                {
                    State = ProvinceSelected.Name,
                    Location = LocationSelected.Name,
                    Street = Street,
                    Number = (int)Number,
                    WithoutNumber = WithoutNumber,
                    ZipCode = ZipCode,
                    FloorDepartment = FloorDepartment,
                    Observations = Observations
                };

                var societiesandperdons = new SocietiesAndPersonDto
                {
                    Type = (Enums.TypeSocieties)1,
                    Name = Name,
                    Cuit = Cuit,
                    CommercialReference = ReferencesComercial,
                    Email = Email,
                    ContactNumber = ContactNumber,
                    Addresses = new List<AddressDto>()
                };

                societiesandperdons.Addresses.Add(addressdto);

                if (await _dialogsHelper.ShowConfirmAsync("¿Deseas agregar esta nueva razón social a tu perfil?.", "Nueva persona física"))
                    await _profileService.AddSocietiesAndPersonsAsync(UserId, societiesandperdons);

            }
            else
            {
                var addressdto = new AddressDto
                {
                    State = ProvinceSelected.Name,
                    Location = LocationSelected.Name,
                    Street = Street,
                    Number = (int)Number,
                    WithoutNumber = WithoutNumber,
                    ZipCode = ZipCode,
                    FloorDepartment = FloorDepartment,
                    Observations = Observations
                };

                var societiesandperdons = new SocietiesAndPersonDto
                {
                    Type = (Enums.TypeSocieties)0,
                    Name = Name,
                    Cuit = Cuit,
                    Addresses = new List<AddressDto>(),
                };

                if (Monotributist == true)
                    societiesandperdons.Monotributist = true;
                else
                    societiesandperdons.Monotributist = false;

                societiesandperdons.Addresses.Add(addressdto);

                if(await _dialogsHelper.ShowConfirmAsync("¿Deseas agregar esta nueva persona física a tu perfil?.", "Nueva persona física"))
                    await _profileService.AddSocietiesAndPersonsAsync(UserId, societiesandperdons);

            }

            MessagingCenter.Send<AddNewPersonOrSocietyViewModel>(this, "SociedadAgregada");

            await Shell.Current.GoToAsync("..");
        }
        
    }
}