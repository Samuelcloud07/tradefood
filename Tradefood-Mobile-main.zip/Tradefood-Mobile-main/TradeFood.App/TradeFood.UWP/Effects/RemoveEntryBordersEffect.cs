﻿using System;
using TradeFood.UWP.Effects;
using Windows.UI.Xaml.Controls;
using Xamarin.Forms;
using Xamarin.Forms.Platform.UWP;

[assembly: ResolutionGroupName("TradeFood")]
[assembly: ExportEffect(typeof(RemoveEntryBordersEffect), nameof(RemoveEntryBordersEffect))]
namespace TradeFood.UWP.Effects
{
    public class RemoveEntryBordersEffect : PlatformEffect
    {
        protected override void OnAttached()
        {
            if (this.Control is FormsComboBox)
                return;

            var textBox = this.Control as TextBox;

            if (textBox is null)
                throw new NotImplementedException();

            textBox.BorderThickness = new Windows.UI.Xaml.Thickness(0);
            textBox.BorderBrush = Color.White.ToBrush();
        }

        protected override void OnDetached()
        {
        }
    }
}