﻿using Newtonsoft.Json;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Extensions;
using TradeFood.Helpers;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    class ForgetPasswordViewModel : BaseViewModel
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IDialogsHelper _dialogsHelper;

        public ForgetPasswordViewModel(ILogger logging,
                                       IAuthenticationService authenticationService,
                                       IDialogsHelper dialogsHelper)
            : base(logging)
        {
            SendCodeCommand = new SandboxedCommand(SendCode);

            GoBackCommand = new SandboxedCommand(GoBack);
            _authenticationService = authenticationService;
            _dialogsHelper = dialogsHelper;
        }

        // Properties
        public string EmailToValidate { get; set; }

        public bool EmailError { get; private set; }

        // Commands
        public SandboxedCommand SendCodeCommand { get; private set; }

        public SandboxedCommand GoBackCommand { get; private set; }

        // Methods
        private async Task SendCode()
        {
            if (string.IsNullOrEmpty(EmailToValidate) || !EmailToValidate.IsValidEmail())
            {
                EmailError = true;

                return;
            }

            _dialogsHelper.ShowDialog();

            var requestPasswordReset = await _authenticationService.RequestPasswordResetAsync(EmailToValidate);

            _dialogsHelper.HideDialog();

            var serializedPasswordReset = JsonConvert.SerializeObject(requestPasswordReset);

            await Shell.Current.GoToAsync($"PasswordRecovery?requestNewPassword={serializedPasswordReset}");
        }

        private async Task GoBack() => await Shell.Current.GoToAsync("..");
    }
}