﻿using System.ComponentModel;
using TradeFood.Settings;

namespace TradeFood.ViewModels
{
    public class AddressItemViewModel : INotifyPropertyChanged
    {
        private readonly IAppSettings _appSettings;
        public AddressItemViewModel(long id, string street, string number, string location, string province, string zipCode) : this()
        {
            Id = id;
            Street = street;
            Number = number;
            Province = province;
            Location = location;
            ZipCode = zipCode;
            CompleteAddress = $"{Street} {Number} {FloorDepartment}\n{Location},{Province} ({ZipCode})";
        }

        public AddressItemViewModel(string street, string number, string location, string province, string zipCode) : this()
        {
            Street = street;
            Number = number;
            Province = province;
            Location = location;
            ZipCode = zipCode;
            CompleteAddress = $"{Street} {Number} {FloorDepartment}\n{Location},{Province} ({ZipCode})";
        }
        public AddressItemViewModel(string street, string number, string location, string floorDepartment, string province, string zipCode,string observations) : this()
        {
            Street = street;
            Number = number;
            FloorDepartment = floorDepartment;
            Province = province;
            Location = location;
            ZipCode = zipCode;
            Observations = observations;
            CompleteAddress = $"{Street} {Number} {FloorDepartment}\n{Location},{Province} ({ZipCode})";
        }

        public AddressItemViewModel()
        {
            _appSettings = TypeLocator.Resolve<IAppSettings>();
        }
        //Properties
        public long Id { get; set; }
        public string CompleteAddress { get; set; }
        public string FloorDepartment { get; set; }
        public string Street { get; set; }
        public string Number { get; set; }
        public string Province { get; set; }
        public string Location { get; set; }
        public string ZipCode { get; set; }
        public string Observations { get; set; }
        public bool Selected { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void RaisePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        public bool ObservationsValidate => !string.IsNullOrEmpty(Observations);
        public string FullAddress => $"{Street} {Number} {FloorDepartment}, {Location}-{Province} ({ZipCode}) ";

        public string AddressLabel
        {
            get
            {
                if (_appSettings.ClientType == "Comisionista" || _appSettings.ClientType == "Productor_Persona")
                {
                    return "Domicilio de la hacienda:";
                }
                else
                {
                    return "Domicilio de la razón social:";
                }

            }
        }



    }
}
