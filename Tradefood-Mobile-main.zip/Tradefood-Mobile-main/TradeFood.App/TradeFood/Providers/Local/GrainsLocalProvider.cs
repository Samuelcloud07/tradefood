﻿using System.Threading.Tasks;
using TradeFood.Exceptions;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class GrainsLocalProvider : IGrainsLocalProvider
    {
        public Task<GrainData> GetGrainsQuotationAsync()
        {
            throw new NoInternetException();
        }
    }
}