﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Enums;
using TradeFood.Exceptions;
using TradeFood.Models;
using TradeFood.Models.Market.Dtos;
using TradeFood.Repositories;

namespace TradeFood.Providers
{
    public class DealsLocalProvider : IDealsLocalProvider
    {
        private readonly IPreBusinessRepository _preBusinessRepository;

        public DealsLocalProvider(IPreBusinessRepository preBusinessRepository)
        {
            _preBusinessRepository = preBusinessRepository;
        }

        public async Task<List<Deal>> GetAllDealsAsync()
        {
            List<Deal> deals = new List<Deal>();

            var preBusinesses = await this.GetAllPreBusinessesFromDb();

            foreach (var preBusiness in preBusinesses)
            {
                List<File> evidenceFiles = new List<File>();

                foreach (var path in preBusiness.EvidencePaths)
                    evidenceFiles.Add(new File { FilePath = path });

                var deal = new Deal
                {
                    
                    DealId = preBusiness.DealId,
                    DealStatus = (DealStatus)Enum.Parse(typeof(DealStatus), preBusiness.DealStatus),
                    TroopCategory = preBusiness.TroopCategory,
                    //TroopType = preBusiness.TroopType,
                    Amount = preBusiness.Amount,
                    Destination = preBusiness.Destination,
                    GeographicDestination = preBusiness.GeographicDestination,
                    WeightAmount = preBusiness.WeightAmount,
                    EvidenceFiles = evidenceFiles,
                    Comments = preBusiness.Comments,
                    SuggestedPrice = preBusiness.SuggestedPrice,
                    PaymentMethod = preBusiness.PaymentMethod,
                    FinancingCategory = preBusiness.FinancingCategory,
                    Province = preBusiness.Province,
                    Location = preBusiness.Location,
                    FromDate = preBusiness.FromDate,
                    ToDate = preBusiness.ToDate,
                    PersonInCharge = preBusiness.PersonInCharge
                    
                };

                deals.Add(deal);
            }

            return deals;
        }

        public Task<string> BeginFileUploadAsync(string fileName)
        {
            throw new NoInternetException();
        }

        public Task<Deal> CreateDealAsync(string userId, DealRequest deal)
        {
            throw new NoInternetException();
        }

        public Task<bool> EndFileUploadAsync(string fileHandle, long fileSize, string dealId, bool isThumbnail)
        {
            throw new NoInternetException();
        }

        public async Task<List<Deal>> PersistDealsAsync(IEnumerable<Deal> deals)
        {
            List<PreBusiness> preBusinesses = new List<PreBusiness>();

            foreach (var deal in deals)
            {
                List<string> evidenceFiles = new List<string>();

                foreach (var filePath in deal.EvidenceFiles)
                    evidenceFiles.Add(filePath.FilePath);

                var preBusiness = new PreBusiness
                {
                    /*
                    DealId = deal.DealId,
                    DealStatus = deal.DealStatus.ToString(),
                    TroopCategory = deal.TroopCategory,
                    TroopType = deal.TroopType,
                    Amount = deal.Amount,
                    Destination = deal.Destination,
                    GeographicDestination = deal.GeographicDestination,
                    WeightAmount = deal.WeightAmount,
                    EvidencePaths = evidenceFiles,
                    Comments = deal.Comments,
                    SuggestedPrice = deal.SuggestedPrice,
                    PaymentMethod = deal.PaymentMethod,
                    FinancingCategory = deal.FinancingCategory,
                    Province = deal.Province,
                    Location = deal.Location,
                    FromDate = deal.FromDate,
                    ToDate = deal.ToDate,
                    PersonInCharge = deal.PersonInCharge
                    */
                };
            }

            await _preBusinessRepository.PersistPreBusinessesAsync(preBusinesses);

            return new List<Deal>(deals);
        }

        public Task<bool> UploadChunkAsync(MediaChunk mediaChunk)
        {
            throw new NoInternetException();
        }

        private Task<List<PreBusiness>> GetAllPreBusinessesFromDb()
        {
            return _preBusinessRepository.GetAllPreBusinessAsync();
        }

        public Task<DealDto> CreateChoreDealAsync(string userId, DealDto deal)
        {
            throw new NoInternetException();
        }

        public Task<DealDto> CreateWinteringDealAsync(string userId, DealDto deal)
        {
            throw new NoInternetException();
        }

        public Task<List<DealApiDto>> GetDealsAsync()
        {
            throw new NoInternetException("mensajeeeee: ");
        }

        public Task<DealsStats> GetDealsStats()
        {
            throw new NoInternetException();
        }
    }
}