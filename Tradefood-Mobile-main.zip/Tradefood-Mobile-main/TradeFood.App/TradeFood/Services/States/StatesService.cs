﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Providers;

namespace TradeFood.Services
{
    public class StatesService : IStatesService
    {
        private readonly IProviderFactory _providerFactory;

        public StatesService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }

        public Task<List<ProvinceLocation>> GetProvincesAsync()
        {
            return _providerFactory.Create<IStatesProvider>().GetProvincesAsync();
        }

        public Task<List<ProvinceLocation>> GetLocationsForProvinceAsync(string provincia)
        {
            return _providerFactory.Create<IStatesProvider>().GetLocationsForProvinceAsync(provincia);
        }
    }
}