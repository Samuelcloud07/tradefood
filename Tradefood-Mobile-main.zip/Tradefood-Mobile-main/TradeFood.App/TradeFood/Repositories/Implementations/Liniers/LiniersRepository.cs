﻿using SQLite;
using SQLiteNetExtensions.Extensions;
using SQLiteNetExtensionsAsync.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Repositories
{
    public class LiniersRepository : BaseSQLiteRepository<LiniersData>, ILiniersRepository
    {
        private readonly ISQLiteAdapter _adapter;

        public LiniersRepository(ISQLiteAdapter adapter)
            : base(adapter)
        {
            _adapter = adapter;
        }

        public async Task<List<LiniersData>> GetLiniersQuotesByCategoryAsync(string category)
        {
            var linierQuotes = await _adapter.Connection.Table<LiniersData>()
                                                    .Where(lq => lq.Category == category)
                                                    .ToListAsync()
                                                    .ConfigureAwait(false);

            foreach (var linierQuote in linierQuotes)
                await _adapter.Connection.GetChildrenAsync(linierQuote, true).ConfigureAwait(false);

            return linierQuotes;
        }

        public async Task<List<LiniersData>> PersistLiniersDataAsync(IEnumerable<LiniersData> liniersData)
        {
            await _adapter.Connection.RunInTransactionAsync(
                (SQLiteConnection conn) =>
                {
                    var today = DateTime.Today.ToString("yyyy-MM-dd");

                    var todayQuotesSaved = conn.Query<LiniersData>($"SELECT * FROM LiniersData WHERE date(Date) = date('{today}')");

                    var quotesToSave = liniersData.Where(lq => !todayQuotesSaved.Any(lqs => lqs.Date == lq.Date)).ToList();

                    if (quotesToSave != null)
                        conn.InsertAllWithChildren(quotesToSave, true);
                }).ConfigureAwait(false);

            return new List<LiniersData>(liniersData);
        }
    }
}