﻿using System.Collections.Generic;
using System.Linq;

namespace TradeFood.Extensions
{
    public static class CollectionExtensions
    {
        public static void AddRange<TObject>(this IList<TObject> source, IEnumerable<TObject> newItems)
        {
            foreach (var item in newItems)
                source.Add(item);
        }

        public static void RemoveRange<TObject>(this IList<TObject> source, int index)
        {
            for (int i = index; i < source.Count; i++)
                source.RemoveAt(i);
        }

        public static bool IsNullOrEmpty<T>(this IEnumerable<T> source)
        {
            return !(source?.Any() ?? false);
        }
    }
}