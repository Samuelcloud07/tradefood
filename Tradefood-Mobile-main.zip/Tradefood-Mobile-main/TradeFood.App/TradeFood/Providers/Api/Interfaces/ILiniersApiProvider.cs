﻿namespace TradeFood.Providers
{
    public interface ILiniersApiProvider : ILiniersProvider
    {
    }
}