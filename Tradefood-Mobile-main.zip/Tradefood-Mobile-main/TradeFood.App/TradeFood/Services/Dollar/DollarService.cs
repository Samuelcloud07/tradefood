﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Providers;

namespace TradeFood.Services
{
    public class DollarService : IDollarService
    {
        private readonly IProviderFactory _providerFactory;

        public DollarService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }

        public Task<List<DollarData>> GetDollarQuotesAsync()
        {
            return _providerFactory.Create<IDollarProvider>().GetDollarQuotesAsync();
        }
    }
}