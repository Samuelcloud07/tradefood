﻿using Newtonsoft.Json;

namespace TradeFood.Models
{
    public class ProfileStats
    {
        [JsonProperty("Todos")]
        public long Todos { get; set; } = 0;

        [JsonProperty("Productor")]
        public long Productor { get; set; }

        [JsonProperty("Comisionista")]
        public long Comisionista { get; set; }

        [JsonProperty("Consignataria")]
        public long Consignataria { get; set; }

        [JsonProperty("Frigorifico")]
        public long Frigorifico { get; set; }
    }
}