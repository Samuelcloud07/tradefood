﻿using System;
using Xamarin.Essentials;

namespace TradeFood.Settings
{
    public class AppSettings : IAppSettings
    {
        public string UserName
        {
            get => Preferences.Get(nameof(UserName), string.Empty);
            set => Preferences.Set(nameof(UserName), value);
        }

        public string UserId
        {
            get => Preferences.Get(nameof(UserId), string.Empty);
            set => Preferences.Set(nameof(UserId), value);
        }

        public string UserEmail
        {
            get => Preferences.Get(nameof(UserEmail), string.Empty);
            set => Preferences.Set(nameof(UserEmail), value);
        }

        public string PhoneNumber
        {
            get => Preferences.Get(nameof(PhoneNumber), string.Empty);
            set => Preferences.Set(nameof(PhoneNumber), value);
        }

        public string State
        {
            get => Preferences.Get(nameof(State), string.Empty);
            set => Preferences.Set(nameof(State), value);
        }

        public string Location
        {
            get => Preferences.Get(nameof(Location), string.Empty);
            set => Preferences.Set(nameof(Location), value);
        }

        public string ClientType
        {
            get => Preferences.Get(nameof(ClientType), string.Empty);
            set => Preferences.Set(nameof(ClientType), value);
        }

        public string CurrentTemp
        {
            get => Preferences.Get(nameof(CurrentTemp), string.Empty);
            set => Preferences.Set(nameof(CurrentTemp), value);
        }

        public string ItemMenuSelected
        {
            get => Preferences.Get(nameof(ItemMenuSelected), string.Empty);
            set => Preferences.Set(nameof(ItemMenuSelected), value);
        }

        public bool IsFirstUse
        {
            get => Preferences.Get(nameof(IsFirstUse), true);
            set => Preferences.Set(nameof(IsFirstUse), value);
        }

        public bool IsLoggedIn
        {
            get => Preferences.Get(nameof(IsLoggedIn), false);
            set => Preferences.Set(nameof(IsLoggedIn), value);
        }

        public bool IsAdmin
        {
            get => Preferences.Get(nameof(IsAdmin), false);
            set => Preferences.Set(nameof(IsAdmin), value);
        }

        public DateTime LastNewsUpdated
        {
            get => Preferences.Get(nameof(LastNewsUpdated), DateTime.Today.AddDays(-1));
            set => Preferences.Set(nameof(LastNewsUpdated), value);
        }

        public void Clear()
        {
            Preferences.Clear();
        }

        public void ClearValue(string value)
        {
            Preferences.Remove(value);
        }

        public void ClearSettings()
        {
            this.ClearValue(nameof(UserName));
            this.ClearValue(nameof(UserId));
            this.ClearValue(nameof(UserEmail));
            this.ClearValue(nameof(ClientType));
            this.ClearValue(nameof(PhoneNumber));
            this.ClearValue(nameof(Location));
            this.ClearValue(nameof(State));
            this.IsFirstUse = true;
            this.IsLoggedIn = false;
            this.IsAdmin = false;
        }
    }
}