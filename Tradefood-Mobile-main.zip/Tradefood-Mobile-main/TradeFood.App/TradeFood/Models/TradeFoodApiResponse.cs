﻿using System.Net;

namespace TradeFood.Models
{
    public class TradeFoodApiResponse
    {
        public string ErrorMessage { get; set; }

        public string Result { get; set; }

        public HttpStatusCode HttpCode { get; set; }
    }

    public class TradeFoodApiResponse<T> : TradeFoodApiResponse
    {
        public T Data { get; set; }
    }
}
