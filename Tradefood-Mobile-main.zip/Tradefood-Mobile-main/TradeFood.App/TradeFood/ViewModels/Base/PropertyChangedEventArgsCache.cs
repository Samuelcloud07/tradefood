﻿using System.Collections.Generic;
using System.ComponentModel;

namespace TradeFood.ViewModels
{
    public sealed class PropertyChangedEventArgsCache
    {
        private readonly Dictionary<string, PropertyChangedEventArgs> _cache = new Dictionary<string, PropertyChangedEventArgs>();

        public PropertyChangedEventArgsCache()
        {
        }

        public static PropertyChangedEventArgsCache Instance { get; } = new PropertyChangedEventArgsCache();

        public PropertyChangedEventArgs Get(string propertyName)
        {
            lock(_cache)
            {
                if (_cache.TryGetValue(propertyName, out PropertyChangedEventArgs result))
                    return result;

                result = new PropertyChangedEventArgs(propertyName);
                _cache.Add(propertyName, result);

                return result;
            }
        }
    }
}