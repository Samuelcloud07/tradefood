﻿using Xamarin.Forms;

namespace TradeFood.Components
{
    public partial class SubMenuItemComponent : Grid
    {
        // Bindable Properties
        public static readonly BindableProperty ImageSourceProperty = BindableProperty.Create(
            nameof(ImageSource),
            typeof(string),
            typeof(SubMenuItemComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (SubMenuItemComponent)bindable;

                view.subMenuItemImage.Source = (string)newVal;
            }
        );

        public static readonly BindableProperty IconSourceProperty = BindableProperty.Create(
            nameof(IconSource),
            typeof(string),
            typeof(SubMenuItemComponent),
            default(string),
            BindingMode.TwoWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (SubMenuItemComponent)bindable;

               view.subMenuIcon.Source = (string)newVal;
            }
        );

        public static readonly BindableProperty SubMenuItemTextProperty = BindableProperty.Create(
            nameof(SubMenuItemText),
            typeof(string),
            typeof(SubMenuItemComponent),
            default(string),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (SubMenuItemComponent)bindable;

                view.subMenuItemTitle.Text = (string)newVal;
            }
        );

        public static readonly BindableProperty SubMenuItemSelectedProperty = BindableProperty.Create(
            nameof(SubMenuItemSelected),
            typeof(bool),
            typeof(SubMenuItemComponent),
            default(bool),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (SubMenuItemComponent)bindable;

                var selected = (bool)newVal;

                var colorPrimary = (Color)Application.Current.Resources["ColorPrimary"];

                //view.subMenuStartBox.Color = selected ? colorPrimary : Color.White;

                view.subMenuItemTitle.TextColor = selected ? Color.White : Color.FromHex("#717276");

                view.subMenuImageContainer.BackgroundColor = selected ? Color.FromHex("#aa6361") : Color.White;

                view.subMenuTitleContainer.BackgroundColor = selected ? Color.FromHex("#aa6361") : Color.White;

                view.subMenuIconContainer.BackgroundColor = selected ? Color.FromHex("#aa6361") : Color.White;

                var pathImage = view.ImageSource.Split('.')[0];
                pathImage = $"{pathImage}_white.png";

                view.ImageSource = selected ? pathImage : view.ImageSource;

                view.subMenuIcon.Source = selected? "icon_metro_expand_more_white.png": "icon_metro_expand_more.png";

            }
        );

        public SubMenuItemComponent()
        {
            InitializeComponent();
        }

        public string ImageSource
        {
            get => (string)GetValue(ImageSourceProperty);
            set => SetValue(ImageSourceProperty, value);
        }

        public string IconSource
        {
            get => (string)GetValue(IconSourceProperty);
            set => SetValue(IconSourceProperty, value);
        }

        public string SubMenuItemText
        {
            get => (string)GetValue(SubMenuItemTextProperty);
            set => SetValue(SubMenuItemTextProperty, value);
        }

        public bool SubMenuItemSelected
        {
            get => (bool)GetValue(SubMenuItemSelectedProperty);
            set => SetValue(SubMenuItemSelectedProperty, value);
        }
    }
}