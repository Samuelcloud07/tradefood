﻿using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{
    public class AdministradorMenuViewModel : BaseViewModel
    {
        private readonly IDialogsHelper _dialogsHelper;
        private readonly IAppSettings _appSettings;

        public AdministradorMenuViewModel(ILogger logger,
                                          IDialogsHelper dialogsHelper,
                                          IAppSettings appSettings)
            : base(logger)
        {
            _dialogsHelper = dialogsHelper;
            _appSettings = appSettings;

            MessagingCenter.Subscribe<BaseViewModel>(this, "LoginCompleted", (sender) =>
            {
                MainThread.BeginInvokeOnMainThread(() =>
                {
                    DisplayName = _appSettings.UserName;
                });
            });

            LogoutCommand = new SandboxedCommand(Logout);
        }

        protected override Task InitializeAsync()
        {
            DisplayName = _appSettings.UserName;

            return base.InitializeAsync();
        }

        // Properties
        public string DisplayName { get; private set; }

        // Commands
        public SandboxedCommand LogoutCommand { get; private set; }

        // Methods
        private async Task Logout()
        {
            if (!await _dialogsHelper.ShowConfirmAsync("¿Esta seguro que desea salir?"))
                return;

            _dialogsHelper.ShowDialog();

            await Task.Delay(800);

            _appSettings.ClearSettings();

            _dialogsHelper.HideDialog();

            Application.Current.MainPage = new AppShell();
        }
    }
}