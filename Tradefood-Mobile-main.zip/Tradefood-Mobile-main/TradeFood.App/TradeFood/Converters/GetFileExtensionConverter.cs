﻿using System;
using System.Globalization;
using System.IO;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class GetFileExtensionConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var fileName = (string)value;

            var extesion = Path.GetExtension(fileName);

            return extesion;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}