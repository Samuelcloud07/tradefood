﻿using System;
using Xamarin.Forms;

namespace TradeFood.Behaviors
{
    public class CollectionViewHightBehavior : Behavior<CollectionView>
    {
        private bool _hasHeightChanged = false;

        public CollectionView CollectionViewObject { get; private set; }

        protected override void OnAttachedTo(CollectionView bindable)
        {
            base.OnAttachedTo(bindable);

            CollectionViewObject = bindable;

            bindable.BindingContextChanged += BindableBindingContextChanged;
            bindable.SizeChanged += BindableSizeChanged;
        }

        private void BindableSizeChanged(object sender, EventArgs e)
        {
            var collectionHeight = CollectionViewObject.Height;

            if (CollectionViewObject.Height > 0 && !_hasHeightChanged)
            {
                CollectionViewObject.HeightRequest = (collectionHeight / 2) + 20;

                _hasHeightChanged = true;
            }
        }

        private void BindableBindingContextChanged(object sender, EventArgs e)
        {
            OnBindingContextChanged();
        }

        protected override void OnBindingContextChanged()
        {
            base.OnBindingContextChanged();

            BindingContext = CollectionViewObject.BindingContext;
        }

        protected override void OnDetachingFrom(CollectionView bindable)
        {
            base.OnDetachingFrom(bindable);

            bindable.BindingContextChanged -= BindableBindingContextChanged;
            bindable.SizeChanged -= BindableSizeChanged;
        }
    }
}