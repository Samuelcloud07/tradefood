﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.Services
{
    public interface IAgroNewsService
    {
        Task<List<NewsReport>> GetAgroNewsAsync();
    }
}