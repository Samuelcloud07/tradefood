﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace TradeFood.Repositories
{
    public interface ISQLiteRepository<T>
        where T : class, new()
    {
        Task<List<T>> GetallAsync(Expression<Func<T, bool>> wherePredicate = null, CancellationToken cancellationToken = default);

        Task<List<T>> GetAllAsync<TOrderValue>(Expression<Func<T, bool>> wherePredicate = null,
                                               Expression<Func<T, TOrderValue>> orderBy = null,
                                               bool orderByAscending = true,
                                               CancellationToken cancellationToken = default);

        Task<T> GetAsync(object id, CancellationToken cancellationToken = default);

        Task SaveAllAsync(IEnumerable<T> entities);

        Task SaveAsync(T entity);

        Task DeleteAllAsync(IEnumerable<T> entities);

        Task DeleteAsync(T entity);

        Task DeleteAsync(object id);
    }
}