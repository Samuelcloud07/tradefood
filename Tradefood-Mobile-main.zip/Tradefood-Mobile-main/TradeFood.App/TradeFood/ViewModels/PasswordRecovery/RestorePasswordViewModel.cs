﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using TradeFood.Commands;
using TradeFood.Extensions;
using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Resources;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using Xamarin.Forms;

namespace TradeFood.ViewModels
{

    public class RestorePasswordViewModel : BaseViewModel, IQueryAttributable
    {
        public Dictionary<string, string> Errors { get; private set; } = new Dictionary<string, string>();

        private readonly IAuthenticationService _authenticationService;
        private readonly IDialogsHelper _dialogsHelper;

        public RestorePasswordViewModel(ILogger logger,
                                        IAuthenticationService authenticationService,
                                        IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _authenticationService = authenticationService;
            _dialogsHelper = dialogsHelper;

            ResetPasswordCommand = new SandboxedCommand(ResetPassword);

            GoBackCommand = new SandboxedCommand(GoBack);
        }

        public void ApplyQueryAttributes(IDictionary<string, string> query)
        {
            ResetUserPassword = JsonConvert.DeserializeObject<ResetUserPassword>(HttpUtility.UrlDecode(query["resetUserPassword"]));
        }

        // Properties
        public ResetUserPassword ResetUserPassword { get; private set; }

        public string NewPassword { get; set; }

        // Commands
        public SandboxedCommand ResetPasswordCommand { get; private set; }
        
        public SandboxedCommand GoBackCommand { get; private set; }
        public bool HasErrors { get; private set; }

        // Methods
        private async Task ResetPassword()
        {
            if (!ValidateAll())
                return;

            _dialogsHelper.ShowDialog();

            ResetUserPassword.Password = NewPassword;

            await _authenticationService.ResetPasswordAsync(ResetUserPassword);

            _dialogsHelper.HideDialog();

            await _dialogsHelper.ShowAlertAsync("Su nueva contraseña ha sido establecida.");

            await Shell.Current.Navigation.PopToRootAsync();
        }

        private bool ValidateAll()
        {
            if (!NewPassword.IsValidPassword())
                Errors.Add(nameof(NewPassword), Strings.MustBeAtLeastEightAlphanumericCharactersAndSymbols);

            this.OnPropertyChanged(nameof(Errors));

            HasErrors = Errors.Any();

            return !Errors.Any();
        }

        private async Task GoBack() => await Shell.Current.Navigation.PopToRootAsync();
    }
}