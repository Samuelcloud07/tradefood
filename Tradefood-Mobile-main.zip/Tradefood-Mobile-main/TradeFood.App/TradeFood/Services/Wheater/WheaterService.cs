﻿using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Providers;

namespace TradeFood.Services
{
    public class WheaterService : IWheaterService
    {
        private readonly IProviderFactory _providerFactory;

        public WheaterService(IProviderFactory providerFactory)
        {
            _providerFactory = providerFactory;
        }

        public Task<WheaterData> GetWheaterAsync(string lat, string lon)
        {
            return _providerFactory.Create<IWheaterProvider>().GetWheaterAsync(lat, lon);
        }
    }
}