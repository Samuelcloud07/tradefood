﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;
using TradeFood.Models.Profile.Dtos;

namespace TradeFood.Services
{
    public interface IProfileService
    {
        Task<string> TestAsync();

        Task<CommercialReferenceDto> GetCommercialReferenceAsync(long userId);

        Task<bool> AddCommercialReferenceAsync(string userId, CommercialReferenceDto commercialReference);

        Task<bool> AddSocietiesAndPersonsAsync(long userId, SocietiesAndPersonDto societiesAndPerson);

        Task<List<SocietiesAndPersonDto>> GetSocietiesAndPersonsAsync(long userId);

        Task<bool> AddAddressSocietiesAsync(long userId, long societiesId, AddressDto address);

        Task<bool> DeleteSocietiesAsync(long userId, long societiesId);

        Task<bool> UpdateSocietiesAsync(long userId, SocietiesAndPersonDto societiesAndPersons);

        Task<bool> UpdateAddressAsync(long userId, AddressDto address);

        Task<List<AddressDto>> GetAllAddressesAsync(long userId);

        Task<List<AddressDto>> GetAddressesAsync(long userId);

        Task<bool> AddAddressAsync(AddressDto addressDto, long userId);

        Task<ProfileStats> GetProfileStats();

        Task<PreferencesDto> GetProfilePreferences(long userId);

        Task<bool> AddProfilePreferences(long userId, PreferencesDto preferences);
    }
}