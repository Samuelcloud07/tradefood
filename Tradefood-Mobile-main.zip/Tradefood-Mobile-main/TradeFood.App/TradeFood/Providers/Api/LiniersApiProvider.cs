﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.ApiClient;
using TradeFood.ApiClient.ApisInterfaces;
using TradeFood.Models;

namespace TradeFood.Providers
{
    public class LiniersApiProvider : TradeFoodBaseApiProvider, ILiniersApiProvider
    {
        private readonly ILiniersLocalProvider _liniersLocalProvider;

        public LiniersApiProvider(IAppHttpClient httpClientSingleton,
                                  IApiExceptionManager apiExceptionManager,
                                  ILiniersLocalProvider liniersLocalProvider)
            : base(httpClientSingleton, apiExceptionManager)
        {
            _liniersLocalProvider = liniersLocalProvider;
        }

        public async Task<List<LiniersData>> GetCotizacionesLiniersAsync()
        {
            var cotizacionesLiniers = await this.ExecuteRequest<TradeFoodApiResponse<List<LiniersData>>>(
                () => this.GetRestServiceFor<ILiniersApi>().GetCotizacionesLiniersAsync()).ConfigureAwait(false);

            return await _liniersLocalProvider.PersistLiniersDataAsync(cotizacionesLiniers.Data).ConfigureAwait(false);
        }
    }
}