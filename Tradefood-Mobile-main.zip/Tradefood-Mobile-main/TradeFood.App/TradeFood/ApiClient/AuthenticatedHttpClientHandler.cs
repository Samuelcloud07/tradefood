﻿using TradeFood.SecureRepository;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace TradeFood.ApiClient
{
    public class AuthenticatedHttpClientHandler : HttpClientHandler
    {
        private readonly ISecureStorageRepository _secureStorageRepository;

        public AuthenticatedHttpClientHandler(ISecureStorageRepository secureStorageRepository)
        {
            _secureStorageRepository = secureStorageRepository;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            //var accessToken = await _secureStorageRepository.GetAccessToken();

            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            //if (!string.IsNullOrEmpty(accessToken))
            //    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            return await base.SendAsync(request, cancellationToken).ConfigureAwait(false);
        }
    }
}