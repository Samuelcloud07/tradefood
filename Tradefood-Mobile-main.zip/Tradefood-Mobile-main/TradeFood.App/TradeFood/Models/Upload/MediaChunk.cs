﻿namespace TradeFood.Models
{
    public class MediaChunk
    {
        public string FileHandle { get; set; }

        public string Data { get; set; }

        public string StartAt { get; set; }
    }
}