﻿using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.ApiClient.ApisInterfaces
{
    public interface IAgroNewsApi
    {
        [Get("/agronewsfunction/agronews/noticias")]
        Task<TradeFoodApiResponse<List<NewsReport>>> GetAgroNewsAsync();
    }
}