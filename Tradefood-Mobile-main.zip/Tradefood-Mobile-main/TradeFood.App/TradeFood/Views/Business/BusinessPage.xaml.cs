﻿namespace TradeFood.Views
{
    public partial class BusinessPage : BasePage
    {
        public BusinessPage()
        {
            InitializeComponent();
        }
    }
}