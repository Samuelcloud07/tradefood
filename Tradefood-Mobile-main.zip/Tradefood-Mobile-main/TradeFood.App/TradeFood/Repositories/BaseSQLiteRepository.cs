﻿using SQLite;
using SQLiteNetExtensions.Extensions;
using SQLiteNetExtensionsAsync.Extensions;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace TradeFood.Repositories
{
    public class BaseSQLiteRepository<T> : ISQLiteRepository<T>
        where T : class, new()
    {
        private readonly ISQLiteAdapter _sqliteAdapter;

        public BaseSQLiteRepository(ISQLiteAdapter adapter)
        {
            _sqliteAdapter = adapter;
        }

        public async Task<List<T>> GetallAsync(Expression<Func<T, bool>> wherePredicate = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var entities = wherePredicate == null
                ? await _sqliteAdapter.Connection.Table<T>().ToListAsync().ConfigureAwait(false)
                : await _sqliteAdapter.Connection.Table<T>().Where(wherePredicate).ToListAsync().ConfigureAwait(false);

            cancellationToken.ThrowIfCancellationRequested();

            foreach (var entity in entities)
                await _sqliteAdapter.Connection.GetChildrenAsync(entity, true, cancellationToken).ConfigureAwait(false);

            return entities;
        }

        public async Task<List<T>> GetAllAsync<TOrderValue>(Expression<Func<T, bool>> wherePredicate = null,
                                                            Expression<Func<T, TOrderValue>> orderBy = null,
                                                            bool orderByAscending = true,
                                                            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var query = _sqliteAdapter.Connection.Table<T>();

            if (wherePredicate != null)
                query = query.Where(wherePredicate);

            if (orderBy != null)
                query = orderByAscending ? query.OrderBy(orderBy) : query.OrderByDescending(orderBy);

            var entities = await query.ToListAsync().ConfigureAwait(false);

            cancellationToken.ThrowIfCancellationRequested();

            foreach (var entity in entities)
                await _sqliteAdapter.Connection.GetChildrenAsync(entity, true, cancellationToken).ConfigureAwait(false);

            return entities;
        }

        public Task<T> GetAsync(object id, CancellationToken cancellationToken = default)
        {
            return _sqliteAdapter.Connection.FindWithChildrenAsync<T>(id, true, cancellationToken);
        }

        public Task SaveAllAsync(IEnumerable<T> entities)
        {
            return _sqliteAdapter.Connection.RunInTransactionAsync((SQLiteConnection conn) =>
            {
                conn.InsertOrReplaceAllWithChildren(entities, true);
            });
        }

        public Task SaveAsync(T entity)
        {
            return _sqliteAdapter.Connection.RunInTransactionAsync((SQLiteConnection conn) =>
            {
                conn.InsertOrReplaceWithChildren(entity, true);
            });
        }

        public Task DeleteAllAsync(IEnumerable<T> entities)
        {
            return _sqliteAdapter.Connection.RunInTransactionAsync((SQLiteConnection conn) =>
            {
                conn.DeleteAll(entities, true);
            });
        }

        public Task DeleteAsync(T entity)
        {
            return _sqliteAdapter.Connection.RunInTransactionAsync((SQLiteConnection conn) =>
            {
                conn.Delete(entity, true);
            });
        }

        public Task DeleteAsync(object id)
        {
            return _sqliteAdapter.Connection.RunInTransactionAsync((SQLiteConnection conn) =>
            {
                var entity = conn.FindWithChildren<T>(id, true);

                if (entity == null)
                    return;

                conn.Delete(entity, true);
            });
        }

    }
}