﻿namespace TradeFood.Providers
{
    public interface IAgroNewsApiProvider : IAgroNewsProvider
    {
    }
}