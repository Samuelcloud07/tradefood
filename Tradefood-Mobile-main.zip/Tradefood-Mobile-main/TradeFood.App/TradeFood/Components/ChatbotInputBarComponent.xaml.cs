﻿using PropertyChanged;
using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace TradeFood.Components
{
    [SuppressPropertyChangedWarnings]
    public partial class ChatbotInputBarComponent : StackLayout
    {
        public static readonly BindableProperty TextProperty = BindableProperty.Create(
            nameof(Text),
            typeof(string),
            typeof(ChatbotInputBarComponent),
            default(string),
            BindingMode.TwoWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (ChatbotInputBarComponent)bindable;

                view.inputEntry.Text = (string)newVal;
            }
        );

        public static readonly BindableProperty PostQuestionCommandProperty = BindableProperty.Create(
            nameof(PostQuestionCommand),
            typeof(ICommand),
            typeof(ChatbotInputBarComponent),
            default(ICommand),
            BindingMode.OneWay,
            null,
            (bindable, oldVal, newVal) =>
            {
                var view = (ChatbotInputBarComponent)bindable;

                view.inputEntry.ReturnCommand = (ICommand)newVal;

                view.sendGestureRecognizer.Command = (ICommand)newVal;
            }
        );

        public ChatbotInputBarComponent()
        {
            InitializeComponent();

            this.inputEntry.Text = this.Text;

            this.inputEntry.TextChanged += this.OnInputTextChanged;
        }

        // Event Handlers
        public event EventHandler<TextChangedEventArgs> TextChanged;

        // Properties
        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        public ICommand PostQuestionCommand
        {
            get => (ICommand)GetValue(PostQuestionCommandProperty);
            set => SetValue(PostQuestionCommandProperty, value);
        }

        // Methods
        private void OnInputTextChanged(object sender, TextChangedEventArgs e)
        {
            this.Text = e.NewTextValue;

            this.TextChanged?.Invoke(this, e);
        }
    }
}