﻿using TradeFood.Helpers;
using TradeFood.Models;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace TradeFood.Views
{
    public partial class RegisterPage : BasePage
    {
        private RegisterViewModel _vm;
        public RegisterPage()
        {
            InitializeComponent();

            _vm = new RegisterViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<IStatesService>(),
                TypeLocator.Resolve<IAuthenticationService>(),
                TypeLocator.Resolve<IDialogsHelper>());

            this.BindingContext = _vm;

            MessagingCenter.Subscribe<BasePage, ProvinceLocation>(this, "locationSelected", (sender, args) =>
            {
                _vm.LocationSelected = args;

                _vm.LocationTitle = _vm.LocationSelected.Name;
            });
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            var safeInsets = On<iOS>().SafeAreaInsets();

            safeInsets.Bottom = -35;

            content.Padding = safeInsets;
        }
    }
}