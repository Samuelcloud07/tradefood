﻿using System.Threading.Tasks;
using TradeFood.Helpers;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace TradeFood.Views
{
    public partial class LoginPage : BasePage
    {
        private LoginViewModel _vm;

        public LoginPage()
        {
            InitializeComponent();

            _vm = new LoginViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<IAuthenticationService>(),
                TypeLocator.Resolve<IAppSettings>(),
                TypeLocator.Resolve<IDialogsHelper>());

            this.BindingContext = _vm;

            this.user.ReturnCommand = new Command(() => this.password.Focus());
            this.password.ReturnCommand = new Command(() => this.PasswordEntryCompleted());
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            var safeInsets = On<iOS>().SafeAreaInsets();

            safeInsets.Bottom = -35;

            content.Padding = safeInsets;

            if (DeviceInfo.Platform == DevicePlatform.UWP)
            {
                MainThread.InvokeOnMainThreadAsync(async () =>
                {
                    Shell.SetNavBarIsVisible(this, true);

                    await Task.Delay(100);

                    Shell.SetNavBarIsVisible(this, false);
                });
            }
        }

        protected override bool OnBackButtonPressed() => true;

        private void PasswordEntryCompleted()
        {
            this.loginBtn.Focus();

            _vm.LoginCommand.Execute(null);
        }
    }
}