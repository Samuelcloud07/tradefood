﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TradeFood.Commands;
using TradeFood.Helpers;
using TradeFood.Models.Market.Dtos;
using TradeFood.Sandbox;
using TradeFood.Services;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.Views;
using TradeFood.Views.Market;
using Xamarin.Forms;

namespace TradeFood.ViewModels.Market
{
    public class NewMarketViewModel : BaseViewModel
    {

        private readonly IAppSettings _appSettings;
        private readonly IDealsService _dealsService;
        private readonly IDialogsHelper _dialogsHelper;

        public List<DealApiDto> _deals=new List<DealApiDto>();
        public NewMarketViewModel(ILogger logger,
                                  IDealsService dealsService,
                                  IAppSettings appSettings,
                                  IDialogsHelper dialogsHelper)
            : base(logger)
        {
            _appSettings = appSettings;
            _dialogsHelper = dialogsHelper;
            _dealsService = dealsService;

            ShowAllDealsCommand = new SandboxedCommand(ShowAllDeals);

            ShowMyDealsCommand = new SandboxedCommand(ShowMyDeals);

            CreateNewBusinessCommand = new SandboxedCommand(CreateNewBusiness);

            OpenDealFiltersCommand = new SandboxedCommand(OpenDealFilters);
        }

        protected override Task InitializeAsync()
        {
            return base.InitializeAsync();
        }

        public override void OnAppearing()
        {
            this.LoadTask = SandboxedNotifyTask.Create(() => GetDeals());
            ShowAllDealsSelected = !ShowMyDealsSelected;
        }

        //Properties
        public ObservableCollection<DealApiItemViewModel> MyDeals { get; private set; } = new ObservableCollection<DealApiItemViewModel>();
        public ObservableCollection<DealApiItemViewModel> BuyDeals { get; set; } = new ObservableCollection<DealApiItemViewModel>();
        public bool ShowAllDealsSelected { get; private set; }
        public bool ShowMyDealsSelected { get; private set; }
        public string Title { get; private set; }


        //Commands
        public SandboxedCommand CreateNewBusinessCommand { get; private set; }
        public SandboxedCommand ShowAllDealsCommand { get; private set; }
        public SandboxedCommand ShowMyDealsCommand { get; private set; }
        public SandboxedCommand OpenDealFiltersCommand { get; private set; }


        //Methods
        private async Task GetDeals()
        {
            MyDeals.Clear();
            BuyDeals.Clear();

            _dialogsHelper.ShowDialog();

            _deals = await _dealsService.GetDealsAsync();

            var buyDeals = _deals.Where(x => x.CreatedBy != _appSettings.UserId).ToList();
            var myDeals = _deals.Where(x => x.CreatedBy == _appSettings.UserId).ToList();

            foreach (var deal in myDeals)
                MyDeals.Add(new DealApiItemViewModel(deal));

            foreach (var deal in buyDeals)
                BuyDeals.Add(new DealApiItemViewModel(deal));

            _dialogsHelper.HideDialog();

        }

        private Task<bool> ShowAllDeals()
        {
            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();

            _dialogsHelper.ShowDialog();

            ShowAllDealsSelected = true;

            ShowMyDealsSelected = false;

            _dialogsHelper.HideDialog();

            tcs.SetResult(true);

            return tcs.Task;
        }

        private Task<bool> ShowMyDeals()
        {
            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();

            ShowAllDealsSelected = false;

            ShowMyDealsSelected = true;

            _dialogsHelper.ShowDialog();

            _dialogsHelper.HideDialog();

            tcs.SetResult(true);

            return tcs.Task;
        }

        private async Task CreateNewBusiness()
        {
            _dialogsHelper.ShowDialog();

            await Shell.Current.GoToAsync(nameof(NewPublishFirstStepPage));

            _dialogsHelper.HideDialog();
        }

        private async Task OpenDealFilters() => await Shell.Current.GoToAsync(nameof(DealsFiltersPage));
    }
}
