﻿using PropertyChanged;

namespace TradeFood.Models
{
    [AddINotifyPropertyChangedInterface]
    public class SideMenuItem
    {
        public string MenuImage { get; set; }

        public string MenuTitle { get; set; }

        public string Target { get; set; }

        public bool IsSelected { get; set; }

        public string MenuIcon { get; set; }
    }
}