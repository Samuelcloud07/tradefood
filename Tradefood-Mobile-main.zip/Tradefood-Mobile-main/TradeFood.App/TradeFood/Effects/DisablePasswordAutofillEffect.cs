﻿using Xamarin.Forms;

namespace TradeFood.Effects
{
    public class DisablePasswordAutofillEffect : RoutingEffect
    {
        public DisablePasswordAutofillEffect()
            : base("TradeFood.DisablePasswordAutofillEffect")
        {
        }
    }
}