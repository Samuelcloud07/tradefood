﻿using AVFoundation;
using CoreGraphics;
using CoreMedia;
using Foundation;
using System;
using System.IO;
using System.Threading.Tasks;
using TradeFood.Handlers;
using TradeFood.iOS.Handlers;
using UIKit;
using Xamarin.Forms;

[assembly: Dependency(typeof(VideoTranscoderHandler))]
namespace TradeFood.iOS.Handlers
{
    public class VideoTranscoderHandler : IVideoTranscoderHandler
    {
        public async Task<string> TranscodeVideoAsync(string sourceVideoPath)
        {
            var asset = AVAsset.FromUrl(NSUrl.FromFilename(sourceVideoPath));
            AVAssetExportSession export = new AVAssetExportSession(asset, AVAssetExportSessionPreset.Preset1280x720);

            string outputFilePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Personal),
                $"{Path.GetRandomFileName().Split('.')[0]}.mp4"
            );
            export.OutputUrl = NSUrl.FromFilename(outputFilePath);
            export.OutputFileType = AVFileType.Mpeg4;
            export.ShouldOptimizeForNetworkUse = true;
            export.FileLengthLimit = 4097152;

            await export.ExportTaskAsync();

            MemoryStream output = new MemoryStream();

            using (Stream source = File.OpenRead(outputFilePath))
                await source.CopyToAsync(output);

            output.Seek(0, SeekOrigin.Begin);

            return outputFilePath;
        }

        public Task<string> GenerateThumbnail(string sourceVideoPath)
        {
            TaskCompletionSource<string> tcs = new TaskCompletionSource<string>();

            AVAssetImageGenerator imageGenerator = new AVAssetImageGenerator(AVAsset.FromUrl(NSUrl.FromFilename(sourceVideoPath)));
            imageGenerator.AppliesPreferredTrackTransform = true;

            CMTime actualTime;
            NSError error;

            CGImage cgImage = imageGenerator.CopyCGImageAtTime(new CMTime(1, 1000000), out actualTime, out error);

            var outputStream = new UIImage(cgImage).AsPNG().AsStream();

            string outputFilePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Personal),
                $"{Path.GetRandomFileName().Split('.')[0]}.png"
            );

            using (var fileStream = File.Create(outputFilePath))
            {
                outputStream.Seek(0, SeekOrigin.Begin);

                outputStream.CopyTo(fileStream);
            }

            tcs.SetResult(outputFilePath);

            return tcs.Task;
        }
    }
}