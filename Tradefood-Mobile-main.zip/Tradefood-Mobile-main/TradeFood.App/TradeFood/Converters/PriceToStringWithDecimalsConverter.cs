﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class PriceToStringWithDecimalsConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var price = (string)value;

            if (string.IsNullOrEmpty(price))
                return string.Empty;

            if (price.Contains("."))
                culture = new CultureInfo("en");

            var decimalPrice = !price.Equals("s/c")? decimal.Parse(price, culture) : 0;

            return Math.Round(decimalPrice, 2).ToString(new CultureInfo("es"));
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}