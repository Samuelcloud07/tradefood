﻿using TradeFood.Models;
using SQLite;
using System;
using System.IO;
using System.Threading.Tasks;
using Xamarin.Essentials;

namespace TradeFood.Repositories
{
    public class SQLiteAdapter : ISQLiteAdapter
    {
        private const string DATABASE_NAME = "tradefood.sqlite";

        public SQLiteAdapter()
        {
            Extensions.TaskExtensions.RunInSandbox(this.OpenConnectionAsync());
        }

        // Properties
        public SQLiteAsyncConnection Connection { get; private set; }

        // Methods
        private async Task InitializeAsync()
        {
            await this.Connection.CreateTablesAsync(CreateFlags.AutoIncPK, new Type[]
            {
                typeof(LiniersData),
                typeof(NewsReport),
                typeof(PreBusiness)
            }).ConfigureAwait(false);
        }

        public async Task DropTablesAsync()
        {
            var tasks = new[]
            {
                this.Connection.DropTableAsync<LiniersData>(),
                this.Connection.DropTableAsync<NewsReport>(),
                this.Connection.DropTableAsync<PreBusiness>()
            };

            await Task.WhenAll(tasks).ConfigureAwait(false);

            await this.InitializeAsync().ConfigureAwait(false);
        }

        private async Task OpenConnectionAsync()
        {
            SQLiteOpenFlags flags = SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.FullMutex | SQLiteOpenFlags.SharedCache;

            Environment.SpecialFolder appFolder = DeviceInfo.Platform == DevicePlatform.UWP
                ? Environment.SpecialFolder.LocalApplicationData
                : Environment.SpecialFolder.Personal;

            this.Connection = new SQLiteAsyncConnection(Path.Combine(Environment.GetFolderPath(appFolder), DATABASE_NAME), flags, false);

            await this.InitializeAsync().ConfigureAwait(false);
        }
    }
}