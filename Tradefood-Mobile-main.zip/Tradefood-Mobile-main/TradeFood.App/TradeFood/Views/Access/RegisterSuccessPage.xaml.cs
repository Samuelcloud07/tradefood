﻿using TradeFood.Services.Loggin;
using TradeFood.ViewModels;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace TradeFood.Views
{
    public partial class RegisterSuccessPage : BasePage
    {
        private RegisterSuccessViewModel _vm;

        public RegisterSuccessPage()
        {
            InitializeComponent();

            _vm = new RegisterSuccessViewModel(
                TypeLocator.Resolve<ILogger>());

            this.BindingContext = _vm;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            var safeInsets = On<iOS>().SafeAreaInsets();

            safeInsets.Bottom = -35;

            content.Padding = safeInsets;
        }

        protected override bool OnBackButtonPressed()
        {
            _vm.GoBackCommand.Execute(null);

            return true;
        }
    }
}