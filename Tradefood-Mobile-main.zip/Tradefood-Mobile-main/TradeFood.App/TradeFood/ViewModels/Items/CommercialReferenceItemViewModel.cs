﻿using System.ComponentModel;

namespace TradeFood.ViewModels
{
    class CommercialReferenceItemViewModel
    {
        public CommercialReferenceItemViewModel(string name, string comments)
        {
            Name = name;
            Comments = comments;
        }
        public string Name { get; private set; }
        public string Comments { get; private set; }
    }
}
