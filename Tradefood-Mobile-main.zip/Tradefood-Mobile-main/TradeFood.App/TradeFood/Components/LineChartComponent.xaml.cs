﻿using Microcharts;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.Components
{
    public partial class LineChartComponent : StackLayout
    {
        public static readonly BindableProperty ItemsSourceProperty = BindableProperty.Create(
            nameof(ItemsSource),
            typeof(IEnumerable<ChartEntry>),
            typeof(LineChartComponent),
            default(IEnumerable<ChartEntry>),
            defaultBindingMode: BindingMode.TwoWay,
            propertyChanged: OnNewItemsAdded
        );

        public LineChartComponent()
        {
            InitializeComponent();

            this.linearChart.Chart = new LineChart
            {
                LineMode = LineMode.Spline,
                LineSize = DeviceInfo.Platform == DevicePlatform.UWP ? 3 : 5,
                LabelOrientation = Microcharts.Orientation.Horizontal,
                ValueLabelOrientation = Microcharts.Orientation.Horizontal,
                PointMode = PointMode.Circle,
                LabelTextSize = DeviceInfo.Platform == DevicePlatform.UWP ? 15 : 25,
                IsAnimated = false
            };
        }

        // Properties
        public IEnumerable<ChartEntry> ItemsSource
        {
            get => (IEnumerable<ChartEntry>)GetValue(ItemsSourceProperty);
            set => SetValue(ItemsSourceProperty, value);
        }

        // Methods
        private static void OnNewItemsAdded(BindableObject bindable, object oldVal, object newVal)
        {
            if (newVal == null)
                return;

            var view = (LineChartComponent)bindable;

            var entries = ((IEnumerable<ChartEntry>)newVal).ToList();

            if (entries != null && entries.Count() > 0)
                view.linearChart.Chart.Entries = entries;

            view.ForceLayout();
            view.UpdateChildrenLayout();
        }
    }
}