﻿using System;
using System.Globalization;
using TradeFood.Models;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TradeFood.Converters
{
    public class WeatherConditionToImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var weather = (Weather)value;

            switch (weather.Description)
            {
                case ("clear sky"):
                    if (DeviceInfo.Platform == DevicePlatform.UWP)
                        return "clear_sky.png";
                    else
                        return "clear_sky";

                case ("few clouds: 11-25%"):
                case ("few clouds"):
                    if (DeviceInfo.Platform == DevicePlatform.UWP)
                        return "few_clouds.png";
                    else
                        return "few_clouds";

                case ("scattered clouds: 25-50%"):
                case ("scattered clouds"):
                case ("broken clouds: 51-84%"):
                case ("broken clouds"):
                case ("overcast clouds: 85-100%"):
                case ("overcast clouds"):
                    if (DeviceInfo.Platform == DevicePlatform.UWP)
                        return "clouds_sky.png";
                    else
                        return "clouds_sky";

                case ("light rain"):
                case ("moderate rain"):
                case ("heavy intensity rain"):
                case ("very heavy rain"):
                case ("extreme rain"):
                case ("freezing rain"):
                case ("light intensity shower rain"):
                case ("shower rain"):
                case ("heavy intensity shower rain"):
                case ("ragged shower rain"):
                case ("rain"):
                    if (DeviceInfo.Platform == DevicePlatform.UWP)
                        return "rain.png";
                    else
                        return "rain";

                case ("thunderstorm with light rain"):
                case ("thunderstorm with rain"):
                case ("thunderstorm with heavy rain"):
                case ("light thunderstorm"):
                case ("thunderstorm"):
                case ("heavy thunderstorm"):
                case ("ragged thunderstorm"):
                case ("thunderstorm with light drizzle"):
                case ("thunderstorm with drizzle"):
                case ("thunderstorm with heavy drizzle"):
                    if (DeviceInfo.Platform == DevicePlatform.UWP)
                        return "storm.png";
                    else
                        return "storm";

                case ("light snow"):
                case ("snow"):
                case ("heavy snow"):
                case ("sleet"):
                case ("light shower sleet"):
                case ("shower sleet"):
                case ("light rain and snow"):
                case ("rain and snow"):
                case ("light shower snow"):
                case ("shower snow"):
                case ("heavy shower snow"):
                    if (DeviceInfo.Platform == DevicePlatform.UWP)
                        return "snow.png";
                    else
                        return "snow";

                default:
                    return string.Empty;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}