﻿using System;
using TradeFood.Enums;

namespace TradeFood.Settings
{
    public interface IAppSettings
    {
        string UserName { get; set; }

        string UserId { get; set; }

        string PhoneNumber { get; set; }

        string UserEmail { get; set; }

        string ClientType { get; set; }

        string CurrentTemp { get; set; }

        string State { get; set; }

        string Location { get; set; }

        string ItemMenuSelected { get; set; }

        bool IsFirstUse { get; set; }

        bool IsLoggedIn { get; set; }

        bool IsAdmin { get; set; }

        DateTime LastNewsUpdated { get; set; }

        void Clear();

        void ClearValue(string value);

        void ClearSettings();
    }
}