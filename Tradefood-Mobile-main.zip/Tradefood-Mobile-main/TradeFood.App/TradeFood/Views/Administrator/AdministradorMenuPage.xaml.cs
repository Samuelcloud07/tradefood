﻿using TradeFood.Helpers;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels;

namespace TradeFood.Views
{
    public partial class AdministradorMenuPage : BasePage
    {
        public AdministradorMenuPage()
        {
            InitializeComponent();

            this.BindingContext = new AdministradorMenuViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<IDialogsHelper>(),
                TypeLocator.Resolve<IAppSettings>()
            );
        }
    }
}