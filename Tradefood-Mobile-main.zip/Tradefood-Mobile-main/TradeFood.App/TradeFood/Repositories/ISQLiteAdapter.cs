﻿using SQLite;
using System.Threading.Tasks;

namespace TradeFood.Repositories
{
    public interface ISQLiteAdapter
    {
        SQLiteAsyncConnection Connection { get; }

        Task DropTablesAsync();
    }
}