﻿using Refit;
using System.Threading.Tasks;
using TradeFood.Models;

namespace TradeFood.ApiClient.ApisInterfaces
{
    public interface IAuthenticationApi
    {
        [Post("/authenticationfunction/Authentication/login")]
        Task<TradeFoodApiResponse<LoginResponse>> LoginAsync([Body(BodySerializationMethod.Serialized)] SignIn signIn);

        [Get("/authenticationfunction/Authentication/password?email={email}")]
        Task<TradeFoodApiResponse<RequestNewPasswordResponse>> RequestPasswordResetAsync(string email);

        [Post("/authenticationfunction/Authentication/password")]
        Task<TradeFoodApiResponse<bool>> ResetPasswordAsync([Body(BodySerializationMethod.Serialized)] ResetUserPassword resetUserPassword);

        [Post("/authenticationfunction/Authentication/signup")]
        Task<TradeFoodApiResponse<LoginResponse>> SignUpAsync([Body(BodySerializationMethod.Serialized)] SignUp signUp);

        [Post("/authenticationfunction/Authentication/confirm-email")]
        Task<TradeFoodApiResponse<LoginResponse>> ConfirmEmailAsync([Body(BodySerializationMethod.Serialized)] EmailConfirmation emailConfirmation);

        [Post("/authenticationfunction/Authentication/resend-email-confirmation?email={email}")]
        Task<TradeFoodApiResponse<bool>> ResendEmailConfirmationAsync(string email);

        [Post("/authenticationfunction/Authentication/changepassword")]
        Task<TradeFoodApiResponse<bool>> ChangePasswordAsync([Body(BodySerializationMethod.Serialized)] ResetUserPassword resetUserPassword);
    }
}