﻿namespace TradeFood.Providers
{
    public interface IGrainsLocalProvider : IGrainsProvider
    {        
    }
}