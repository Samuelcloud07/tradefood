﻿namespace TradeFood.Models
{
    public class File
    {
        public string FilePath { get; set; }
    }
}