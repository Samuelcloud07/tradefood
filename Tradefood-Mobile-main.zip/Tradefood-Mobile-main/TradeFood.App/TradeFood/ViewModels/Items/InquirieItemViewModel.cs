﻿using System.ComponentModel;

namespace TradeFood.ViewModels
{
    public class InquirieItemViewModel : INotifyPropertyChanged
    {
        public InquirieItemViewModel(string text,
                                     string username,
                                     bool isUserPost = false,
                                     bool isPreviousUserPost = false)
        {
            InquirieText = text;

            UserName = username;

            IsUserPost = isUserPost;

            IsPreviousUserPost = isPreviousUserPost;
        }

        // Properties
        public string InquirieText { get; set; }

        public string UserName { get; set; }

        public bool IsUserPost { get; set; }

        public bool IsPreviousUserPost { get; set; }


        // INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}