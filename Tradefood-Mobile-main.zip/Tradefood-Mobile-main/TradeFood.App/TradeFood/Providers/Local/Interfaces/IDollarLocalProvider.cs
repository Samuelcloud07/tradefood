﻿namespace TradeFood.Providers
{
    public interface IDollarLocalProvider : IDollarProvider
    {
    }
}