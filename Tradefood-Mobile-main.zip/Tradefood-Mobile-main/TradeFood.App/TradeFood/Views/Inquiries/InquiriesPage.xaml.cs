﻿using System;
using System.ComponentModel;
using System.Linq;
using TradeFood.Services.Loggin;
using TradeFood.Settings;
using TradeFood.ViewModels;

namespace TradeFood.Views
{
    public partial class InquiriesPage : BasePage
    {
        private InquiriesViewModel _vm;
        public InquiriesPage()
        {
            InitializeComponent();

            _vm = new InquiriesViewModel(
                TypeLocator.Resolve<ILogger>(),
                TypeLocator.Resolve<IAppSettings>());

            this.BindingContext = _vm;

            this.inquirieDate.Text = $"{DateTime.Now:dd/MM/yyyy HH:mm}";
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            _vm.PropertyChanged += ViewModel_PropertyChanged;
        }

        private void ViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(_vm.Inquiries))
            {
                inquiriesChat.ScrollTo(_vm.Inquiries.Last());
                inquiriesChatUwp.ScrollTo(_vm.Inquiries.Last());
            }
        }
    }
}